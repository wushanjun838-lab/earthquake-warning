package com.quake.warning

import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Locale
import java.util.TimeZone

/**
 * 台网数据解析。
 *
 * 已实测确认的字段（速报目录 https://api.wolfx.jp/cenc_eqlist.json）：
 * time / location / magnitude / depth / latitude / longitude / intensity / EventID。
 *
 * 预警推送（wss://ws-api.wolfx.jp/cenc_eew）的报文官方没有公开逐字段文档，
 * 这里做兼容解析：多个候选键名按顺序尝试，解析失败返回 null 并由调用方记日志，
 * 绝不因为个别字段对不上就让服务崩溃。拿到真实推送后可按日志收紧字段。
 */
object EewParser {

    private val beijing = TimeZone.getTimeZone("Asia/Shanghai")

    /** 解析速报目录：形如 {"No1": {...}, "No2": {...}}，按编号顺序返回。 */
    fun parseCatalog(json: String): List<Quake> {
        val out = mutableListOf<Quake>()
        try {
            val root = JSONObject(json)
            val keys = root.keys().asSequence()
                .filter { it.startsWith("No") }
                .sortedBy { it.removePrefix("No").toIntOrNull() ?: 9999 }
            for (key in keys) {
                parseOne(root.optJSONObject(key) ?: continue)?.let { out.add(it) }
            }
        } catch (_: Exception) {
        }
        return out
    }

    /** 解析单条预警推送报文。 */
    fun parseEew(json: String): Quake? {
        return try {
            parseOne(JSONObject(json))
        } catch (_: Exception) {
            null
        }
    }

    private fun parseOne(o: JSONObject): Quake? {
        val lat = firstDouble(o, "latitude", "lat", "epiLat") ?: return null
        val lon = firstDouble(o, "longitude", "lon", "lng", "epiLon") ?: return null
        val mag = firstDouble(o, "magnitude", "mag", "M") ?: return null
        val time = parseTime(firstString(o, "time", "originTime", "origin_time", "O_TIME"))
        // v1.6.1：实测字段是 "HypoCenter"（首字母大写），旧的 "hypocenter" 小写键匹配不到
        val location = firstString(o, "location", "placeName", "place", "HypoCenter", "hypocenter") ?: "未知震中"
        val depth = firstDouble(o, "depth", "epiDepth")
        val intensity = firstDouble(o, "intensity")?.toInt()
        val id = firstString(o, "EventID", "eventId", "id")
            ?: "eew-$time-${location.hashCode()}"
        // v1.6.1 多数据源：type=sc_eew 是四川局，cenc_eew 是中国地震台网；
        // 目录条目 type 为 reviewed/automatic，来源默认中国地震台网。
        val source = when (firstString(o, "type")) {
            "sc_eew" -> "四川地震局"
            else -> "中国地震台网"
        }
        val reportNum = firstDouble(o, "ReportNum", "reportNum")?.toInt() ?: 0
        val reportTime = parseTimeOrZero(firstString(o, "ReportTime", "reportTime"))
        return Quake(id, time, location, mag, depth, lat, lon, intensity, source, reportNum, reportTime)
    }

    private fun firstString(o: JSONObject, vararg keys: String): String? {
        for (k in keys) {
            val v = o.optString(k, "")
            if (v.isNotEmpty()) return v
        }
        return null
    }

    private fun firstDouble(o: JSONObject, vararg keys: String): Double? {
        for (k in keys) {
            if (!o.isNull(k)) {
                val v = o.optDouble(k, Double.NaN)
                if (!v.isNaN()) return v
            }
        }
        return null
    }

    /** 报告发布时间解析：缺失或解析失败返回 0（未知），不回退到当前时间。 */
    private fun parseTimeOrZero(raw: String?): Long {
        if (raw.isNullOrEmpty()) return 0L
        raw.toLongOrNull()?.let {
            return when {
                it > 1_000_000_000_000L -> it
                it > 1_000_000_000L -> it * 1000
                else -> 0L
            }
        }
        val patterns = listOf(
            "yyyy-MM-dd HH:mm:ss",
            "yyyy-MM-dd'T'HH:mm:ss",
            "yyyy-MM-dd'T'HH:mm:ss.SSS"
        )
        val cleaned = raw.replace("Z", "").substringBefore("+")
        for (p in patterns) {
            try {
                val f = SimpleDateFormat(p, Locale.CHINA)
                f.timeZone = beijing
                return f.parse(cleaned)?.time ?: continue
            } catch (_: Exception) {
            }
        }
        return 0L
    }

    /** 发震时刻解析：北京时间 "yyyy-MM-dd HH:mm:ss"、ISO8601、或 epoch 秒/毫秒。 */
    private fun parseTime(raw: String?): Long {
        if (raw.isNullOrEmpty()) return System.currentTimeMillis()
        raw.toLongOrNull()?.let {
            return when {
                it > 1_000_000_000_000L -> it
                it > 1_000_000_000L -> it * 1000
                else -> System.currentTimeMillis()
            }
        }
        val patterns = listOf(
            "yyyy-MM-dd HH:mm:ss",
            "yyyy-MM-dd'T'HH:mm:ss",
            "yyyy-MM-dd'T'HH:mm:ss.SSS"
        )
        for (p in patterns) {
            try {
                val f = SimpleDateFormat(p, Locale.CHINA)
                f.timeZone = beijing
                return f.parse(raw)?.time ?: continue
            } catch (_: Exception) {
            }
        }
        // ISO 带时区后缀时去掉后缀再按北京时间解析
        val cleaned = raw.replace("Z", "").substringBefore("+")
        for (p in patterns) {
            try {
                val f = SimpleDateFormat(p, Locale.CHINA)
                f.timeZone = beijing
                return f.parse(cleaned)?.time ?: continue
            } catch (_: Exception) {
            }
        }
        return System.currentTimeMillis()
    }
}
