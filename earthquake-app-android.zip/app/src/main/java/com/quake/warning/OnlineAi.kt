package com.quake.warning

import okhttp3.Call
import okhttp3.Callback
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import java.io.IOException
import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import java.util.concurrent.TimeUnit

/**
 * 在线模型分析（无需注册、无需填 Key，直接联网调用）。
 *
 * 用的是免 Key 的免费在线模型接口（Pollinations 文本接口），点开地震详情时
 * 把本次地震的真实数据发过去，由模型现写一段分析。任何失败（无网、超时、
 * 服务异常、返回为空）都返回 null，调用方自动回落到本地规则分析，不影响
 * 详情其他内容。
 *
 * 防编造：提示词明确要求只根据提供的数据分析，不编造伤亡数字、历史地震
 * 或未提供的数据，不知道就写不知道，不做地震预报。历史最大地震与伤亡数据
 * 仍由 AiAnalysis 用 USGS / NOAA 真实数据库查询，不走模型。
 */
object OnlineAi {

    private val client = OkHttpClient.Builder()
        .connectTimeout(10, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .build()

    private val beijing = TimeZone.getTimeZone("Asia/Shanghai")

    /** 在线分析。成功返回模型文本（已裁剪），失败返回 null（调用方回落本地规则）。 */
    fun analyze(quake: Quake, userLat: Double, userLon: Double, cb: (String?) -> Unit) {
        val prompt = buildPrompt(quake, userLat, userLon)
        val encoded = try {
            URLEncoder.encode(prompt, "UTF-8").replace("+", "%20")
        } catch (_: Exception) {
            cb(null)
            return
        }
        val url = "https://text.pollinations.ai/$encoded"
        client.newCall(Request.Builder().url(url).build()).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                cb(null)
            }

            override fun onResponse(call: Call, response: Response) {
                try {
                    val text = response.body?.string()?.trim() ?: ""
                    if (!response.isSuccessful || text.length < 20) {
                        cb(null)
                        return
                    }
                    cb(text.take(2000))
                } catch (_: Exception) {
                    cb(null)
                }
            }
        })
    }

    /** 近 7 天汇总分析：只发真实汇总统计，失败返回 null（调用方回落本地规则汇总）。 */
    fun analyzeAggregate(statsText: String, cb: (String?) -> Unit) {
        val prompt = "你是一位地震科普助手。请只根据下面提供的近7天中国地震真实统计数据，" +
            "用简洁中文分点分析，200字以内。要求：不要编造任何伤亡数字、历史地震或未提供的数据；" +
            "不知道的就写不知道；不要做地震预报。" +
            "分析内容：1 近7天地震活动总体特点；2 震级分布特点；3 最活跃的地区；4 给公众的关注建议。" +
            "数据：$statsText。" +
            "结尾写一句：以上分析由在线模型按近7天的公开地震数据生成，仅供参考，不构成预报。"
        val encoded = try {
            URLEncoder.encode(prompt, "UTF-8").replace("+", "%20")
        } catch (_: Exception) {
            cb(null)
            return
        }
        val url = "https://text.pollinations.ai/$encoded"
        client.newCall(Request.Builder().url(url).build()).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                cb(null)
            }

            override fun onResponse(call: Call, response: Response) {
                try {
                    val text = response.body?.string()?.trim() ?: ""
                    if (!response.isSuccessful || text.length < 20) {
                        cb(null)
                        return
                    }
                    cb(text.take(2000))
                } catch (_: Exception) {
                    cb(null)
                }
            }
        })
    }

    private fun buildPrompt(quake: Quake, userLat: Double, userLon: Double): String {
        val timeText = SimpleDateFormat("yyyy年MM月dd日HH时mm分", Locale.CHINA).apply {
            timeZone = beijing
        }.format(Date(quake.timeMillis))
        val depthText = quake.depthKm?.let { "${it.toInt()}千米" } ?: "未公布"
        val epiText = quake.intensity?.let { "${it}度（台网数据）" } ?: "未公布"
        val distText = if (userLat != 0.0 || userLon != 0.0) {
            val d = QuakeMath.distanceKm(userLat, userLon, quake.latitude, quake.longitude)
            "距用户约${d.toInt()}公里"
        } else {
            "用户未设置监测城市，距离未知"
        }
        return "你是一位地震科普助手。请只根据下面提供的真实数据，用简洁中文分点分析这场地震，200字以内。" +
            "要求：不要编造任何伤亡数字、历史地震或未提供的数据；不知道的就写不知道；不要做地震预报。" +
            "分析内容：1 震级定性；2 震源深浅的影响；3 对用户所在地的影响；4 余震可能性（说明是经验判断、非预报）；5 应对建议。" +
            "数据：震级${quake.magnitude}级；地点：${quake.location}；发震时间：$timeText；震源深度：$depthText；震中烈度：$epiText；$distText。" +
            "结尾写一句：以上分析由在线模型按本次地震的公开数据生成，仅供参考，不构成预报。"
    }
}
