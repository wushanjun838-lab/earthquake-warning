package com.quake.warning

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.location.LocationManager
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.Spinner
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * “我的”二级页面：一个 Activity 按 page 参数渲染 11 个子页
 * （预警设置 / 提醒方式 / 播报预览 / 预警记录 / 震感记录 / 避难场所 /
 * 家庭联系人 / 家庭安全自查 / 帮助与支持 / 应急指南 / 关于）。
 * 一次只看一组，返回即回到“我的”列表。
 */
class MyPageActivity : AppCompatActivity() {

    private lateinit var pageContent: LinearLayout
    private var dark = true
    private var mandarinTts: MandarinTts? = null

    private val magOptions = listOf("不限", "3.0级", "4.0级", "4.5级", "5.0级", "6.0级")
    private val intensityOptions = listOf("不限", "2度", "3度", "4度", "5度", "6度", "7度")
    private val leadOptions = listOf("5秒", "10秒", "30秒", "60秒", "120秒")

    private fun tc1(): Int = if (dark) 0xFFFFFFFF.toInt() else 0xFF1A2E1A.toInt()
    private fun tc2(): Int = if (dark) 0xFFA8C4A0.toInt() else 0xFF4A6B4A.toInt()
    private fun cardBg(): Int = if (dark) R.drawable.glass_dark else R.drawable.glass_card_light

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_mypage)
        dark = LocalStore.isDark(this)
        if (!dark) {
            findViewById<LinearLayout>(R.id.rootPage).setBackgroundResource(R.drawable.bg_light)
        }
        pageContent = findViewById(R.id.pageContent)
        val page = intent.getStringExtra("page") ?: "settings"
        val title = when (page) {
            "settings" -> "预警设置"
            "remind" -> "提醒方式"
            "preview" -> "播报预览"
            "history" -> "预警记录"
            "felt" -> "震感记录"
            "shelter" -> "避难场所"
            "contacts" -> "家庭联系人"
            "safety" -> "家庭安全自查"
            "help" -> "帮助与支持"
            "guide" -> "应急指南"
            "about" -> "关于"
            else -> "设置"
        }
        findViewById<TextView>(R.id.tvPageTitle).text = title
        findViewById<Button>(R.id.btnBack).setOnClickListener { finish() }
        when (page) {
            "settings" -> buildSettings()
            "remind" -> buildRemind()
            "preview" -> buildPreview()
            "history" -> buildHistory()
            "felt" -> buildFelt()
            "shelter" -> buildShelter()
            "contacts" -> buildContacts()
            "safety" -> buildSafety()
            "help" -> buildHelp()
            "guide" -> buildGuide()
            "about" -> buildAbout()
        }
    }

    // ---------------- 小组件 ----------------

    private fun card(): LinearLayout {
        val c = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundResource(cardBg())
            val pad = (16 * resources.displayMetrics.density).toInt()
            setPadding(pad, pad, pad, pad)
            val lp = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
            lp.bottomMargin = (12 * resources.displayMetrics.density).toInt()
            layoutParams = lp
        }
        pageContent.addView(c)
        return c
    }

    private fun title(parent: LinearLayout, text: String): TextView {
        return TextView(this).apply {
            this.text = text
            textSize = 16f
            setTypeface(null, android.graphics.Typeface.BOLD)
            setTextColor(tc1())
            parent.addView(this)
        }
    }

    private fun body(parent: LinearLayout, text: String): TextView {
        return TextView(this).apply {
            this.text = text
            textSize = 14f
            setTextColor(tc2())
            val lp = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
            lp.topMargin = (6 * resources.displayMetrics.density).toInt()
            layoutParams = lp
            parent.addView(this)
        }
    }

    private fun actionButton(parent: LinearLayout, text: String, onClick: () -> Unit): Button {
        // v1.5 统一小按钮：15sp 字，上下 10dp 内边距，最小高 44dp，全 App 一致
        val d = resources.displayMetrics.density
        return Button(this).apply {
            this.text = text
            textSize = 15f
            setBackgroundResource(R.drawable.btn_glass_gray)
            setTextColor(0xFFFFFFFF.toInt())
            setPadding((20 * d).toInt(), (10 * d).toInt(), (20 * d).toInt(), (10 * d).toInt())
            minHeight = (44 * d).toInt()
            setOnClickListener { onClick() }
            val lp = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
            lp.topMargin = (8 * resources.displayMetrics.density).toInt()
            layoutParams = lp
            parent.addView(this)
        }
    }

    private fun switchRow(
        parent: LinearLayout,
        text: String,
        checked: Boolean,
        onChange: (Boolean) -> Unit
    ): Switch {
        return Switch(this).apply {
            this.text = text
            isChecked = checked
            setTextColor(tc1())
            setOnCheckedChangeListener { _, v -> onChange(v) }
            val lp = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
            lp.topMargin = (8 * resources.displayMetrics.density).toInt()
            layoutParams = lp
            parent.addView(this)
        }
    }

    private fun setupSpinner(spinner: Spinner, items: List<String>) {
        spinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, items).apply {
            setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        }
    }

    private fun prefs() = getSharedPreferences("prefs", Context.MODE_PRIVATE)

    // ---------------- 预警设置 ----------------

    private fun buildSettings() {
        val c = card()
        title(c, "监测开关")
        val wanted = prefs().getBoolean("service_wanted", true)
        switchRow(c, "预警监测（开启后常驻后台）", wanted) { on ->
            prefs().edit().putBoolean("service_wanted", on).apply()
            if (on) {
                ContextCompat.startForegroundService(
                    this, Intent(this, WarningService::class.java)
                )
                Toast.makeText(this, "预警服务已启动", Toast.LENGTH_SHORT).show()
            } else {
                stopService(Intent(this, WarningService::class.java))
                Toast.makeText(this, "预警服务已停止", Toast.LENGTH_SHORT).show()
            }
        }
        body(c, "监测默认自动开启。关闭后不再接收实时预警，直到重新打开。")

        val loc = card()
        title(loc, "我的位置（默认 GPS 自动定位；也可手动选城市覆盖）")
        val spinnerCity = Spinner(this).apply { loc.addView(this) }
        setupSpinner(
            spinnerCity,
            listOf("请选择城市（或用GPS/手动填经纬度）") + CityData.cities.map { it.name }
        )
        val savedCity = prefs().getString("user_city", "") ?: ""
        val cityIndex = CityData.cities.indexOfFirst { it.name == savedCity }
        if (cityIndex >= 0) spinnerCity.setSelection(cityIndex + 1)
        // 手动选城市 / 手动填经纬度 = 覆盖 GPS 自动定位（location_source = "manual"）；
        // 用 GPS 定位并保存 = 回到自动定位（location_source = "gps"）。
        var locFromGps = false
        val etLat = EditText(this).apply {
            hint = "纬度，如 30.57"
            inputType = android.text.InputType.TYPE_CLASS_NUMBER or
                android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL or
                android.text.InputType.TYPE_NUMBER_FLAG_SIGNED
            setTextColor(tc1())
            setHintTextColor(tc2())
            loc.addView(this)
        }
        val etLon = EditText(this).apply {
            hint = "经度，如 104.07"
            inputType = android.text.InputType.TYPE_CLASS_NUMBER or
                android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL or
                android.text.InputType.TYPE_NUMBER_FLAG_SIGNED
            setTextColor(tc1())
            setHintTextColor(tc2())
            loc.addView(this)
        }
        etLat.setText(prefs().getFloat("user_lat", 0f).takeIf { it != 0f }?.toString() ?: "")
        etLon.setText(prefs().getFloat("user_lon", 0f).takeIf { it != 0f }?.toString() ?: "")
        // 手动改经纬度 = 手动定位（useGps/选城市填入时也会触发，之后由按钮再纠正）
        val manualWatcher = object : android.text.TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: android.text.Editable?) { locFromGps = false }
        }
        etLat.addTextChangedListener(manualWatcher)
        etLon.addTextChangedListener(manualWatcher)
        spinnerCity.onItemSelectedListener =
            object : android.widget.AdapterView.OnItemSelectedListener {
                override fun onItemSelected(
                    parent: android.widget.AdapterView<*>?, view: View?,
                    position: Int, id: Long
                ) {
                    if (position > 0) {
                        val city = CityData.cities[position - 1]
                        etLat.setText(city.lat.toString())
                        etLon.setText(city.lon.toString())
                        locFromGps = false
                        // 手动选城市立即生效（城市名 + 经纬度 + 覆盖标记一次写好）
                        prefs().edit()
                            .putString("user_city", city.name)
                            .putFloat("user_lat", city.lat.toFloat())
                            .putFloat("user_lon", city.lon.toFloat())
                            .putString("location_source", "manual")
                            .apply()
                    }
                }

                override fun onNothingSelected(parent: android.widget.AdapterView<*>?) {}
            }
        actionButton(loc, "用 GPS 定位") { if (useGps(etLat, etLon)) locFromGps = true }
        actionButton(loc, "保存位置") {
            prefs().edit()
                .putFloat("user_lat", etLat.text.toString().toFloatOrNull() ?: 0f)
                .putFloat("user_lon", etLon.text.toString().toFloatOrNull() ?: 0f)
                .putString("location_source", if (locFromGps) "gps" else "manual")
                .apply()
            Toast.makeText(this, "位置已保存", Toast.LENGTH_SHORT).show()
        }

        val th = card()
        title(th, "预警阈值")
        val spinnerMag = Spinner(this).apply { th.addView(this) }
        setupSpinner(spinnerMag, magOptions)
        spinnerMag.setSelection(
            magOptions.indexOf(prefs().getString("mag_label", "不限") ?: "不限").coerceAtLeast(0)
        )
        val spinnerIntensity = Spinner(this).apply { th.addView(this) }
        setupSpinner(spinnerIntensity, intensityOptions)
        spinnerIntensity.setSelection(
            intensityOptions.indexOf(
                prefs().getString("intensity_label", "不限") ?: "不限"
            ).coerceAtLeast(0)
        )
        val spinnerLead = Spinner(this).apply { th.addView(this) }
        setupSpinner(spinnerLead, leadOptions)
        spinnerLead.setSelection(
            leadOptions.indexOf(prefs().getString("lead_label", "5秒") ?: "5秒").coerceAtLeast(0)
        )
        body(th, "震级阈值：低于此震级不报警；烈度阈值：低于此烈度不报警；" +
            "提前时间：S 波到达还剩至少这么久才报警（设 5 秒≈几乎都报）。")
        actionButton(th, "保存阈值") {
            val magLabel = spinnerMag.selectedItem as String
            val intensityLabel = spinnerIntensity.selectedItem as String
            val leadLabel = spinnerLead.selectedItem as String
            prefs().edit()
                .putFloat(
                    "min_mag",
                    if (magLabel == "不限") 0f else magLabel.removeSuffix("级").toFloat()
                )
                .putInt(
                    "min_intensity",
                    if (intensityLabel == "不限") 0 else intensityLabel.removeSuffix("度").toInt()
                )
                .putInt("min_lead_sec", leadLabel.removeSuffix("秒").toInt())
                .putString("mag_label", magLabel)
                .putString("intensity_label", intensityLabel)
                .putString("lead_label", leadLabel)
                .apply()
            Toast.makeText(this, "阈值已保存", Toast.LENGTH_SHORT).show()
        }
    }

    private fun useGps(etLat: EditText, etLon: EditText): Boolean {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
            != PackageManager.PERMISSION_GRANTED
        ) {
            ActivityCompat.requestPermissions(
                this, arrayOf(Manifest.permission.ACCESS_FINE_LOCATION), 100
            )
            Toast.makeText(this, "请先允许位置权限，再点一次 GPS 定位", Toast.LENGTH_LONG).show()
            return false
        }
        val lm = getSystemService(Context.LOCATION_SERVICE) as LocationManager
        val loc = try {
            lm.getLastKnownLocation(LocationManager.GPS_PROVIDER)
                ?: lm.getLastKnownLocation(LocationManager.NETWORK_PROVIDER)
        } catch (_: SecurityException) {
            null
        }
        if (loc != null) {
            etLat.setText(loc.latitude.toString())
            etLon.setText(loc.longitude.toString())
            Toast.makeText(this, "已获取 GPS 位置", Toast.LENGTH_SHORT).show()
            return true
        } else {
            Toast.makeText(this, "未获取到 GPS，请手动选城市或填经纬度", Toast.LENGTH_LONG).show()
            return false
        }
    }

    // ---------------- 提醒方式 ----------------

    private fun buildRemind() {
        val c = card()
        title(c, "语音与提醒")
        switchRow(c, "语音播报", prefs().getBoolean("voice_on", true)) { on ->
            prefs().edit().putBoolean("voice_on", on).apply()
        }
        switchRow(c, "新地震语音播报（≥3.0级）", prefs().getBoolean("voice_new_quake_on", true)) { on ->
            prefs().edit().putBoolean("voice_new_quake_on", on).apply()
        }
        switchRow(c, "未达预警地震通知（≥3.0级）", prefs().getBoolean("notify_non_alert_on", true)) { on ->
            prefs().edit().putBoolean("notify_non_alert_on", on).apply()
        }
        body(c, "未达预警的地震：台网发布 3.0 级以上、但未达到报警阈值的新地震时，" +
            "发一条状态栏通知（震中、震级、距你多远、预计烈度），并按上面“新地震语音播报”开关播报；" +
            "达到报警阈值时仍按预警弹窗报警，不重复通知。")
        // 倒计时语音（v1.4 预录普通话语音包）：女声 / 男声 / 系统语音
        title(c, "倒计时语音")
        val spinnerVoice = Spinner(this).apply { c.addView(this) }
        val voiceOptions = listOf("女声（预录普通话）", "男声（预录普通话）", "系统语音")
        setupSpinner(spinnerVoice, voiceOptions)
        spinnerVoice.setSelection(
            when (LocalStore.voicePack(this)) {
                "male" -> 1
                "system" -> 2
                else -> 0
            }
        )
        spinnerVoice.onItemSelectedListener =
            object : android.widget.AdapterView.OnItemSelectedListener {
                override fun onItemSelected(
                    parent: android.widget.AdapterView<*>?, view: View?,
                    position: Int, id: Long
                ) {
                    val v = when (position) {
                        1 -> "male"
                        2 -> "system"
                        else -> "female"
                    }
                    if (LocalStore.voicePack(this@MyPageActivity) != v) {
                        LocalStore.setVoicePack(this@MyPageActivity, v)
                        Toast.makeText(
                            this@MyPageActivity, "倒计时语音已切换",
                            Toast.LENGTH_SHORT
                        ).show()
                    }
                }
                override fun onNothingSelected(parent: android.widget.AdapterView<*>?) {}
            }
        body(c, "倒计时报数、“地震预警”、“地震到达”用预录的普通话语音包播放，" +
            "不依赖手机系统语音，绝不会播成粤语；选“系统语音”时改用本机 TTS" +
            "（无普通话语音时改蜂鸣）。倒计时超过 60 秒的部分语音包没录，" +
            "用系统普通话顶着。")
        actionButton(c, "试听倒计时语音") {
            val pack = LocalStore.voicePack(this)
            if (pack == "system") {
                Toast.makeText(this, "当前是系统语音，试听请用“播报预览”", Toast.LENGTH_SHORT).show()
            } else {
                // 依次试听“地震预警”→“10秒”→“地震到达”，播完自动释放
                VoicePackPlayer(this, pack).playPreview()
            }
        }
        switchRow(c, "警报声", LocalStore.soundOn(this)) { on ->
            LocalStore.setSoundOn(this, on)
        }
        switchRow(c, "震动", LocalStore.vibrateOn(this)) { on ->
            LocalStore.setVibrateOn(this, on)
        }
        val tvVoice = body(c, "正在检查本机普通话语音…")
        mandarinTts = MandarinTts(this).also { tts ->
            tts.init { found ->
                runOnUiThread {
                    tvVoice.text = if (found) {
                        "普通话语音：本机已找到“${tts.currentVoiceName() ?: "普通话"}”，" +
                            "系统语音模式下播报用普通话。"
                    } else {
                        "本机未安装普通话语音，地名播报将联网合成；" +
                            "倒计时为内置普通话语音包，不受影响。"
                    }
                }
            }
        }
        body(c, "全部播报都只用普通话，绝不会播粤语：倒计时与固定短语用内置" +
            "普通话语音包；地名用在线普通话合成（有缓存的直接播，没网时跳过地名" +
            "只报震级和体感）；系统语音只在选“系统语音”时用，且只认大陆普通话，" +
            "没有时改蜂鸣。")

        val ap = card()
        title(ap, "外观")
        val spinnerAp = Spinner(this).apply { ap.addView(this) }
        val apOptions = listOf("深色（默认）", "浅色", "跟随系统")
        setupSpinner(spinnerAp, apOptions)
        spinnerAp.setSelection(
            when (LocalStore.appearance(this)) {
                "light" -> 1
                "system" -> 2
                else -> 0
            }
        )
        spinnerAp.onItemSelectedListener =
            object : android.widget.AdapterView.OnItemSelectedListener {
                override fun onItemSelected(
                    parent: android.widget.AdapterView<*>?, view: View?,
                    position: Int, id: Long
                ) {
                    val v = when (position) {
                        1 -> "light"
                        2 -> "system"
                        else -> "dark"
                    }
                    // 未设置过外观时默认深色，不算“改过”，不弹提示
                    val current = LocalStore.appearance(this@MyPageActivity)
                        .ifEmpty { "dark" }
                    if (current != v) {
                        LocalStore.setAppearance(this@MyPageActivity, v)
                        Toast.makeText(
                            this@MyPageActivity, "外观已切换，返回首页生效",
                            Toast.LENGTH_SHORT
                        ).show()
                    }
                }

                override fun onNothingSelected(parent: android.widget.AdapterView<*>?) {}
            }

        val rm = card()
        title(rm, "减少动态")
        switchRow(rm, "减少动态（播报条停滚、动效关闭）", LocalStore.reducedMotion(this)) { on ->
            LocalStore.setReducedMotion(this, on)
        }
    }

    // ---------------- 播报预览 ----------------

    private fun buildPreview() {
        val c = card()
        title(c, "播报预览")
        body(c, "地震预警，四川宜宾发生5.2级地震，S波将于32秒后到达，" +
            "请立即避险，远离建筑物和坠物，找坚固家具躲避。")
        body(c, "读秒节奏：10 秒开外每 2 秒读一下，最后 10 秒每秒读；" +
            "S 波到达后强提示音持续 20 秒。")
        actionButton(c, "播放预览（普通话）") {
            mandarinTts?.shutdown()
            mandarinTts = MandarinTts(this).also { tts ->
                tts.init { found ->
                    if (!found) {
                        Toast.makeText(
                            this, "本机无普通话语音，改用蜂鸣提示",
                            Toast.LENGTH_LONG
                        ).show()
                    }
                    tts.speak(
                        "地震预警，四川宜宾发生5.2级地震，S波将于32秒后到达，" +
                            "请立即避险，远离建筑物和坠物，找坚固家具躲避。"
                    )
                }
            }
        }
        actionButton(c, "测试预警（模拟一次报警）") {
            val intent = Intent(this, AlertActivity::class.java).apply {
                putExtra("test", true)
                putExtra("voice", prefs().getBoolean("voice_on", true))
            }
            startActivity(intent)
        }
    }

    // ---------------- 预警记录 ----------------

    private fun buildHistory() {
        val arr = LocalStore.alertHistory(this)
        if (arr.length() == 0) {
            val c = card()
            body(c, "暂无预警记录")
            return
        }
        val fmt = SimpleDateFormat("MM-dd HH:mm", Locale.CHINA)
        for (i in arr.length() - 1 downTo 0) {
            val o = arr.optJSONObject(i) ?: continue
            val c = card()
            // v1.6.1：播报记录分三种——真实预警 / 地震通知（未达预警）/ 测试预览，
            // 并显示数据来源与第几报；老记录没有 kind/source 字段，按原样显示
            val kind = o.optString("kind").ifEmpty {
                if (o.optString("type") == "test") "test" else "warning"
            }
            val label = when (kind) {
                "test" -> "测试预览"
                "notification" -> "地震通知"
                else -> "真实预警"
            }
            val sourceSuffix = buildString {
                val src = o.optString("source")
                if (src.isNotEmpty()) append(" · $src")
                val rn = o.optInt("reportNum", 0)
                if (rn > 0) append(" 第${rn}报")
            }
            val lead = o.optInt("leadSec", -1)
            title(c, "$label · ${o.optString("location")} ${o.optDouble("magnitude")}级")
            body(c, if (kind == "notification") {
                fmt.format(Date(o.optLong("time"))) + "  ·  未达预警阈值$sourceSuffix"
            } else if (lead >= 0) {
                fmt.format(Date(o.optLong("time"))) +
                    "  ·  提前 ${lead} 秒报警$sourceSuffix"
            } else {
                fmt.format(Date(o.optLong("time"))) + sourceSuffix
            })
        }
        // v1.5：清空记录按钮不套灰色卡片背景，直接放在页面上
        actionButton(pageContent, "清空记录") {
            LocalStore.clearAlertHistory(this)
            Toast.makeText(this, "已清空", Toast.LENGTH_SHORT).show()
            recreate()
        }
    }

    // ---------------- 震感记录 ----------------

    private fun buildFelt() {
        val arr = LocalStore.feltReports(this)
        if (arr.length() == 0) {
            val c = card()
            body(c, "暂无震感记录。在地震详情里点“我有震感”可以记录。")
            return
        }
        val fmt = SimpleDateFormat("MM-dd HH:mm", Locale.CHINA)
        val levelText = mapOf(0 to "无感", 1 to "轻微震感", 2 to "强烈震感")
        for (i in arr.length() - 1 downTo 0) {
            val o = arr.optJSONObject(i) ?: continue
            val c = card()
            title(c, "${o.optString("location")} ${o.optDouble("magnitude")}级")
            body(c, "${levelText[o.optInt("level")] ?: ""}  ·  " +
                fmt.format(Date(o.optLong("time"))))
        }
    }

    // ---------------- 避难场所 ----------------

    private fun buildShelter() {
        val c = card()
        title(c, "附近应急避难场所")
        body(c, "打开高德地图，按当前位置搜索应急避难广场；" +
            "请以地图与现场标识为准。")
        actionButton(c, "在地图中查看附近避难场所") {
            val lat = prefs().getFloat("user_lat", 0f).toDouble()
            val lon = prefs().getFloat("user_lon", 0f).toDouble()
            val url = if (lat != 0.0 || lon != 0.0) {
                "https://uri.amap.com/search?keyword=" +
                    URLEncoder.encode("应急避难广场", "UTF-8") +
                    "&center=$lon,$lat"
            } else {
                "https://uri.amap.com/search?keyword=" +
                    URLEncoder.encode("应急避难广场", "UTF-8")
            }
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
        }
    }

    // ---------------- 家庭联系人 ----------------

    private fun buildContacts() {
        val list = card()
        title(list, "家庭应急联系人")
        val arr = LocalStore.contacts(this)
        if (arr.length() == 0) {
            body(list, "还没有联系人，在下面添加。")
        }
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                list.addView(this)
            }
            TextView(this).apply {
                text = "${o.optString("name")}  ${o.optString("phone")}"
                textSize = 15f
                setTextColor(tc1())
                val lp = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                layoutParams = lp
                row.addView(this)
            }
            // v1.6.2：联系人按钮改用深色毛玻璃（白字）
            Button(this).apply {
                text = "拨打"
                textSize = 13f
                setTextColor(0xFFFFFFFF.toInt())
                setBackgroundResource(R.drawable.btn_glass_gray)
                val d = resources.displayMetrics.density
                setPadding((12 * d).toInt(), (6 * d).toInt(), (12 * d).toInt(), (6 * d).toInt())
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                ).apply { marginEnd = (6 * d).toInt() }
                setOnClickListener {
                    startActivity(
                        Intent(
                            Intent.ACTION_DIAL,
                            Uri.parse("tel:${o.optString("phone")}")
                        )
                    )
                }
                row.addView(this)
            }
            Button(this).apply {
                text = "删除"
                textSize = 13f
                setTextColor(0xFFFFFFFF.toInt())
                setBackgroundResource(R.drawable.btn_glass_gray)
                val d = resources.displayMetrics.density
                setPadding((12 * d).toInt(), (6 * d).toInt(), (12 * d).toInt(), (6 * d).toInt())
                setOnClickListener {
                    LocalStore.removeContact(this@MyPageActivity, i)
                    recreate()
                }
                row.addView(this)
            }
        }
        val add = card()
        title(add, "添加联系人")
        val etName = EditText(this).apply {
            hint = "姓名，如：妈妈"
            setTextColor(tc1())
            setHintTextColor(tc2())
            add.addView(this)
        }
        val etPhone = EditText(this).apply {
            hint = "电话"
            inputType = android.text.InputType.TYPE_CLASS_PHONE
            setTextColor(tc1())
            setHintTextColor(tc2())
            add.addView(this)
        }
        actionButton(add, "添加") {
            val name = etName.text.toString().trim()
            val phone = etPhone.text.toString().trim()
            if (name.isEmpty() || phone.isEmpty()) {
                Toast.makeText(this, "姓名和电话都要填", Toast.LENGTH_SHORT).show()
                return@actionButton
            }
            LocalStore.addContact(this, name, phone)
            Toast.makeText(this, "已添加", Toast.LENGTH_SHORT).show()
            recreate()
        }
    }

    // ---------------- 家庭安全自查 ----------------

    private fun buildSafety() {
        val c = card()
        title(c, "家庭安全自查")
        val tvProgress = body(c, "")
        val updateProgress = {
            tvProgress.text = "已完成 ${LocalStore.safetyProgress(this)}/" +
                "${LocalStore.SAFETY_ITEMS.size} 项"
        }
        updateProgress()
        for (i in LocalStore.SAFETY_ITEMS.indices) {
            CheckBox(this).apply {
                text = LocalStore.SAFETY_ITEMS[i]
                isChecked = LocalStore.safetyChecked(this@MyPageActivity, i)
                setTextColor(tc1())
                setOnCheckedChangeListener { _, v ->
                    LocalStore.setSafetyChecked(this@MyPageActivity, i, v)
                    updateProgress()
                }
                c.addView(this)
            }
        }
        body(c, "逐项打勾，进度保存在本机。")
    }

    // ---------------- 帮助与支持 ----------------

    private fun buildHelp() {
        val faqs = listOf(
            "监测是怎么工作的？" to
                "App 常驻后台，直连中国地震台网预警推送通道；推送一到就按你的位置、" +
                "震级、烈度、提前时间算 S 波到达，满足条件立刻全屏报警。推送断开时自动" +
                "每 30 秒轮询速报目录兜底，并自动重连。",
            "为什么近震可能来不及预警？" to
                "离震中太近的地震，S 波可能几秒就到甚至已经到了，预警时间可能为 0，" +
                "这是所有预警系统的物理极限，不是 App 的问题。",
            "息屏、锁屏能收到预警吗？" to
                "能。本 App 是原生前台服务，息屏也在后台连着推送通道，预警一到就亮屏" +
                "全屏弹出。注意要在手机设置里给电池“无限制”、允许自启动和锁屏显示，" +
                "否则系统可能杀掉后台服务。",
            "手机系统自带的地震预警怎么开？" to
                "华为/荣耀：设置→安全→应急预警通知→地震预警；小米：手机管家→家人关怀→" +
                "地震预警；OPPO：设置→安全→SOS紧急联络→自然灾害警报→地震警报；" +
                "vivo：天气 App→设置→地震预警。建议系统预警 + 本 App 双保险。",
            "播报为什么有时是蜂鸣？" to
                "语音强制只认大陆普通话；本机没有普通话语音数据时，绝不会用粤语凑数，" +
                "改用蜂鸣代替读秒。请在手机设置→文字转语音中下载普通话语音数据。",
            "天气灾害预警是官方预警吗？" to
                "不是。播报条里的天气灾害预警是按公开天气预报阈值推算的提示，" +
                "不是气象部门正式发布的预警信号，请以官方发布为准。",
            "避难场所怎么找？" to
                "“我的 > 避难场所”打开高德地图按当前位置搜索应急避难广场；" +
                "没有官方统一的本地避难场所名录，请以地图与现场标识为准。",
            "数据来源" to
                "地震数据：中国地震台网速报目录与预警推送（经 Wolfx 开放接口中转）；" +
                "天气：Open-Meteo；历史地震：美国地质调查局 USGS 地震目录；" +
                "伤亡数据：美国 NOAA/NCEI 全球重大地震数据库。",
            "隐私" to
                "监测位置只存在本机、只用于本地计算与保存；震感记录、联系人、" +
                "自查进度也都只存本机，不上传。"
        )
        for ((q, a) in faqs) {
            val c = card()
            val tvQ = title(c, q)
            val tvA = body(c, a).apply { visibility = View.GONE }
            tvQ.setOnClickListener {
                tvA.visibility = if (tvA.visibility == View.GONE) View.VISIBLE else View.GONE
            }
            body(c, "点问题展开/收起")
        }
    }

    // ---------------- 应急指南 ----------------

    private fun buildGuide() {
        val c1 = card()
        title(c1, "震时躲避")
        body(c1, "· 室内：立即躲到坚固桌下，护住头颈；不要乘电梯，不要跳楼。\n" +
            "· 室外：迅速到空旷处，远离建筑物、电线杆和坠物。\n" +
            "· 开车：减速靠边停车，留在车内，远离高架桥。")
        val c2 = card()
        title(c2, "震后撤离")
        body(c2, "· 震后迅速撤到空旷处，小心余震。\n" +
            "· 闻到燃气异味不要开灯、打电话，关总阀后撤离。\n" +
            "· 不要盲目返回危房，等官方通知。")
        val c3 = card()
        title(c3, "常备物资")
        body(c3, "饮用水、干粮、急救包、充电宝、口哨、重要证件、手电筒、" +
            "保暖毯。定期检查有效期。")
    }

    // ---------------- 关于 ----------------

    private fun buildAbout() {
        val c = card()
        title(c, "中国地震预警")
        body(c, "版本 1.4（原生 App，首页世界地图 + 五页签 + NERV 风预警弹窗 + 预录普通话语音包）\n\n" +
            "给自己手机用的地震预警 App：常驻前台服务，实时连中国地震台网" +
            "预警推送通道，地震一来就全屏报警、倒计时、警报声、震动、普通话播报。\n\n" +
            "本 App 不能替代官方预警。最可靠的一层仍是手机系统自带的地震预警，" +
            "建议系统预警 + 本 App 双保险。")
    }

    override fun onDestroy() {
        mandarinTts?.shutdown()
        super.onDestroy()
    }
}
