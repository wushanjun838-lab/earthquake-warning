package com.quake.warning

import android.content.Context
import android.media.MediaPlayer
import android.os.Handler
import android.os.Looper
import android.util.Log
import java.io.File
import java.io.FileOutputStream
import java.net.URLEncoder
import java.security.MessageDigest
import java.util.concurrent.TimeUnit
import okhttp3.Call
import okhttp3.Callback
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import java.io.IOException

/**
 * 地名/动态语句的在线普通话 TTS（v1.4）。
 *
 * 背景：地名是动态的、没法提前录全；本机系统 TTS 又不可靠（无普通话语音时
 * 会 fallback 到粤语）。改用 Google Translate TTS 非官方接口合成普通话音频：
 * GET https://translate.google.com/translate_tts?ie=UTF-8&q=<URL编码>&tl=zh-CN&client=tw-ob，
 * 带浏览器 User-Agent，返回 MP3（64kbps，24kHz 单声道）。
 *
 * 定位：尽力而为（best-effort），不是关键路径。关键路径（倒计时）是离线的
 * 预录语音包，不依赖网络。地名播报失败时调用方跳过地名、只报语音包能报的
 * 部分，绝不 fallback 到系统 TTS 去赌一把。
 *
 * 缓存：按文本 MD5 存到应用缓存目录 place_tts/place_<md5>.mp3，同一文本只下载一次。
 * 超时：连接 5 秒、读取 8 秒；失败不重试、不阻塞倒计时。
 */
class PlaceNameTts(context: Context) {

    companion object {
        private const val TAG = "PlaceNameTts"
        private const val ENDPOINT = "https://translate.google.com/translate_tts" +
            "?ie=UTF-8&tl=zh-CN&client=tw-ob"
        private const val UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) " +
            "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
        /** 单次请求文本上限（接口约 200 字符，留余量）。 */
        private const val MAX_TEXT_LEN = 180
    }

    private val appContext = context.applicationContext
    private val cacheDir = File(appContext.cacheDir, "place_tts").apply { mkdirs() }
    private val handler = Handler(Looper.getMainLooper())
    private val client = OkHttpClient.Builder()
        .connectTimeout(5, TimeUnit.SECONDS)
        .readTimeout(8, TimeUnit.SECONDS)
        .build()

    private var mediaPlayer: MediaPlayer? = null
    private var currentCall: Call? = null
    @Volatile
    private var released = false

    private fun md5(text: String): String {
        val digest = MessageDigest.getInstance("MD5")
            .digest(text.toByteArray(Charsets.UTF_8))
        return digest.joinToString("") { "%02x".format(it) }
    }

    private fun cacheFile(text: String): File = File(cacheDir, "place_${md5(text)}.mp3")

    /** 该文本是否已有缓存音频（可直接播，无需联网）。 */
    fun isCached(text: String): Boolean {
        val f = cacheFile(text)
        return f.exists() && f.length() > 0
    }

    /**
     * 合成并播放一段中文（普通话）。异步：缓存命中直接播；否则联网下载后播并缓存。
     * 成功播出时 onResult(true)，任何失败（没网、超时、接口报错、音频损坏）时
     * onResult(false)，调用方自行 fallback（语音包报震级 + 体感，跳过地名）。
     * 回调在主线程。
     */
    fun speak(text: String, onResult: ((Boolean) -> Unit)? = null) {
        if (released) {
            onResult?.let { handler.post { it(false) } }
            return
        }
        val clean = text.trim().take(MAX_TEXT_LEN)
        if (clean.isEmpty()) {
            onResult?.let { handler.post { it(false) } }
            return
        }
        val file = cacheFile(clean)
        if (file.exists() && file.length() > 0) {
            playFile(file, onResult)
            return
        }
        val url = ENDPOINT + "&q=" + URLEncoder.encode(clean, "UTF-8")
        val request = Request.Builder().url(url).header("User-Agent", UA).build()
        val call = client.newCall(request)
        currentCall = call
        call.enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                Log.w(TAG, "online tts failed: ${e.message}")
                handler.post { onResult?.invoke(false) }
            }

            override fun onResponse(call: Call, response: Response) {
                try {
                    val bytes = response.body?.bytes()
                    if (!response.isSuccessful || bytes.isNullOrEmpty()) {
                        Log.w(TAG, "online tts bad response: ${response.code}")
                        handler.post { onResult?.invoke(false) }
                        return
                    }
                    try {
                        FileOutputStream(file).use { it.write(bytes) }
                    } catch (_: Exception) {
                        // 缓存写失败不影响本次播放（直接播内存里的字节需要落盘，
                        // 写失败就当失败处理，调用方 fallback）
                        handler.post { onResult?.invoke(false) }
                        return
                    }
                    handler.post { playFile(file, onResult) }
                } catch (e: Exception) {
                    Log.w(TAG, "online tts error: ${e.message}")
                    handler.post { onResult?.invoke(false) }
                }
            }
        })
    }

    private fun playFile(file: File, onResult: ((Boolean) -> Unit)?) {
        if (released) {
            onResult?.invoke(false)
            return
        }
        try {
            stopCurrent()
            val mp = MediaPlayer()
            mediaPlayer = mp
            mp.setDataSource(file.absolutePath)
            mp.setOnPreparedListener { it.start() }
            mp.setOnCompletionListener {
                try {
                    it.release()
                } catch (_: Exception) {
                }
                if (mediaPlayer === it) mediaPlayer = null
                onResult?.invoke(true)
            }
            mp.setOnErrorListener { _, _, _ ->
                try {
                    mp.release()
                } catch (_: Exception) {
                }
                if (mediaPlayer === mp) mediaPlayer = null
                onResult?.invoke(false)
                true
            }
            mp.prepareAsync()
        } catch (_: Exception) {
            onResult?.invoke(false)
        }
    }

    private fun stopCurrent() {
        try {
            mediaPlayer?.stop()
        } catch (_: Exception) {
        }
        try {
            mediaPlayer?.release()
        } catch (_: Exception) {
        }
        mediaPlayer = null
    }

    fun release() {
        released = true
        try {
            currentCall?.cancel()
        } catch (_: Exception) {
        }
        currentCall = null
        handler.removeCallbacksAndMessages(null)
        stopCurrent()
    }
}
