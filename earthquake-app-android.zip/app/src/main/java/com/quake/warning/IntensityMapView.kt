package com.quake.warning

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.DashPathEffect
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Rect
import android.graphics.RectF
import android.util.AttributeSet
import android.view.View
import kotlin.math.cos
import kotlin.math.pow

/** 某城市相对某次地震的预估烈度（MainActivity 的城市震感列表与本图共用）。 */
data class IntensityCity(val city: City, val intensity: Int, val distKm: Double)

/**
 * 烈度地图（v1.7.0）：以某次地震的震中为中心，在夜光地球底图上画 4 圈预估烈度圈。
 *
 * 烈度半径公式（QuakeMath.estimateIntensity 的反函数）：
 *   R_km(I) = 10^((M+1.5−I)/1.5) − 10，截断 ≥0；
 *   I=6 且 M<6 时 R 为负 → 只画震中点（小半径）。
 * 底图用太平洋居中投影裁剪放大，保证 4 度圈落在图内；3 度圈可能超出视图——直接裁剪。
 * 所有烈度数字均为公式估算，非官方发布；图本身是静态数据，不随减少动态开关变化。
 */
class IntensityMapView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : View(context, attrs, defStyleAttr) {

    private var quake: Quake? = null
    private var placeLabel: String = ""
    private var cities: List<IntensityCity> = emptyList()
    private var radiiKm: Map<Int, Double> = emptyMap()

    private val density = resources.displayMetrics.density
    private fun dp(v: Int): Float = v * density

    /** 夜光地球（2000×1000，太平洋居中）；RGB_565 省一半内存，夜景图够用。 */
    private val earthBitmap: Bitmap? by lazy {
        try {
            BitmapFactory.decodeResource(
                resources, R.drawable.earth_night_pacific,
                BitmapFactory.Options().apply { inPreferredConfig = Bitmap.Config.RGB_565 }
            )
        } catch (_: Exception) {
            null
        }
    }

    fun setData(q: Quake?, cities: List<IntensityCity>, radiiKm: Map<Int, Double>, placeLabel: String = "") {
        quake = q
        this.placeLabel = placeLabel
        this.cities = cities
        this.radiiKm = radiiKm
        invalidate()
    }

    // ---- 画笔 ----
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textSize = 11f * density
        typeface = android.graphics.Typeface.DEFAULT_BOLD
        setShadowLayer(dp(2), 0f, 0f, Color.BLACK)
    }
    private val epiTextPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textSize = 11f * density
        typeface = android.graphics.Typeface.DEFAULT_BOLD
    }
    private val epiBgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xB3000000.toInt()
        style = Paint.Style.FILL
    }
    private val epiDotPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFFFF3B30.toInt()
        style = Paint.Style.FILL
    }
    private val epiStrokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        style = Paint.Style.STROKE
        strokeWidth = dp(2)
    }
    private val cityDotPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        style = Paint.Style.FILL
    }
    private val cityStrokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFF93E62A.toInt()
        style = Paint.Style.STROKE
        strokeWidth = 1.5f * density
    }
    private val borderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0x47FFFFFF.toInt()
        style = Paint.Style.STROKE
        strokeWidth = dp(1)
    }
    private val placeholderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFFA8C4A0.toInt()
        textSize = 14f * density
        textAlign = Paint.Align.CENTER
    }

    /** 烈度圈：填充色 / 边框色 / 是否虚线边框。 */
    private data class RingStyle(val fill: Int, val stroke: Int, val dashed: Boolean)

    private val ringStyles = mapOf(
        6 to RingStyle(Color.argb(140, 255, 59, 48), Color.argb(255, 255, 59, 48), false),
        5 to RingStyle(Color.argb(71, 255, 149, 0), Color.argb(255, 255, 149, 0), false),
        4 to RingStyle(Color.argb(36, 245, 197, 66), Color.argb(220, 245, 197, 66), false),
        3 to RingStyle(Color.argb(18, 147, 230, 42), Color.argb(180, 147, 230, 42), true)
    )

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0f || h <= 0f) return
        val corner = dp(16)
        val clip = Path().apply { addRoundRect(RectF(0f, 0f, w, h), corner, corner, Path.Direction.CW) }
        canvas.save()
        canvas.clipPath(clip)
        // 深色底（底图失败时也不留白）
        canvas.drawColor(0xFF0B0F0B.toInt())

        val q = quake
        val bitmap = earthBitmap
        if (q == null) {
            canvas.drawText("暂无数据", w / 2f, h / 2f, placeholderPaint)
            canvas.restore()
            canvas.drawRoundRect(RectF(0f, 0f, w, h), corner, corner, borderPaint)
            return
        }
        if (bitmap == null) {
            canvas.drawText("地图加载失败", w / 2f, h / 2f, placeholderPaint)
            canvas.restore()
            canvas.drawRoundRect(RectF(0f, 0f, w, h), corner, corner, borderPaint)
            return
        }

        // ---- 底图裁剪：太平洋居中投影，震中居中，保证 4 度圈落在图内 ----
        val bw = bitmap.width.toFloat()
        val bh = bitmap.height.toFloat()
        val pxPerDeg = bw / 360f
        val cosLat = cos(Math.toRadians(q.latitude)).coerceAtLeast(0.2)
        val r4 = radiiKm[4] ?: 0.0
        // 可见半宽（km）：4 度圈半径 ×1.15 余量，最小 150km（小震也不至于无限放大）
        val visHalfKm = maxOf(r4 * 1.15, 150.0)
        var srcW = (2 * visHalfKm / (111.32 * cosLat) * pxPerDeg).toFloat()
        var srcH = srcW * h / w
        if (srcW >= bw || srcH >= bh) {
            // 超大震：整幅图都装不下 4 度圈，直接用全图
            srcW = bw
            srcH = bh
        }
        val ex = (((q.longitude - 150 + 540) % 360) / 360.0 * bw).toFloat()
        val ey = ((90 - q.latitude) / 180.0 * bh).toFloat()
        val srcLeft = (ex - srcW / 2f).coerceIn(0f, (bw - srcW).coerceAtLeast(0f))
        val srcTop = (ey - srcH / 2f).coerceIn(0f, (bh - srcH).coerceAtLeast(0f))
        val srcRect = Rect(srcLeft.toInt(), srcTop.toInt(), (srcLeft + srcW).toInt(), (srcTop + srcH).toInt())
        canvas.drawBitmap(bitmap, srcRect, RectF(0f, 0f, w, h), null)

        // 震中在视图里的位置（按实际裁剪矩形换算）与 km→px 比例
        val epiX = (ex - srcLeft) / srcW * w
        val epiY = (ey - srcTop) / srcH * h
        val pxPerKm = w / (srcW / pxPerDeg * 111.32 * cosLat)

        // ---- 烈度圈（先画大的）----
        for (level in listOf(3, 4, 5, 6)) {
            val ringStyle = ringStyles[level] ?: continue
            var rPx = ((radiiKm[level] ?: 0.0) * pxPerKm).toFloat()
            if (rPx <= 0f) {
                if (level != 6) continue
                rPx = dp(12) // 6 度圈不存在时只画震中点
            }
            val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = ringStyle.fill
                style = Paint.Style.FILL
            }
            canvas.drawCircle(epiX, epiY, rPx, fillPaint)
            val strokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = ringStyle.stroke
                style = Paint.Style.STROKE
                strokeWidth = dp(2)
                if (ringStyle.dashed) pathEffect = DashPathEffect(floatArrayOf(dp(8), dp(6)), 0f)
            }
            canvas.drawCircle(epiX, epiY, rPx, strokePaint)
            // 圈度数标签：放在圈右下方 45° 处，太小或出界就不标（图例里有说明）
            if (rPx >= dp(30)) {
                val lx = epiX + rPx * 0.707f
                val ly = epiY + rPx * 0.707f
                if (lx < w - dp(24) && ly < h - dp(8)) {
                    canvas.drawText("${level}度", lx, ly, textPaint)
                }
            }
        }

        // ---- 城市点 + 标签 ----
        for (c in cities) {
            // 经纬度 → 视图坐标（与圈同比例；纬度方向按 110.94 km/度）
            val dxKm = (c.city.lon - q.longitude) * 111.32 * cosLat
            val dyKm = (c.city.lat - q.latitude) * 110.94
            val cx = epiX + (dxKm * pxPerKm).toFloat()
            val cy = epiY - (dyKm * pxPerKm).toFloat()
            if (cx < dp(8) || cx > w - dp(8) || cy < dp(8) || cy > h - dp(8)) continue
            canvas.drawCircle(cx, cy, dp(4), cityDotPaint)
            canvas.drawCircle(cx, cy, dp(4), cityStrokePaint)
            canvas.drawText("${c.city.name} ${c.intensity}度", cx, cy + dp(18), textPaint)
        }

        // ---- 震中点 + 标签 ----
        canvas.drawCircle(epiX, epiY, dp(7), epiDotPaint)
        canvas.drawCircle(epiX, epiY, dp(7), epiStrokePaint)
        val epiLabel = "${if (placeLabel.isEmpty()) q.location else placeLabel} ${q.magnitude} · 震中"
        val tw = epiTextPaint.measureText(epiLabel)
        val tagW = tw + dp(16)
        val tagH = dp(22)
        val tagLeft = (epiX - tagW / 2f).coerceIn(0f, (w - tagW).coerceAtLeast(0f))
        val tagTop = (epiY + dp(12)).coerceAtMost(h - tagH)
        val tagRect = RectF(tagLeft, tagTop, tagLeft + tagW, tagTop + tagH)
        canvas.drawRoundRect(tagRect, dp(8), dp(8), epiBgPaint)
        canvas.drawText(
            epiLabel, tagLeft + dp(8),
            tagTop + tagH / 2f + epiTextPaint.textSize * 0.35f, epiTextPaint
        )

        canvas.restore()
        canvas.drawRoundRect(RectF(0f, 0f, w, h), corner, corner, borderPaint)
    }
}
