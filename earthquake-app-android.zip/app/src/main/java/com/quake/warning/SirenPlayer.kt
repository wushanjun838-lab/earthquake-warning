package com.quake.warning

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import kotlin.math.PI
import kotlin.math.sin

/**
 * 程序生成的强提示音：正弦波警笛（700~1150 Hz 来回扫频），无须任何音频文件，
 * 走闹钟通道，盖过普通提示音。用于 S 波到达后的 20 秒强提示。
 */
class SirenPlayer {

    private var track: AudioTrack? = null
    private var thread: Thread? = null
    @Volatile
    private var running = false

    fun start() {
        if (running) return
        running = true
        val sampleRate = 44100
        val minBuf = AudioTrack.getMinBufferSize(
            sampleRate,
            AudioFormat.CHANNEL_OUT_MONO,
            AudioFormat.ENCODING_PCM_16BIT
        )
        val attrs = AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_ALARM)
            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
            .build()
        val audioTrack = AudioTrack(
            attrs,
            AudioFormat.Builder()
                .setSampleRate(sampleRate)
                .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                .build(),
            minBuf,
            AudioTrack.MODE_STREAM,
            0
        )
        track = audioTrack
        audioTrack.play()
        thread = Thread {
            val buf = ShortArray(1024)
            var phase = 0.0
            var t = 0.0
            while (running) {
                // 0.5 Hz 调制扫频：700 Hz <-> 1150 Hz
                val freq = 925 + 225 * sin(2 * PI * 0.5 * t)
                val step = 2 * PI * freq / sampleRate
                for (i in buf.indices) {
                    buf[i] = (sin(phase) * 12000).toInt().toShort()
                    phase += step
                    if (phase > 2 * PI) phase -= 2 * PI
                }
                try {
                    audioTrack.write(buf, 0, buf.size)
                } catch (_: Exception) {
                    break
                }
                t += buf.size.toDouble() / sampleRate
            }
        }.apply { start() }
    }

    fun stop() {
        running = false
        try {
            thread?.join(500)
        } catch (_: Exception) {
        }
        try {
            track?.stop()
            track?.release()
        } catch (_: Exception) {
        }
        track = null
        thread = null
    }
}
