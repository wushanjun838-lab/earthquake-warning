package com.quake.warning

import android.content.Context
import okhttp3.Call
import okhttp3.Callback
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import org.json.JSONObject
import java.io.IOException
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import kotlin.math.abs

/**
 * 每条地震的 AI 分析（展开详情里，位于速报和地图下方）。
 *
 * 三部分，全部只用真实数据，绝不编造：
 * (a) 智能分析：先由本机按本次地震的真实震级、深度、震中、距监测城市距离、
 *     估算烈度规则生成（标注“本地规则生成”），同时在后台调用免 Key 的免费
 *     在线模型（OnlineAi）按同样真实数据现写一段分析；在线返回后替换显示为
 *     “在线模型生成”并缓存，失败时静默保留本地规则版。提示词要求模型只用
 *     提供的数据、不编造伤亡与历史、不做预报。
 * (b) 历史最大地震：查 USGS 全球地震目录（1900 年至今，震中 200 公里内），
 *     取本次地震之前最大的那场，显示震级/时间/震中/深度；没有则显示
 *     “该区域公开目录内暂无记录”。只在用户点开详情时查询一次，结果缓存。
 * (c) 当时人员伤亡与受灾情况：只用 NOAA/NCEI 全球重大地震数据库里
 *     能对上号的记录（同年、震级差 ≤0.5、距离 ≤100 公里），显示死亡/
 *     受伤/房屋损毁的精确数字并注明来源；对不上或没有精确数字时显示
 *     “暂无公开伤亡数据”。注意：NCEI 部分记录只给量级代码不给精确数字
 *     （例如唐山 1976 年记录），这类一律按“无精确数据”处理，不把量级
 *     代码换算成人数，避免以假乱真。
 *
 * 查询只在点开详情时触发，不阻塞列表和报警；失败时显示可重试的提示，
 * 不影响详情其他内容。
 */
object AiAnalysis {

    const val STATE_LOADING = 0
    const val STATE_OK = 1
    const val STATE_NONE = 2
    const val STATE_FAILED = 3

    data class Result(
        val localAnalysis: String,
        val historyState: Int,
        val historyText: String?,
        val casualtyState: Int,
        val casualtyText: String?
    )

    private val client = OkHttpClient()
    private val beijing = TimeZone.getTimeZone("Asia/Shanghai")

    /** 点开详情时调用。onUpdate 可能被多次调用（先本地分析，后联网结果），均在后台线程。 */
    fun load(
        context: Context,
        quake: Quake,
        userLat: Double,
        userLon: Double,
        onUpdate: (Result) -> Unit
    ) {
        val local = buildLocalAnalysis(quake, userLat, userLon)
        val lock = Any()
        // latest：最近一次发出的 Result；onlineText：在线模型返回的分析（成功时才有）
        var latest: Result? = null
        var onlineText: String? = null

        fun saveCache(r: Result) {
            val online = synchronized(lock) { onlineText }
            try {
                val o = JSONObject().apply {
                    put("historyState", r.historyState)
                    put("historyText", r.historyText ?: "")
                    put("casualtyState", r.casualtyState)
                    put("casualtyText", r.casualtyText ?: "")
                    put("onlineText", online ?: "")
                }
                LocalStore.saveAiCache(context, quake.eventId, o.toString())
            } catch (_: Exception) {
            }
        }

        fun emit(r: Result) {
            synchronized(lock) { latest = r }
            onUpdate(r)
        }

        // 在线模型（免 Key、免注册）：与历史查询并行；成功则把分析文字换成在线版并缓存，
        // 失败静默回落本地规则分析，不影响详情其他内容。
        fun fetchOnline() {
            OnlineAi.analyze(quake, userLat, userLon) { text ->
                if (text == null) return@analyze
                synchronized(lock) {
                    onlineText = text
                    val cur = latest ?: return@analyze
                    val updated = cur.copy(localAnalysis = onlineAnalysisText(text))
                    latest = updated
                    saveCache(updated)
                    onUpdate(updated)
                }
            }
        }

        fun analysisText(): String {
            return synchronized(lock) { onlineText?.let { onlineAnalysisText(it) } } ?: local
        }

        // 先看缓存
        val cached = LocalStore.aiCache(context, quake.eventId)
        if (cached != null) {
            try {
                val o = JSONObject(cached)
                val cachedOnline = o.optString("onlineText").takeIf { it.isNotEmpty() }
                if (cachedOnline != null) synchronized(lock) { onlineText = cachedOnline }
                emit(
                    Result(
                        analysisText(),
                        o.optInt("historyState", STATE_NONE),
                        o.optString("historyText").takeIf { it.isNotEmpty() },
                        o.optInt("casualtyState", STATE_NONE),
                        o.optString("casualtyText").takeIf { it.isNotEmpty() }
                    )
                )
                // 缓存里没有在线分析时，后台补一次在线调用
                if (cachedOnline == null) fetchOnline()
                return
            } catch (_: Exception) {
            }
        }
        emit(Result(local, STATE_LOADING, null, STATE_LOADING, null))
        fetchOnline()
        queryHistory(quake) { histState, histText, hist ->
            if (histState != STATE_OK || hist == null) {
                val r = Result(analysisText(), histState, histText, STATE_NONE, "暂无公开伤亡数据")
                saveCache(r)
                emit(r)
                return@queryHistory
            }
            queryCasualty(hist) { casState, casText ->
                val r = Result(analysisText(), STATE_OK, histText, casState, casText)
                saveCache(r)
                emit(r)
            }
        }
    }

    private fun onlineAnalysisText(text: String): String {
        return "智能分析（在线模型生成）\n$text"
    }

    // ---------------- (a) 本地规则分析 ----------------

    fun buildLocalAnalysis(quake: Quake, userLat: Double, userLon: Double): String {
        val sb = StringBuilder()
        sb.append("智能分析（本地规则生成）\n")
        val mag = quake.magnitude
        sb.append("· 震级定性：")
        sb.append(
            when {
                mag < 3.0 -> "3级以下微震，一般无感。"
                mag < 4.5 -> "3–4.5级有感地震，室内可以察觉，一般不造成破坏。"
                mag < 6.0 -> "4.5–6级中强震，可能造成老旧房屋开裂、物品坠落。"
                mag < 7.0 -> "6–7级强震，破坏性明显。"
                else -> "7级以上大地震，破坏严重。"
            }
        )
        quake.intensity?.let {
            sb.append("\n· 震中烈度：${it}度（台网数据，指震中附近的最大烈度，与你所在地的预计烈度不同）。")
        }
        sb.append("\n· 震源深浅：")
        val depth = quake.depthKm
        sb.append(
            when {
                depth == null -> "台网未公布震源深度。"
                depth < 70 -> "浅源地震（${depth.toInt()}千米），能量更易传到地面，同样震级破坏相对更大。"
                depth <= 300 -> "中源地震（${depth.toInt()}千米）。"
                else -> "深源地震（${depth.toInt()}千米），影响范围广，但地表破坏相对较弱。"
            }
        )
        val hasUserLoc = userLat != 0.0 || userLon != 0.0
        if (hasUserLoc) {
            val dist = QuakeMath.distanceKm(userLat, userLon, quake.latitude, quake.longitude)
            // 本地预计烈度必须由震级+距离算出，绝不能直接用台网的震中烈度
            // （远震震中烈度很高，用户所在地可能完全无感）
            val intensity = QuakeMath.estimateIntensity(mag, dist)
            sb.append("\n· 你所在地：距震中约${dist.toInt()}公里，预计烈度约${intensity}度，")
            sb.append(
                when {
                    intensity >= 7 -> "震感强烈。"
                    intensity >= 5 -> "震感明显。"
                    intensity >= 3 -> "可能有轻微震感。"
                    else -> "基本无感。"
                }
            )
            val arrival = QuakeMath.sArrivalMillis(quake.timeMillis, dist)
            val diffMin = (System.currentTimeMillis() - arrival) / 60000
            if (diffMin >= 0) {
                sb.append("S波已于${diffMin}分钟前到达。")
            } else {
                sb.append("S波将于${-diffMin * 60}秒后到达。")
            }
        } else {
            sb.append("\n· 你所在地：未设置监测城市，无法估算你所在地的震感。")
        }
        sb.append("\n· 余震可能（经验判断，非预报）：")
        sb.append(
            when {
                mag >= 6.0 -> "主震较强，未来数日可能出现较强余震，注意防范。"
                mag >= 4.5 -> "可能有小余震，留意官方后续速报。"
                else -> "余震一般较弱。"
            }
        )
        val intensity = if (hasUserLoc) {
            // 应对建议针对用户所在地：用本地预计烈度，不用震中烈度
            QuakeMath.estimateIntensity(
                mag, QuakeMath.distanceKm(userLat, userLon, quake.latitude, quake.longitude)
            )
        } else 0
        sb.append("\n· 应对建议：")
        sb.append(
            when {
                intensity >= 6 -> "若在室内，立即躲到坚固桌下护住头颈；震后迅速撤到空旷处，远离建筑物和坠物。"
                intensity >= 4 -> "检查家中物品是否坠落，留意燃气异味，关注官方后续速报。"
                else -> "保持冷静，关注官方后续速报即可。"
            }
        )
        sb.append("\n（以上分析由本机按本次地震的公开震级、深度、距离规则生成，仅供参考，不构成预报。）")
        return sb.toString()
    }

    // ---------------- (b) USGS 历史最大地震 ----------------

    private data class HistQuake(
        val mag: Double,
        val timeMillis: Long,
        val place: String,
        val lat: Double,
        val lon: Double,
        val depthKm: Double?
    )

    private fun queryHistory(quake: Quake, cb: (Int, String?, HistQuake?) -> Unit) {
        // 只查本次地震之前，避免把本次地震本身算成“历史最大”
        val cal = Calendar.getInstance(beijing)
        cal.timeInMillis = quake.timeMillis
        cal.add(Calendar.DAY_OF_YEAR, -1)
        val endDate = SimpleDateFormat("yyyy-MM-dd", Locale.CHINA).apply {
            timeZone = beijing
        }.format(cal.time)
        val url = "https://earthquake.usgs.gov/fdsnws/event/1/query?format=geojson" +
            "&latitude=${quake.latitude}&longitude=${quake.longitude}" +
            "&maxradiuskm=200&starttime=1900-01-01&endtime=$endDate" +
            "&orderby=magnitude&limit=1"
        client.newCall(Request.Builder().url(url).build()).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                cb(STATE_FAILED, "历史地震查询失败（网络异常），可稍后重试", null)
            }

            override fun onResponse(call: Call, response: Response) {
                try {
                    val body = response.body?.string() ?: ""
                    val features = JSONObject(body).optJSONArray("features")
                    if (features == null || features.length() == 0) {
                        cb(STATE_NONE, "该区域公开目录内暂无记录", null)
                        return
                    }
                    val f = features.getJSONObject(0)
                    val props = f.getJSONObject("properties")
                    val coords = f.getJSONObject("geometry").optJSONArray("coordinates")
                    val hist = HistQuake(
                        mag = props.optDouble("mag", 0.0),
                        timeMillis = props.optLong("time", 0L),
                        place = props.optString("place", ""),
                        lat = coords?.optDouble(1, 0.0) ?: 0.0,
                        lon = coords?.optDouble(0, 0.0) ?: 0.0,
                        depthKm = coords?.optDouble(2, Double.NaN)
                            ?.takeIf { !it.isNaN() }
                    )
                    val timeText = SimpleDateFormat("yyyy年MM月dd日", Locale.CHINA).apply {
                        timeZone = beijing
                    }.format(Date(hist.timeMillis))
                    val depthText = hist.depthKm?.let { "，深度约${it.toInt()}千米" } ?: ""
                    val placeText = hist.place.ifEmpty { "该区域" }
                    cb(
                        STATE_OK,
                        "该地震之前，震中 200 公里内有记录的最大地震：$timeText，${hist.mag}级，$placeText$depthText。（数据来源：美国地质调查局 USGS 地震目录，1900 年至今）",
                        hist
                    )
                } catch (_: Exception) {
                    cb(STATE_FAILED, "历史地震查询失败（数据解析异常），可稍后重试", null)
                }
            }
        })
    }

    // ---------------- (c) NCEI 伤亡与受灾 ----------------

    private fun queryCasualty(hist: HistQuake, cb: (Int, String?) -> Unit) {
        val year = Calendar.getInstance(beijing).apply {
            timeInMillis = hist.timeMillis
        }.get(Calendar.YEAR)
        val url = "https://www.ngdc.noaa.gov/hazel/hazard-service/api/v1/earthquakes" +
            "?minYear=$year&maxYear=$year" +
            "&minLatitude=${hist.lat - 1.5}&maxLatitude=${hist.lat + 1.5}" +
            "&minLongitude=${hist.lon - 1.5}&maxLongitude=${hist.lon + 1.5}"
        client.newCall(Request.Builder().url(url).build()).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                cb(STATE_FAILED, "伤亡数据查询失败（网络异常），可稍后重试")
            }

            override fun onResponse(call: Call, response: Response) {
                try {
                    val body = response.body?.string() ?: ""
                    val items = JSONObject(body).optJSONArray("items")
                    var best: JSONObject? = null
                    var bestDist = Double.MAX_VALUE
                    if (items != null) {
                        for (i in 0 until items.length()) {
                            val o = items.optJSONObject(i) ?: continue
                            val m = o.optDouble("eqMagnitude", 0.0)
                            if (abs(m - hist.mag) > 0.5) continue
                            val d = QuakeMath.distanceKm(
                                hist.lat, hist.lon,
                                o.optDouble("latitude", 0.0),
                                o.optDouble("longitude", 0.0)
                            )
                            if (d <= 100 && d < bestDist) {
                                bestDist = d
                                best = o
                            }
                        }
                    }
                    if (best == null) {
                        cb(STATE_NONE, "暂无公开伤亡数据")
                        return
                    }
                    val deaths = if (best.isNull("deaths")) null else best.optInt("deaths")
                    val injuries = if (best.isNull("injuries")) null else best.optInt("injuries")
                    val houses = if (best.isNull("housesDestroyed")) null else best.optInt("housesDestroyed")
                    if (deaths == null && injuries == null && houses == null) {
                        // 只有量级代码、没有精确数字时，不换算、不编造
                        cb(STATE_NONE, "暂无公开伤亡数据")
                        return
                    }
                    val name = best.optString("locationName", "")
                    val y = best.optInt("year", year)
                    val parts = mutableListOf<String>()
                    parts.add("当时受灾情况（$y 年，$name）：")
                    if (deaths != null) parts.add("死亡 ${formatNum(deaths)} 人")
                    if (injuries != null) parts.add("受伤 ${formatNum(injuries)} 人")
                    if (houses != null) parts.add("房屋损毁 ${formatNum(houses)} 间")
                    parts.add("（数据来源：美国 NOAA/NCEI 全球重大地震数据库）")
                    cb(STATE_OK, parts.joinToString("；"))
                } catch (_: Exception) {
                    cb(STATE_FAILED, "伤亡数据查询失败（数据解析异常），可稍后重试")
                }
            }
        })
    }

    private fun formatNum(n: Int): String {
        return "%,d".format(Locale.CHINA, n)
    }
}
