package com.quake.warning

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.media.MediaPlayer
import android.media.RingtoneManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.VibrationEffect
import android.os.Vibrator
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.FrameLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.TimeZone

/**
 * 全屏报警页（预警弹窗，v1.4 NERV 风 + 预录普通话语音包）：锁屏也能亮屏弹出，
 * 倒计时 S 波到达，警报声 + 震动 + 普通话读秒播报，直到用户点“我知道了”才停。
 *
 * 语音（v1.4，铁律：绝不播粤语）：
 * - 倒计时报数、“地震预警”、“地震到达”：预录普通话语音包（女声/男声按设置），
 *   不走系统 TTS；倒计时 >60 秒的部分语音包没录，用系统普通话 TTS 顶着
 *   （本机无普通话语音时 MandarinTts 改蜂鸣，绝不 fallback 到粤语）。
 * - 地名播报：在线普通话 TTS（Google Translate TTS，带缓存），不含秒数
 *   （避免播出的秒数过期、避免与倒计时报数重叠）；在线失败时跳过地名，
 *   只报语音包能报的部分，绝不 fallback 到系统 TTS。
 * - 选“系统语音”时：保持原有行为（MandarinTts 白名单 + 蜂鸣 fallback）。
 */
class AlertActivity : AppCompatActivity() {

    private lateinit var tvCountdown: TextView
    private lateinit var tvCountdownUnit: TextView
    private lateinit var tvCountdownLabel: TextView
    private lateinit var tvLocalIntensity: TextView
    private var mediaPlayer: MediaPlayer? = null
    private var vibrator: Vibrator? = null
    private var mandarinTts: MandarinTts? = null
    private var voicePack: VoicePackPlayer? = null
    private var voicePackMode = "female" // female / male / system（“倒计时语音”设置）
    private var placeNameTts: PlaceNameTts? = null
    private var sArrival = 0L
    private var voiceOn = true
    private var soundOn = true
    private var vibrateOn = true
    private var location = ""
    private var magnitude = 0.0
    private var userLat = 0.0
    private var userLon = 0.0
    /** v1.6.1：本场报警的数据来源与第几报（弹窗显示 + 修订广播匹配用）。 */
    private var alertSource = ""
    private var alertReportNum = 0
    private var alertEventKey = ""
    private val handler = Handler(Looper.getMainLooper())
    private var arrivalHandled = false
    private val siren = SirenPlayer()
    private var lastSpokenSecond = -1

    /**
     * 倒计时：每 200 毫秒刷新一次带一位小数的倒计时；
     * 读秒仍按整秒走：>10 秒时每 2 秒读一下，<=10 秒时每秒读。
     */
    private val countdownRunnable = object : Runnable {
        override fun run() {
            val remainMs = sArrival - System.currentTimeMillis()
            if (remainMs > 0) {
                val remainSec = remainMs / 1000.0
                tvCountdown.text = "%.1f".format(Locale.CHINA, remainSec)
                val secInt = Math.ceil(remainSec).toInt()
                if (secInt != lastSpokenSecond) {
                    lastSpokenSecond = secInt
                    if (secInt <= 10 || secInt % 2 == 0) {
                        speakCountdownNumber(secInt)
                    }
                }
                handler.postDelayed(this, 200)
            } else {
                onArrival()
            }
        }
    }

    private val repeatSpeakRunnable = object : Runnable {
        override fun run() {
            speakRepeatSentence()
            handler.postDelayed(this, 30_000)
        }
    }

    /** v1.6.2 倒计时报数：数字绝不走系统 TTS（本机系统 TTS 会把数字读成英文）。
     * 全部走预录普通话语音包：1–60 秒用“X秒”录音；>60 秒按位拼数字录音
     * （res/raw 里没有单独的“秒”录音，拼读时只读数字，如 75 → “七”“五”）；
     * 语音包也失败时不发声（警笛与倒计时画面仍在），绝不回落系统 TTS。 */
    private fun speakCountdownNumber(secInt: Int) {
        if (voicePack == null) {
            // 系统语音模式也要用语音包报数（只用于数字）；其他语音仍走系统
            voicePack = VoicePackPlayer(this, "female")
        }
        voicePack?.playCountdownNumber(secInt)
    }

    /** 30 秒重复提醒：在线普通话 TTS；失败时只报语音包的“地震预警”。 */
    private fun speakRepeatSentence() {
        val text = "地震预警，S波即将到达，请立即避险。"
        if (voicePackMode == "system") {
            mandarinTts?.speak(text)
            return
        }
        if (placeNameTts == null) placeNameTts = PlaceNameTts(this)
        placeNameTts?.speak(text) { ok ->
            if (!ok) voicePack?.playYujing()
        }
    }

    /** S 波到达：强提示音 20 秒，之后恢复普通警报声。 */
    private val resumeAlarmRunnable = Runnable {
        siren.stop()
        startAlarm()
        startVibration()
    }

    private fun onArrival() {
        if (arrivalHandled) return
        arrivalHandled = true
        tvCountdown.text = "已到达"
        tvCountdownUnit.visibility = View.GONE
        tvCountdownLabel.text = "主要动"
        if (voicePackMode == "system") {
            mandarinTts?.speakArrival()
        } else {
            // 预录普通话“地震到达”；警笛随后也会响，语音包万一失败仍有强提示音
            voicePack?.playDaoda()
        }
        try {
            mediaPlayer?.stop()
            mediaPlayer?.release()
        } catch (_: Exception) {
        }
        mediaPlayer = null
        try {
            vibrator?.cancel()
        } catch (_: Exception) {
        }
        if (soundOn) siren.start()
        if (vibrateOn) {
            try {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    vibrator?.vibrate(
                        VibrationEffect.createWaveform(longArrayOf(0, 500, 200, 500), 0)
                    )
                }
            } catch (_: Exception) {
            }
        }
        handler.postDelayed(resumeAlarmRunnable, 20_000)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        @Suppress("DEPRECATION")
        window.addFlags(
            WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED
                or WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON
                or WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON
        )
        setContentView(R.layout.activity_alert)

        tvCountdown = findViewById(R.id.tvCountdown)
        tvCountdownUnit = findViewById(R.id.tvCountdownUnit)
        tvCountdownLabel = findViewById(R.id.tvCountdownLabel)
        tvLocalIntensity = findViewById(R.id.tvLocalIntensity)
        val btnStop: Button = findViewById(R.id.btnStop)

        val prefs = getSharedPreferences("prefs", Context.MODE_PRIVATE)
        userLat = prefs.getFloat("user_lat", 0f).toDouble()
        userLon = prefs.getFloat("user_lon", 0f).toDouble()
        soundOn = LocalStore.soundOn(this)
        vibrateOn = LocalStore.vibrateOn(this)

        location = intent.getStringExtra("location") ?: "某地"
        magnitude = intent.getDoubleExtra("magnitude", 0.0)
        // v1.6.1：数据来源与第几报（WarningService 随报警 intent 传来）
        alertSource = intent.getStringExtra("source") ?: ""
        alertReportNum = intent.getIntExtra("report_num", 0)
        alertEventKey = intent.getStringExtra("event_key") ?: ""
        var depth = intent.getDoubleExtra("depth", -1.0)
        val maxIntensity = intent.getIntExtra("intensity", -1)
        var localIntensity = intent.getIntExtra("local_intensity", -1)
        var epiLat = intent.getDoubleExtra("latitude", 0.0)
        var epiLon = intent.getDoubleExtra("longitude", 0.0)
        var quakeTime = intent.getLongExtra("time", 0L)
        val test = intent.getBooleanExtra("test", false)
        voiceOn = intent.getBooleanExtra("voice", true)
        sArrival = intent.getLongExtra("s_arrival", 0L)
        var targetAreas: String

        if (test) {
            // 测试样例：真实的 2019 年长宁 6.0 级地震（时间/震级/深度/最大烈度为真，
            // 本地预计烈度 4 度与 32.5 秒倒计时为设计样例）
            location = "四川宜宾市长宁县"
            magnitude = 6.0
            depth = 16.0
            localIntensity = 4
            epiLat = 28.34
            epiLon = 104.90
            quakeTime = Calendar.getInstance(TimeZone.getTimeZone("Asia/Shanghai")).apply {
                set(2019, Calendar.JUNE, 17, 22, 55, 43)
                set(Calendar.MILLISECOND, 0)
            }.timeInMillis
            sArrival = System.currentTimeMillis() + 32_500
            targetAreas = "宜宾 · 自贡 · 泸州"
            findViewById<TextView>(R.id.tvPreviewBanner).visibility = View.VISIBLE
        } else {
            targetAreas = deriveTargetAreas(location)
        }

        // 红色横幅
        findViewById<TextView>(R.id.tvAlertTitle).text = "$location 发生地震"
        findViewById<TextView>(R.id.tvAlertSub).text =
            "强烈震动警戒 · 预计强烈震动区域 · $targetAreas"

        // 地图：震中红点 + 震动范围环（按真实经纬度定位，底图经度 73–135、纬度 18–54）
        positionAlertMarker(epiLat, epiLon)
        val shortPlace = location.substringAfterLast("市", location)
            .removeSuffix("县").removeSuffix("市")
            .ifEmpty { location }
        findViewById<TextView>(R.id.tvAlertMapTag).text = "${magnitude}级 $shortPlace"

        // 发布时间（v1.6.1：附上数据来源与第几报，如“中国地震台网 第1报”）
        val pubBase = if (quakeTime > 0) {
            SimpleDateFormat("yyyy年MM月dd日 HH:mm 发表", Locale.CHINA).apply {
                timeZone = TimeZone.getTimeZone("Asia/Shanghai")
            }.format(Date(quakeTime))
        } else {
            "刚刚发布"
        }
        findViewById<TextView>(R.id.tvPubTime).text =
            if (test) pubBase else pubBase + sourceSuffix()

        // 大红板：我所在地预计烈度（左）+ 倒计时（右，带一位小数）
        tvLocalIntensity.text = if (localIntensity >= 0) "$localIntensity" else "-"
        val remain0 = ((sArrival - System.currentTimeMillis()) / 1000).toInt().coerceAtLeast(0)
        tvCountdown.text = "%.1f".format(Locale.CHINA, remain0.toDouble())

        // 数据格
        findViewById<TextView>(R.id.tvStatMaxInt).text =
            if (test) "8 度" else if (maxIntensity > 0) "$maxIntensity 度" else "-"
        findViewById<TextView>(R.id.tvStatMag).text = "$magnitude"
        findViewById<TextView>(R.id.tvStatPlace).text = location
        findViewById<TextView>(R.id.tvStatDepth).text =
            if (depth >= 0) "${depth.toInt()} km" else "未公布"
        findViewById<TextView>(R.id.tvTargetAreas).text = targetAreas

        val broadcast =
            "地震预警，${location}发生${magnitude}级地震，" +
                "S波将于${remain0}秒后到达，请立即避险，远离建筑物和坠物，找坚固家具躲避。"
        // 在线播报的地名句：不含“地震预警，”前缀（语音包已报过），不含秒数
        // （播出的秒数到播放时已过期，且会与倒计时报数重叠）。
        val onlineBroadcast =
            "${location}发生${magnitude}级地震，请立即避险，远离建筑物和坠物，找坚固家具躲避。"

        if (test) {
            LocalStore.addAlertHistory(this, "test", location, magnitude, remain0)
        }

        fetchWeatherAndSupplies()
        startAlarm()
        startVibration()
        if (voiceOn) {
            voicePackMode = LocalStore.voicePack(this)
            if (voicePackMode == "system") {
                // v1.6.2 系统语音模式：首次播报也改走在线普通话 TTS（带数字的句子绝不走系统 TTS，
                // 本机系统 TTS 会把数字读成英文）；在线失败时用语音包短语 + 震级数字拼读。
                // 重复提醒句与到达提示不含数字，仍走系统普通话 TTS（白名单 + 蜂鸣兜底）。
                mandarinTts = MandarinTts(this).also { tts ->
                    tts.init { found ->
                        if (!found) {
                            runOnUiThread {
                                findViewById<TextView>(R.id.tvVoiceNote).apply {
                                    text = "本机未找到普通话语音，已改用蜂鸣提示；" +
                                        "请在手机设置→文字转语音中下载普通话语音数据"
                                    visibility = View.VISIBLE
                                }
                            }
                        }
                        handler.postDelayed(repeatSpeakRunnable, 30_000)
                    }
                }
                if (placeNameTts == null) placeNameTts = PlaceNameTts(this)
                placeNameTts?.speak(broadcast) { ok ->
                    if (!ok) {
                        if (voicePack == null) voicePack = VoicePackPlayer(this, "female")
                        voicePack?.playYujing()
                        val feeling = if (localIntensity >= 0) QuakeMath.feelingText(localIntensity) else ""
                        handler.postDelayed({
                            voicePack?.playMagnitudeAndFeeling(magnitude, feeling)
                        }, 1500)
                    }
                }
            } else {
                // 语音包模式（默认）：倒计时与固定短语全部用预录普通话音频，绝不走系统 TTS
                voicePack = VoicePackPlayer(this, voicePackMode)
                voicePack?.playYujing()
                // 地名播报：在线普通话 TTS（带缓存），延迟 1.5 秒避免与“地震预警”重叠；
                // 在线失败时跳过地名（不报、不重试、不阻塞倒计时）
                handler.postDelayed({
                    if (placeNameTts == null) placeNameTts = PlaceNameTts(this)
                    placeNameTts?.speak(onlineBroadcast) { _ -> }
                }, 1500)
                // v1.6.2：不再初始化 MandarinTts——倒计时数字全部走语音包（>60 秒按位拼读），
                // 语音包模式下没有任何内容需要系统 TTS。
                handler.postDelayed(repeatSpeakRunnable, 30_000)
            }
        }
        handler.post(countdownRunnable)

        btnStop.setOnClickListener { finish() }

        // v1.6.1：真实报警时监听修订广播——同一场地震另一路数据源发来更新的报告
        // （如四川局第2报修正了震级/地点），刷新弹窗上显示的震级/地点/来源/第几报。
        // 倒计时与报警声不受影响。
        if (!test) {
            registerReceiver(revisionReceiver, IntentFilter(WarningService.ACTION_EEW_REVISION))
        }
    }

    /** “ · 中国地震台网 第1报”这样的来源后缀；没有来源信息时返回空串。 */
    private fun sourceSuffix(): String = buildString {
        if (alertSource.isNotEmpty()) append(" · $alertSource")
        if (alertReportNum > 0) append(" 第${alertReportNum}报")
    }

    /** 修订广播接收：只处理与本场报警同一事件（event_key 匹配）的更新。 */
    private val revisionReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent?.action != WarningService.ACTION_EEW_REVISION) return
            if (alertEventKey.isEmpty() ||
                intent.getStringExtra("event_key") != alertEventKey
            ) return
            val newLoc = intent.getStringExtra("location") ?: return
            val newMag = intent.getDoubleExtra("magnitude", -1.0)
            if (newMag < 0) return
            location = newLoc
            magnitude = newMag
            alertSource = intent.getStringExtra("source") ?: alertSource
            alertReportNum = intent.getIntExtra("report_num", alertReportNum)
            val maxInt = intent.getIntExtra("intensity", -1)
            val newDepth = intent.getDoubleExtra("depth", -1.0)
            runOnUiThread {
                findViewById<TextView>(R.id.tvAlertTitle).text = "$location 发生地震"
                findViewById<TextView>(R.id.tvStatMag).text = "$magnitude"
                findViewById<TextView>(R.id.tvStatPlace).text = location
                val shortPlace = location.substringAfterLast("市", location)
                    .removeSuffix("县").removeSuffix("市")
                    .ifEmpty { location }
                findViewById<TextView>(R.id.tvAlertMapTag).text = "${magnitude}级 $shortPlace"
                val tvPub = findViewById<TextView>(R.id.tvPubTime)
                tvPub.text = tvPub.text.toString().substringBefore(" · ") + sourceSuffix()
                if (maxInt > 0) findViewById<TextView>(R.id.tvStatMaxInt).text = "$maxInt 度"
                if (newDepth >= 0) {
                    findViewById<TextView>(R.id.tvStatDepth).text = "${newDepth.toInt()} km"
                }
            }
        }
    }

    /** 目标区域：从震中地名取“市/县”级行政区（如“四川宜宾市长宁县”→“宜宾及周边”）。 */
    private fun deriveTargetAreas(location: String): String {
        val cityIdx = location.indexOf("市")
        val countyIdx = location.indexOf("县")
        val end = when {
            cityIdx > 0 -> cityIdx
            countyIdx > 0 -> countyIdx
            else -> -1
        }
        if (end <= 0) return location
        val provIdx = location.lastIndexOf("省")
        val start = if (provIdx >= 0 && provIdx < end) provIdx + 1 else 0
        val area = location.substring(start, end + 1)
        return area.removeSuffix("市").removeSuffix("县") + "及周边"
    }

    /** 地图上的震中红点 + 两圈震动范围环（静态环，示意）；无经纬度时不画点。 */
    private fun positionAlertMarker(lat: Double, lon: Double) {
        val layer = findViewById<FrameLayout>(R.id.alertMarkerLayer)
        if (lat == 0.0 && lon == 0.0) return
        val xPct = (lon - 73) / 62.0
        val yPct = (54 - lat) / 36.0
        if (xPct < 0 || xPct > 1 || yPct < 0 || yPct > 1) return
        layer.post {
            val w = layer.width
            val h = layer.height
            if (w == 0 || h == 0) return@post
            val cx = (w * xPct).toInt()
            val cy = (h * yPct).toInt()
            val density = resources.displayMetrics.density
            fun dp(v: Int): Int = (v * density).toInt()
            for (size in listOf(dp(170), dp(90))) {
                val ring = View(this).apply {
                    setBackgroundResource(R.drawable.epi_ring)
                    layoutParams = FrameLayout.LayoutParams(size, size).apply {
                        leftMargin = cx - size / 2
                        topMargin = cy - size / 2
                    }
                }
                layer.addView(ring)
            }
            val dot = View(this).apply {
                setBackgroundResource(R.drawable.epi_dot)
                val size = dp(22)
                layoutParams = FrameLayout.LayoutParams(size, size).apply {
                    leftMargin = cx - size / 2
                    topMargin = cy - size / 2
                }
            }
            layer.addView(dot)
        }
    }

    // ---------------- 当地天气 + 物资推荐 ----------------

    /** Open-Meteo 免费天气接口，无须 key；失败时只显示常备物资，不影响报警。 */
    private fun fetchWeatherAndSupplies() {
        val tvPrep = findViewById<TextView>(R.id.tvPrepText)
        if (userLat == 0.0 && userLon == 0.0) {
            tvPrep.text = "未设置位置 · 备好水、干粮、手电"
            return
        }
        WeatherHelper.fetch(userLat, userLon) { f ->
            val hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
            val supplies = WeatherHelper.suppliesFor(f, hour)
            runOnUiThread {
                val weatherText = if (f == null) {
                    "当地天气获取失败"
                } else {
                    val tempText = f.tempNow?.let { "${it.toInt()}℃ " } ?: ""
                    val isRain = f.precipNow > 0 || f.codeNow in listOf(
                        51, 53, 55, 61, 63, 65, 66, 67, 71, 73, 75, 77,
                        80, 81, 82, 85, 86, 95, 96, 99
                    )
                    val rainText = if (isRain) "有降水 " else ""
                    "当地${WeatherHelper.weatherCodeText(f.codeNow)} $tempText$rainText" +
                        "风速${f.windNow.toInt()}km/h"
                }
                tvPrep.text = "$weatherText · 备好" + supplies.take(3).joinToString("、")
            }
        }
    }

    // ---------------- 警报声 / 震动 ----------------

    private fun startAlarm() {
        if (!soundOn) return
        try {
            val uri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
                ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
            mediaPlayer = MediaPlayer.create(this, uri)?.apply {
                isLooping = true
                start()
            }
        } catch (_: Exception) {
        }
    }

    private fun startVibration() {
        if (!vibrateOn) return
        try {
            @Suppress("DEPRECATION")
            vibrator = getSystemService(VIBRATOR_SERVICE) as Vibrator
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                vibrator?.vibrate(
                    VibrationEffect.createWaveform(longArrayOf(0, 1000, 500, 1000), 0)
                )
            } else {
                @Suppress("DEPRECATION")
                vibrator?.vibrate(longArrayOf(0, 1000, 500, 1000), 0)
            }
        } catch (_: Exception) {
        }
    }

    override fun onDestroy() {
        try {
            unregisterReceiver(revisionReceiver)
        } catch (_: Exception) {
        }
        handler.removeCallbacks(countdownRunnable)
        handler.removeCallbacks(repeatSpeakRunnable)
        handler.removeCallbacks(resumeAlarmRunnable)
        siren.stop()
        try {
            mediaPlayer?.stop()
            mediaPlayer?.release()
        } catch (_: Exception) {
        }
        try {
            vibrator?.cancel()
        } catch (_: Exception) {
        }
        mandarinTts?.shutdown()
        voicePack?.release()
        placeNameTts?.release()
        super.onDestroy()
    }
}
