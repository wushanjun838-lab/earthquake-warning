package com.quake.warning

import android.content.Context
import android.media.MediaPlayer
import android.media.RingtoneManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.VibrationEffect
import android.os.Vibrator
import android.view.WindowManager
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import java.util.Calendar

/**
 * 全屏报警页（预警弹窗）：锁屏也能亮屏弹出，倒计时 S 波到达，
 * 警报声 + 震动 + 普通话读秒播报，直到用户点“我知道了”才停。
 *
 * 本版规则（与网页版 v7–v16 同步）：
 * - 弹窗 = 第一版 + 按天气推荐的物资：只有等级/震中/震级、倒计时大数字、
 *   当地天气和物资；不要微博、不要避难场所整块、不要提示音流程文字。
 * - 读秒：10 秒开外每 2 秒读一下，最后 10 秒每秒读；倒计时从收到实时推送
 *   那一刻就开始（WarningService 拉起本页即开始）。
 * - 倒计时结束（S 波到达）：强提示音（程序生成警笛）持续 20 秒，
 *   之后恢复普通警报声，直到用户手动停止。
 * - 语音严格普通话（MandarinTts）：只认 zh-CN/zh-Hans-CN，绝不用粤语凑数；
 *   本机无普通话语音时改用蜂鸣代替读秒，并在页内注明原因。
 * - 提醒方式（警报声/震动开关）在“我的 > 提醒方式”里设置，这里只执行。
 */
class AlertActivity : AppCompatActivity() {

    private lateinit var tvCountdown: TextView
    private lateinit var tvInfo: TextView
    private lateinit var tvBroadcast: TextView
    private lateinit var tvWeather: TextView
    private lateinit var tvSupplies: TextView
    private var mediaPlayer: MediaPlayer? = null
    private var vibrator: Vibrator? = null
    private var mandarinTts: MandarinTts? = null
    private var sArrival = 0L
    private var voiceOn = true
    private var soundOn = true
    private var vibrateOn = true
    private var location = ""
    private var magnitude = 0.0
    private var userLat = 0.0
    private var userLon = 0.0
    private val handler = Handler(Looper.getMainLooper())
    private var arrivalHandled = false
    private val siren = SirenPlayer()

    /** 读秒：>10 秒时每 2 秒读一下，<=10 秒时每秒读。 */
    private val countdownRunnable = object : Runnable {
        override fun run() {
            val remain = ((sArrival - System.currentTimeMillis()) / 1000).toInt()
            if (remain > 0) {
                tvCountdown.text = remain.toString()
                if (remain <= 10 || remain % 2 == 0) {
                    mandarinTts?.speakNumber(remain)
                }
                handler.postDelayed(this, 1000)
            } else {
                onArrival()
            }
        }
    }

    private val repeatSpeakRunnable = object : Runnable {
        override fun run() {
            mandarinTts?.speak("地震预警，S波即将到达，请立即避险。")
            handler.postDelayed(this, 30_000)
        }
    }

    /** S 波到达：强提示音 20 秒，之后恢复普通警报声。 */
    private val resumeAlarmRunnable = Runnable {
        siren.stop()
        startAlarm()
        startVibration()
    }

    private fun onArrival() {
        if (arrivalHandled) return
        arrivalHandled = true
        tvCountdown.text = "S波已到达"
        mandarinTts?.speakArrival()
        try {
            mediaPlayer?.stop()
            mediaPlayer?.release()
        } catch (_: Exception) {
        }
        mediaPlayer = null
        try {
            vibrator?.cancel()
        } catch (_: Exception) {
        }
        if (soundOn) siren.start()
        if (vibrateOn) {
            try {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    vibrator?.vibrate(
                        VibrationEffect.createWaveform(longArrayOf(0, 500, 200, 500), 0)
                    )
                }
            } catch (_: Exception) {
            }
        }
        handler.postDelayed(resumeAlarmRunnable, 20_000)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        @Suppress("DEPRECATION")
        window.addFlags(
            WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED
                or WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON
                or WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON
        )
        setContentView(R.layout.activity_alert)

        tvCountdown = findViewById(R.id.tvCountdown)
        tvInfo = findViewById(R.id.tvInfo)
        tvBroadcast = findViewById(R.id.tvBroadcast)
        tvWeather = findViewById(R.id.tvWeather)
        tvSupplies = findViewById(R.id.tvSupplies)
        val btnStop: Button = findViewById(R.id.btnStop)

        val prefs = getSharedPreferences("prefs", Context.MODE_PRIVATE)
        userLat = prefs.getFloat("user_lat", 0f).toDouble()
        userLon = prefs.getFloat("user_lon", 0f).toDouble()
        soundOn = LocalStore.soundOn(this)
        vibrateOn = LocalStore.vibrateOn(this)

        location = intent.getStringExtra("location") ?: "某地"
        magnitude = intent.getDoubleExtra("magnitude", 0.0)
        val depth = intent.getDoubleExtra("depth", -1.0)
        val intensity = intent.getIntExtra("intensity", -1)
        val test = intent.getBooleanExtra("test", false)
        voiceOn = intent.getBooleanExtra("voice", true)
        sArrival = intent.getLongExtra("s_arrival", 0L)
        if (test) {
            location = "测试（模拟地震）"
            magnitude = 5.0
            sArrival = System.currentTimeMillis() + 30_000
        }

        val depthText = if (depth >= 0) "  深度${depth.toInt()}千米" else ""
        val intensityText = if (intensity > 0) "  预计烈度$intensity" else ""
        tvInfo.text = "$location  $magnitude 级$depthText$intensityText"

        val remain0 = ((sArrival - System.currentTimeMillis()) / 1000).toInt().coerceAtLeast(0)
        val broadcast =
            "地震预警，${location}发生${magnitude}级地震，" +
                "S波将于${remain0}秒后到达，请立即避险，远离建筑物和坠物，找坚固家具躲避。"
        tvBroadcast.text = broadcast

        if (test) {
            LocalStore.addAlertHistory(this, "test", location, magnitude, remain0)
        }

        fetchWeatherAndSupplies()
        startAlarm()
        startVibration()
        if (voiceOn) {
            mandarinTts = MandarinTts(this).also { tts ->
                tts.init { found ->
                    if (!found) {
                        runOnUiThread {
                            tvBroadcast.text = broadcast +
                                "\n（本机未找到普通话语音，已改用蜂鸣提示；请在手机设置→文字转语音中下载普通话语音数据）"
                        }
                    } else {
                        tts.speak(broadcast)
                    }
                    handler.postDelayed(repeatSpeakRunnable, 30_000)
                }
            }
        }
        handler.post(countdownRunnable)

        btnStop.setOnClickListener { finish() }
    }

    // ---------------- 当地天气 + 物资推荐 ----------------

    /** Open-Meteo 免费天气接口，无须 key；失败时只显示常备物资，不影响报警。 */
    private fun fetchWeatherAndSupplies() {
        if (userLat == 0.0 && userLon == 0.0) {
            tvWeather.text = "未设置位置，无法获取当地天气"
            tvSupplies.text = "建议随身物资：饮用水、干粮、急救包、充电宝、口哨、重要证件、手电筒"
            return
        }
        WeatherHelper.fetch(userLat, userLon) { f ->
            val hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
            val supplies = WeatherHelper.suppliesFor(f, hour)
            runOnUiThread {
                if (f == null) {
                    tvWeather.text = "当地天气获取失败"
                } else {
                    val tempText = f.tempNow?.let { "${it.toInt()}℃ " } ?: ""
                    val isRain = f.precipNow > 0 || f.codeNow in listOf(
                        51, 53, 55, 61, 63, 65, 66, 67, 71, 73, 75, 77,
                        80, 81, 82, 85, 86, 95, 96, 99
                    )
                    val rainText = if (isRain) "有降水 " else ""
                    tvWeather.text = "当地天气：${WeatherHelper.weatherCodeText(f.codeNow)} " +
                        "$tempText$rainText" + "风速${f.windNow.toInt()}km/h"
                }
                tvSupplies.text = "建议随身物资：" + supplies.joinToString("、")
            }
        }
    }

    // ---------------- 警报声 / 震动 ----------------

    private fun startAlarm() {
        if (!soundOn) return
        try {
            val uri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
                ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
            mediaPlayer = MediaPlayer.create(this, uri)?.apply {
                isLooping = true
                start()
            }
        } catch (_: Exception) {
        }
    }

    private fun startVibration() {
        if (!vibrateOn) return
        try {
            @Suppress("DEPRECATION")
            vibrator = getSystemService(VIBRATOR_SERVICE) as Vibrator
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                vibrator?.vibrate(
                    VibrationEffect.createWaveform(longArrayOf(0, 1000, 500, 1000), 0)
                )
            } else {
                @Suppress("DEPRECATION")
                vibrator?.vibrate(longArrayOf(0, 1000, 500, 1000), 0)
            }
        } catch (_: Exception) {
        }
    }

    override fun onDestroy() {
        handler.removeCallbacks(countdownRunnable)
        handler.removeCallbacks(repeatSpeakRunnable)
        handler.removeCallbacks(resumeAlarmRunnable)
        siren.stop()
        try {
            mediaPlayer?.stop()
            mediaPlayer?.release()
        } catch (_: Exception) {
        }
        try {
            vibrator?.cancel()
        } catch (_: Exception) {
        }
        mandarinTts?.shutdown()
        super.onDestroy()
    }
}
