package com.quake.warning

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.content.ContextCompat

/** 开机后恢复预警服务（仅当用户之前开着服务时）。 */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Intent.ACTION_BOOT_COMPLETED) return
        val prefs = context.getSharedPreferences("prefs", Context.MODE_PRIVATE)
        if (!prefs.getBoolean("service_wanted", false)) return
        val serviceIntent = Intent(context, WarningService::class.java)
        ContextCompat.startForegroundService(context, serviceIntent)
    }
}
