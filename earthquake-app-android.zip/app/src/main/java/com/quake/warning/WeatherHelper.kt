package com.quake.warning

import okhttp3.Call
import okhttp3.Callback
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import org.json.JSONObject
import java.io.IOException
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

/**
 * 当地天气（Open-Meteo 免费接口，无须 key）：
 * - 播报条用：未来 4 天天气预报 + 当地天气灾害预警（高温/寒冷/大风/暴雨/暴雪/雷电，
 *   按阈值判定，公开预报推算，不是气象部门正式预警信号）；
 * - 预警弹窗用：当前天气 + 按天气推荐的随身物资。
 * 失败时不影响报警/播报，只显示常备物资或跳过天气条目。
 */
object WeatherHelper {

    data class DayForecast(val dateLabel: String, val weather: String, val maxTemp: Int, val minTemp: Int)
    data class Hazard(val text: String, val level: Int) // level 1 注意 2 警告（仅用于小圆点颜色）

    data class Forecast(
        val tempNow: Double?,
        val codeNow: Int,
        val windNow: Double,
        val precipNow: Double,
        val days: List<DayForecast>,
        val hazards: List<Hazard>
    )

    private val client = OkHttpClient()

    /** 拉取监测城市未来 4 天 + 当前天气。回调在后台线程，调用方自行切主线程。 */
    fun fetch(lat: Double, lon: Double, onResult: (Forecast?) -> Unit) {
        val url = "https://api.open-meteo.com/v1/forecast?latitude=$lat&longitude=$lon" +
            "&current=temperature_2m,precipitation,weather_code,wind_speed_10m" +
            "&daily=weather_code,temperature_2m_max,temperature_2m_min,precipitation_sum,wind_speed_10m_max" +
            "&forecast_days=5&timezone=auto"
        client.newCall(Request.Builder().url(url).build()).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                onResult(null)
            }

            override fun onResponse(call: Call, response: Response) {
                val body = response.body?.string() ?: ""
                try {
                    val root = JSONObject(body)
                    val cur = root.optJSONObject("current")
                    val daily = root.optJSONObject("daily")
                    val days = mutableListOf<DayForecast>()
                    val hazards = mutableListOf<Hazard>()
                    if (daily != null) {
                        val dates = daily.optJSONArray("time")
                        val codes = daily.optJSONArray("weather_code")
                        val maxs = daily.optJSONArray("temperature_2m_max")
                        val mins = daily.optJSONArray("temperature_2m_min")
                        val precs = daily.optJSONArray("precipitation_sum")
                        val winds = daily.optJSONArray("wind_speed_10m_max")
                        val n = dates?.length() ?: 0
                        val dayFmt = SimpleDateFormat("MM月dd日", Locale.CHINA)
                        val weekFmt = SimpleDateFormat("EEEE", Locale.CHINA)
                        for (i in 0 until minOf(n, 5)) {
                            val dateStr = dates?.optString(i) ?: continue
                            val date = try {
                                SimpleDateFormat("yyyy-MM-dd", Locale.CHINA).parse(dateStr)
                            } catch (_: Exception) {
                                null
                            } ?: continue
                            val maxT = maxs?.optDouble(i, Double.NaN) ?: Double.NaN
                            val minT = mins?.optDouble(i, Double.NaN) ?: Double.NaN
                            val code = codes?.optInt(i, -1) ?: -1
                            val prec = precs?.optDouble(i, 0.0) ?: 0.0
                            val wind = winds?.optDouble(i, 0.0) ?: 0.0
                            val label = when (i) {
                                0 -> "今天"
                                1 -> "明天"
                                else -> dayFmt.format(date) + " " + weekFmt.format(date)
                            }
                            days.add(
                                DayForecast(
                                    label, weatherCodeText(code),
                                    if (maxT.isNaN()) 0 else maxT.toInt(),
                                    if (minT.isNaN()) 0 else minT.toInt()
                                )
                            )
                            // 当地天气灾害预警（公开预报按阈值推算）
                            if (i == 0 || i == 1) {
                                if (!maxT.isNaN() && maxT >= 35) hazards.add(Hazard("$label 高温 ${maxT.toInt()}℃", 2))
                                if (!minT.isNaN() && minT <= -10) hazards.add(Hazard("$label 严寒 ${minT.toInt()}℃", 2))
                                if (wind >= 60) hazards.add(Hazard("$label 大风 ${wind.toInt()}km/h", 2))
                                else if (wind >= 40) hazards.add(Hazard("$label 大风 ${wind.toInt()}km/h", 1))
                                if (prec >= 50) hazards.add(Hazard("$label 暴雨 ${prec.toInt()}毫米", 2))
                                else if (prec >= 25) hazards.add(Hazard("$label 降雨 ${prec.toInt()}毫米", 1))
                                if (code in listOf(71, 73, 75, 77, 85, 86)) hazards.add(Hazard("$label 降雪", 1))
                                if (code in listOf(95, 96, 99)) hazards.add(Hazard("$label 雷阵雨", 1))
                            }
                        }
                    }
                    onResult(
                        Forecast(
                            tempNow = cur?.optDouble("temperature_2m", Double.NaN)
                                ?.takeIf { !it.isNaN() },
                            codeNow = cur?.optInt("weather_code", -1) ?: -1,
                            windNow = cur?.optDouble("wind_speed_10m", 0.0) ?: 0.0,
                            precipNow = cur?.optDouble("precipitation", 0.0) ?: 0.0,
                            days = days,
                            hazards = hazards
                        )
                    )
                } catch (_: Exception) {
                    onResult(null)
                }
            }
        })
    }

    /** v1.6.2 播报条天气灾害部分（只含灾害，没有灾害时为空）：跑马灯里放最前。 */
    fun tickerHazardItems(f: Forecast): List<Pair<String, Int>> {
        val out = mutableListOf<Pair<String, Int>>()
        for (h in f.hazards) out.add("天气预警：" + h.text to h.level)
        return out
    }

    /** v1.6.3 播报条天气预报部分：取未来 4 天（跳过今天，从明天起），放最后垫底。 */
    fun tickerForecastItems(f: Forecast): List<Pair<String, Int>> {
        val out = mutableListOf<Pair<String, Int>>()
        for (d in f.days.drop(1).take(4)) {
            out.add("${d.dateLabel} ${d.weather} ${d.minTemp}~${d.maxTemp}℃" to 0)
        }
        return out
    }

    /** 按天气推荐的随身物资（预警弹窗用）。 */
    fun suppliesFor(f: Forecast?, nowHour: Int): List<String> {
        val supplies = mutableListOf("饮用水", "干粮", "急救包", "充电宝", "口哨", "重要证件")
        if (f == null) return supplies + "手电筒"
        val isRain = f.precipNow > 0 || f.codeNow in listOf(
            51, 53, 55, 61, 63, 65, 66, 67, 71, 73, 75, 77,
            80, 81, 82, 85, 86, 95, 96, 99
        )
        if (isRain) supplies += listOf("雨衣", "防水袋", "防水鞋套")
        val t = f.tempNow
        if (t != null && t < 5) supplies += listOf("保暖毯", "厚外套", "暖宝宝")
        if (t != null && t >= 30) supplies += listOf("遮阳帽", "防晒用品")
        val isNight = nowHour < 6 || nowHour >= 18
        if (isNight) supplies += listOf("手电筒", "反光背心")
        if (f.windNow >= 40) supplies += listOf("防风外套")
        return supplies
    }

    fun weatherCodeText(code: Int): String = when (code) {
        0 -> "晴"
        1 -> "多云"
        2 -> "多云"
        3 -> "阴"
        45, 48 -> "雾"
        51, 53, 55 -> "毛毛雨"
        56, 57 -> "冻雨"
        61, 63, 65 -> "雨"
        66, 67 -> "冻雨"
        71, 73, 75 -> "雪"
        77 -> "雪粒"
        80, 81, 82 -> "阵雨"
        85, 86 -> "阵雪"
        95 -> "雷阵雨"
        96, 99 -> "冰雹雷阵雨"
        else -> ""
    }

    fun todayLabel(): String {
        val now = Date()
        val fmt = SimpleDateFormat("MM月dd日 EEEE", Locale.CHINA)
        return fmt.format(now)
    }
}
