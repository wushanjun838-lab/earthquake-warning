package com.quake.warning

import kotlin.math.*

/** 地震事件（台网目录或预警推送统一结构）。 */
data class Quake(
    val eventId: String,
    val timeMillis: Long,      // 发震时刻（毫秒，北京时间）
    val location: String,      // 中文震中地名
    val magnitude: Double,     // 震级
    val depthKm: Double?,      // 震源深度（千米）
    val latitude: Double,
    val longitude: Double,
    val intensity: Int?,       // 震中烈度（台网给出时用它，否则估算）
    // v1.6.1 多数据源：数据来源机构（中国地震台网 / 四川地震局 / USGS / EMSC），
    // 第几报（EEW 推送才有，0=未知），报告发布时间（毫秒，0=未知）。
    val source: String = "中国地震台网",
    val reportNum: Int = 0,
    val reportTimeMillis: Long = 0L
)

/** 距离与波到达时间计算。P波约6 km/s，S波约3.5 km/s。 */
object QuakeMath {

    fun distanceKm(lat1: Double, lon1: Double, lat2: Double, lon2: Double): Double {
        val r = 6371.0
        val dLat = Math.toRadians(lat2 - lat1)
        val dLon = Math.toRadians(lon2 - lon1)
        val a = sin(dLat / 2).pow(2) +
            cos(Math.toRadians(lat1)) * cos(Math.toRadians(lat2)) * sin(dLon / 2).pow(2)
        return 2 * r * asin(sqrt(a))
    }

    /** S波到达时刻（毫秒）。 */
    fun sArrivalMillis(originMillis: Long, distanceKm: Double): Long =
        originMillis + (distanceKm / 3.5 * 1000).toLong()

    /**
     * 我所在地预计烈度（v1.3 修正版）：
     * 按震级与震中距衰减估算，经验公式，仅供参考。
     * 烈度 ≈ 震级 - 1.5*log10(距离+10) + 1.5，截断到 0~9。
     * 注意：这是用户所在地的预计烈度，绝不能拿台网给的“震中烈度”
     * （q.intensity）当成本地烈度显示——远震的震中烈度很高，
     * 但用户所在地可能完全无感（例如宜宾 3.1 级、250 公里外约 1 度）。
     * 校验：宜宾 M3.1@250km→1度无感；托克逊 M4.1@850km→1度无感；
     * 玉树 M4.0@977km→1度无感；斐济 M6.1@9200km→2度无感；
     * 长宁 M6.0@200km→4度（与 NERV 预览样例一致）。
     */
    fun estimateIntensity(magnitude: Double, distanceKm: Double): Int {
        val v = magnitude - 1.5 * log10(distanceKm + 10.0) + 1.5
        return v.roundToInt().coerceIn(0, 9)
    }

    /** 按本地预计烈度给体感分级：≤2 无感 / 3–4 有感 / ≥5 强烈。 */
    fun feelingText(localIntensity: Int): String = when {
        localIntensity <= 2 -> "无感"
        localIntensity <= 4 -> "有感"
        else -> "强烈"
    }

    /** 某次地震在用户所在地的预计烈度；未设置监测位置时返回 null。 */
    fun localIntensity(quake: Quake, userLat: Double, userLon: Double): Int? {
        if (userLat == 0.0 && userLon == 0.0) return null
        val dist = distanceKm(userLat, userLon, quake.latitude, quake.longitude)
        return estimateIntensity(quake.magnitude, dist)
    }

    // ---------------- v1.6.1 多数据源去重 ----------------
    //
    // 同一场地震会从 CENC 和四川局两路推送进来，EventID 格式还不一样：
    // CENC EEW 是 "202611060056.0001"，四川局是 "202610231016.0001_2"（末尾 _N 是第几报），
    // 速报目录里则是 "CD.20261106101126.025" 这种带机构前缀的。只比 EventID 全等一定漏判，
    // 所以同一场地震的判定是：归一化 EventID 相等，或地点相同且发震时刻差 < 60 秒
    // （地点+时间规则与首页 renderHomeLatest 的去重规则一致）。

    /** 归一化 EventID：去掉四川局的 "_N" 后缀和目录的机构前缀（CD./CC./AU. 等）。 */
    fun normalizeEventId(id: String): String {
        var s = id.trim()
        s = s.replace(Regex("_\\d+$"), "")
        s = s.replace(Regex("^[A-Za-z]{1,3}\\."), "")
        return s
    }

    /** 同一场地震吗（跨数据源去重用）。 */
    fun sameEvent(a: Quake, b: Quake): Boolean {
        if (a.eventId.isNotEmpty() && b.eventId.isNotEmpty()) {
            val na = normalizeEventId(a.eventId)
            val nb = normalizeEventId(b.eventId)
            if (na.isNotEmpty() && na == nb) return true
        }
        return a.location == b.location &&
            kotlin.math.abs(a.timeMillis - b.timeMillis) < 60_000
    }

    /**
     * 事件的稳定键（播报记录去重、预警弹窗修订匹配用）。
     * 时间戳型 EventID（YYYYMMDDHHMMSS.序号）直接用归一化 ID；
     * 否则退回地点+分钟桶。注意：目录 ID 与 EEW ID 的序号段不同
     * （".025" vs ".0001"），目录与推送之间仍需靠 sameEvent() 的地点+时间规则判重。
     */
    fun canonicalEventKey(q: Quake): String {
        val n = normalizeEventId(q.eventId)
        if (n.matches(Regex("^\\d{14}\\.\\d+$"))) return "id:$n"
        return "lt:${q.location}:${q.timeMillis / 60000}"
    }
}
