package com.quake.warning

import kotlin.math.*

/** 地震事件（台网目录或预警推送统一结构）。 */
data class Quake(
    val eventId: String,
    val timeMillis: Long,      // 发震时刻（毫秒，北京时间）
    val location: String,      // 中文震中地名
    val magnitude: Double,     // 震级
    val depthKm: Double?,      // 震源深度（千米）
    val latitude: Double,
    val longitude: Double,
    val intensity: Int?        // 震中烈度（台网给出时用它，否则估算）
)

/** 距离与波到达时间计算。P波约6 km/s，S波约3.5 km/s。 */
object QuakeMath {

    fun distanceKm(lat1: Double, lon1: Double, lat2: Double, lon2: Double): Double {
        val r = 6371.0
        val dLat = Math.toRadians(lat2 - lat1)
        val dLon = Math.toRadians(lon2 - lon1)
        val a = sin(dLat / 2).pow(2) +
            cos(Math.toRadians(lat1)) * cos(Math.toRadians(lat2)) * sin(dLon / 2).pow(2)
        return 2 * r * asin(sqrt(a))
    }

    /** S波到达时刻（毫秒）。 */
    fun sArrivalMillis(originMillis: Long, distanceKm: Double): Long =
        originMillis + (distanceKm / 3.5 * 1000).toLong()

    /**
     * 我所在地预计烈度（v1.3 修正版）：
     * 按震级与震中距衰减估算，经验公式，仅供参考。
     * 烈度 ≈ 震级 - 1.5*log10(距离+10) + 1.5，截断到 0~9。
     * 注意：这是用户所在地的预计烈度，绝不能拿台网给的“震中烈度”
     * （q.intensity）当成本地烈度显示——远震的震中烈度很高，
     * 但用户所在地可能完全无感（例如宜宾 3.1 级、250 公里外约 1 度）。
     * 校验：宜宾 M3.1@250km→1度无感；托克逊 M4.1@850km→1度无感；
     * 玉树 M4.0@977km→1度无感；斐济 M6.1@9200km→2度无感；
     * 长宁 M6.0@200km→4度（与 NERV 预览样例一致）。
     */
    fun estimateIntensity(magnitude: Double, distanceKm: Double): Int {
        val v = magnitude - 1.5 * log10(distanceKm + 10.0) + 1.5
        return v.roundToInt().coerceIn(0, 9)
    }

    /** 按本地预计烈度给体感分级：≤2 无感 / 3–4 有感 / ≥5 强烈。 */
    fun feelingText(localIntensity: Int): String = when {
        localIntensity <= 2 -> "无感"
        localIntensity <= 4 -> "有感"
        else -> "强烈"
    }

    /** 某次地震在用户所在地的预计烈度；未设置监测位置时返回 null。 */
    fun localIntensity(quake: Quake, userLat: Double, userLon: Double): Int? {
        if (userLat == 0.0 && userLon == 0.0) return null
        val dist = distanceKm(userLat, userLon, quake.latitude, quake.longitude)
        return estimateIntensity(quake.magnitude, dist)
    }
}
