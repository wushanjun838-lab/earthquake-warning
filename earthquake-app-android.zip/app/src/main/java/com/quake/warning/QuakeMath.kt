package com.quake.warning

import kotlin.math.*

/** 地震事件（台网目录或预警推送统一结构）。 */
data class Quake(
    val eventId: String,
    val timeMillis: Long,      // 发震时刻（毫秒，北京时间）
    val location: String,      // 中文震中地名
    val magnitude: Double,     // 震级
    val depthKm: Double?,      // 震源深度（千米）
    val latitude: Double,
    val longitude: Double,
    val intensity: Int?        // 震中烈度（台网给出时用它，否则估算）
)

/** 距离与波到达时间计算。P波约6 km/s，S波约3.5 km/s。 */
object QuakeMath {

    fun distanceKm(lat1: Double, lon1: Double, lat2: Double, lon2: Double): Double {
        val r = 6371.0
        val dLat = Math.toRadians(lat2 - lat1)
        val dLon = Math.toRadians(lon2 - lon1)
        val a = sin(dLat / 2).pow(2) +
            cos(Math.toRadians(lat1)) * cos(Math.toRadians(lat2)) * sin(dLon / 2).pow(2)
        return 2 * r * asin(sqrt(a))
    }

    /** S波到达时刻（毫秒）。 */
    fun sArrivalMillis(originMillis: Long, distanceKm: Double): Long =
        originMillis + (distanceKm / 3.5 * 1000).toLong()

    /**
     * 烈度粗略估算（仅当台网没给烈度时用，结果仅供参考）：
     * 烈度 ≈ 震级 - log10(距离+10) + 2，截断到 2~9。
     */
    fun estimateIntensity(magnitude: Double, distanceKm: Double): Int {
        val v = magnitude - log10(distanceKm + 10.0) + 2.0
        return v.roundToInt().coerceIn(2, 9)
    }
}
