package com.quake.warning

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Shader
import android.util.AttributeSet
import android.view.View

/**
 * 近 7 天地震活动折线图（v1.4 首页“地震活动”区）。
 * 数据来自 CENC 目录按天统计（真实目录，不用示意数）：
 * 每天一个点，带辉光的绿线 + 面积渐变填充 + 每个数据点一个小圆点 + 横轴日期标签。
 * 目录覆盖不满 7 天时只画实际有数据的天数（调用方传入几天就画几点）；
 * 只有 1 个点时只画圆点，不连线。
 */
class WaveformChartView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : View(context, attrs, defStyleAttr) {

    /** 一天的数据：横轴标签（如 "11-06"）+ 当天地震次数。 */
    data class DayPoint(val label: String, val count: Int)

    private var points: List<DayPoint> = emptyList()

    private val linePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFF93E62A.toInt()
        style = Paint.Style.STROKE
        strokeWidth = 4f * resources.displayMetrics.density
        strokeJoin = Paint.Join.ROUND
        strokeCap = Paint.Cap.ROUND
        setShadowLayer(12f, 0f, 0f, 0xFF93E62A.toInt())
    }
    private val areaPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
    }
    private val dotPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFF0B0F0B.toInt()
        style = Paint.Style.FILL
    }
    private val dotRingPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFF93E62A.toInt()
        style = Paint.Style.STROKE
        strokeWidth = 3f * resources.displayMetrics.density
    }
    private val gridPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(0x1A, 0xFF, 0xFF, 0xFF)
        style = Paint.Style.STROKE
        strokeWidth = 1f
    }
    private val labelPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFFA8C4A0.toInt()
        textSize = 11f * resources.displayMetrics.density
        textAlign = Paint.Align.CENTER
    }

    fun setData(data: List<DayPoint>) {
        points = data
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        if (points.isEmpty()) return
        val density = resources.displayMetrics.density
        val padL = 16f * density
        val padR = 16f * density
        val padT = 18f * density
        val padB = 26f * density
        val w = width - padL - padR
        val h = height - padT - padB
        if (w <= 0 || h <= 0) return

        // 横向网格线（3 条）
        for (i in 0..2) {
            val y = padT + h * i / 2f
            canvas.drawLine(padL, y, padL + w, y, gridPaint)
        }

        val maxCount = (points.maxOfOrNull { it.count } ?: 0).coerceAtLeast(1)
        val xAt: (Int) -> Float = { i ->
            if (points.size == 1) padL + w / 2f
            else padL + w * i / (points.size - 1)
        }
        val yAt: (Int) -> Float = { c ->
            padT + h * (1f - c.toFloat() / maxCount * 0.85f)
        }

        // 面积渐变填充（线下到基线）
        if (points.size >= 2) {
            val area = Path().apply {
                moveTo(xAt(0), yAt(points[0].count))
                for (i in 1 until points.size) lineTo(xAt(i), yAt(points[i].count))
                lineTo(xAt(points.size - 1), padT + h)
                lineTo(xAt(0), padT + h)
                close()
            }
            areaPaint.shader = LinearGradient(
                0f, padT, 0f, padT + h,
                Color.argb(0x40, 0x93, 0xE6, 0x2A),
                Color.argb(0x00, 0x93, 0xE6, 0x2A),
                Shader.TileMode.CLAMP
            )
            canvas.drawPath(area, areaPaint)
        }

        // 折线
        if (points.size >= 2) {
            val line = Path().apply {
                moveTo(xAt(0), yAt(points[0].count))
                for (i in 1 until points.size) lineTo(xAt(i), yAt(points[i].count))
            }
            canvas.drawPath(line, linePaint)
        }

        // 数据点 + 横轴日期
        val dotR = 5f * density
        for (i in points.indices) {
            val x = xAt(i)
            val y = yAt(points[i].count)
            canvas.drawCircle(x, y, dotR + 3f * density, dotRingPaint)
            canvas.drawCircle(x, y, dotR, dotPaint)
            canvas.drawText(
                points[i].label, x,
                height - 8f * density, labelPaint
            )
        }
    }
}
