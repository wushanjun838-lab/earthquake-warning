package com.quake.warning

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Shader
import android.util.AttributeSet
import android.view.View

/**
 * 近 7 天地震活动折线图（v1.4 首页“地震活动”区）。
 * 数据来自 CENC 目录按天统计（真实目录，不用示意数）：
 * 每天一个点，带辉光的绿线 + 面积渐变填充 + 每个数据点一个小圆点 + 横轴日期标签。
 * 目录覆盖不满 7 天时只画实际有数据的天数（调用方传入几天就画几点）；
 * 只有 1 个点时只画圆点，不连线。
 */
class WaveformChartView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : View(context, attrs, defStyleAttr) {

    /** 一天的数据：横轴标签（如 "11-06"）+ 当天地震次数。 */
    data class DayPoint(val label: String, val count: Int)

    private var points: List<DayPoint> = emptyList()

    /** v1.6.2：线条颜色（默认荧光绿；震级分布图用橙色）。 */
    private var lineColor = 0xFF93E62A.toInt()

    /** v1.6.2：是否在每个点上方标数值（数据分析页开，首页“地震活动”关）。 */
    private var showValueLabels = false

    private val linePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFF93E62A.toInt()
        style = Paint.Style.STROKE
        strokeWidth = 4f * resources.displayMetrics.density
        strokeJoin = Paint.Join.ROUND
        strokeCap = Paint.Cap.ROUND
        setShadowLayer(12f, 0f, 0f, 0xFF93E62A.toInt())
    }
    private val areaPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
    }
    private val dotPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFF0B0F0B.toInt()
        style = Paint.Style.FILL
    }
    private val dotRingPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFF93E62A.toInt()
        style = Paint.Style.STROKE
        strokeWidth = 3f * resources.displayMetrics.density
    }
    private val gridPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(0x1A, 0xFF, 0xFF, 0xFF)
        style = Paint.Style.STROKE
        strokeWidth = 1f
    }
    private val labelPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFFA8C4A0.toInt()
        textSize = 11f * resources.displayMetrics.density
        textAlign = Paint.Align.CENTER
    }
    private val valuePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFFFFFFFF.toInt()
        textSize = 11f * resources.displayMetrics.density
        textAlign = Paint.Align.CENTER
        typeface = android.graphics.Typeface.DEFAULT_BOLD
    }

    fun setData(data: List<DayPoint>) {
        points = data
        invalidate()
    }

    /** v1.6.2：设置线条颜色（线、圆点描边、辉光、面积渐变一起换）。 */
    fun setLineColor(color: Int) {
        lineColor = color
        linePaint.color = color
        linePaint.setShadowLayer(12f, 0f, 0f, color)
        dotRingPaint.color = color
        invalidate()
    }

    /** v1.6.2：是否在每个点上方标数值。 */
    fun setShowValueLabels(show: Boolean) {
        showValueLabels = show
        invalidate()
    }

    /** Catmull-Rom 转三次贝塞尔：过所有点的平滑曲线（端点钳制，不外溢）。 */
    private fun smoothPath(xs: List<Float>, ys: List<Float>): Path {
        val path = Path()
        if (xs.isEmpty()) return path
        path.moveTo(xs[0], ys[0])
        if (xs.size == 2) {
            path.lineTo(xs[1], ys[1])
            return path
        }
        for (i in 0 until xs.size - 1) {
            val p0x = if (i == 0) xs[0] else xs[i - 1]
            val p0y = if (i == 0) ys[0] else ys[i - 1]
            val p1x = xs[i]
            val p1y = ys[i]
            val p2x = xs[i + 1]
            val p2y = ys[i + 1]
            val p3x = if (i + 2 < xs.size) xs[i + 2] else xs[i + 1]
            val p3y = if (i + 2 < xs.size) ys[i + 2] else ys[i + 1]
            val c1x = p1x + (p2x - p0x) / 6f
            val c1y = p1y + (p2y - p0y) / 6f
            val c2x = p2x - (p3x - p1x) / 6f
            val c2y = p2y - (p3y - p1y) / 6f
            path.cubicTo(c1x, c1y, c2x, c2y, p2x, p2y)
        }
        return path
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        if (points.isEmpty()) return
        val density = resources.displayMetrics.density
        val padL = 16f * density
        val padR = 16f * density
        // 数值标在点上方时顶部多留 12dp，避免最高点的数值贴到上边缘
        val padT = (if (showValueLabels) 30f else 18f) * density
        val padB = 26f * density
        val w = width - padL - padR
        val h = height - padT - padB
        if (w <= 0 || h <= 0) return

        // 横向网格线（3 条）
        for (i in 0..2) {
            val y = padT + h * i / 2f
            canvas.drawLine(padL, y, padL + w, y, gridPaint)
        }

        val maxCount = (points.maxOfOrNull { it.count } ?: 0).coerceAtLeast(1)
        val xAt: (Int) -> Float = { i ->
            if (points.size == 1) padL + w / 2f
            else padL + w * i / (points.size - 1)
        }
        val yAt: (Int) -> Float = { c ->
            padT + h * (1f - c.toFloat() / maxCount * 0.85f)
        }

        // 面积渐变填充（平滑曲线下到基线），渐变色跟随线条颜色
        if (points.size >= 2) {
            val xs = points.indices.map { xAt(it) }
            val ys = points.indices.map { yAt(points[it].count) }
            val area = smoothPath(xs, ys).apply {
                lineTo(xAt(points.size - 1), padT + h)
                lineTo(xAt(0), padT + h)
                close()
            }
            areaPaint.shader = LinearGradient(
                0f, padT, 0f, padT + h,
                Color.argb(0x40, Color.red(lineColor), Color.green(lineColor), Color.blue(lineColor)),
                Color.argb(0x00, Color.red(lineColor), Color.green(lineColor), Color.blue(lineColor)),
                Shader.TileMode.CLAMP
            )
            canvas.drawPath(area, areaPaint)
        }

        // 平滑折线
        if (points.size >= 2) {
            val xs = points.indices.map { xAt(it) }
            val ys = points.indices.map { yAt(points[it].count) }
            canvas.drawPath(smoothPath(xs, ys), linePaint)
        }

        // 数据点 + 数值 + 横轴日期
        val dotR = 5f * density
        for (i in points.indices) {
            val x = xAt(i)
            val y = yAt(points[i].count)
            canvas.drawCircle(x, y, dotR + 3f * density, dotRingPaint)
            canvas.drawCircle(x, y, dotR, dotPaint)
            if (showValueLabels) {
                canvas.drawText(
                    points[i].count.toString(), x,
                    y - dotR - 8f * density, valuePaint
                )
            }
            canvas.drawText(
                points[i].label, x,
                height - 8f * density, labelPaint
            )
        }
    }
}
