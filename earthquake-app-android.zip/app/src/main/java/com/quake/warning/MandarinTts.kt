package com.quake.warning

import android.content.Context
import android.media.ToneGenerator
import android.os.Handler
import android.os.Looper
import android.speech.tts.TextToSpeech
import android.speech.tts.Voice
import android.util.Log
import java.util.Locale

/**
 * 严格普通话语音播报。
 *
 * 规则（与网页版一致，2026-11-05 第二次投诉后收紧）：
 * - 白名单：只接受语言为 zh-CN 或 zh-Hans-CN 的语音；
 * - 黑名单：名称含 粤语/Cantonese/Yue/广东/香港/Hong Kong/HK/台湾/Taiwan/臺/Hant/
 *   zh-HK/zh-TW/zh-MO/yue 的一律排除；
 * - 绝不用粤语/港台语音凑数：本机找不到普通话语音时改用蜂鸣代替播报，
 *   并在设置页说明原因（手机设置→文字转语音中下载普通话语音数据）；
 * - 不提供“测试普通话”按钮，说明文字放在“我的 > 帮助与支持”里；
 * - 语音列表是异步加载的：等 voiceschanged 并轮询 getVoices 直到非空（最多约 2 秒），
 *   不在空列表时直接 speak。
 *
 * 蜂鸣兜底：用 ToneGenerator 发短促提示音代替读秒（倒计时每报一次哔一声，
 * S 波到达时连哔三声），不依赖任何语音数据。
 */
class MandarinTts(private val context: Context) {

    companion object {
        private const val TAG = "MandarinTts"
        private val BAD_NAME_KEYWORDS = listOf(
            "粤语", "Cantonese", "Yue", "广东", "香港", "Hong Kong", "HK",
            "台湾", "Taiwan", "臺", "Hant", "zh-HK", "zh-TW", "zh-MO", "yue"
        )
    }

    private var tts: TextToSpeech? = null
    private var mandarinVoice: Voice? = null
    private var ready = false
    private var useBeep = false
    private var toneGen: ToneGenerator? = null
    private val handler = Handler(Looper.getMainLooper())
    private var utterCount = 0

    /** 初始化（异步）。ready 后回调 onReady，参数为是否找到普通话语音。 */
    fun init(onReady: (mandarinFound: Boolean) -> Unit) {
        tts = TextToSpeech(context) { status ->
            if (status != TextToSpeech.SUCCESS) {
                useBeep = true
                ready = true
                onReady(false)
                return@TextToSpeech
            }
            waitForVoices(0, onReady)
        }
    }

    /** 轮询等语音列表加载完成，最多约 2 秒。 */
    private fun waitForVoices(triedMs: Long, onReady: (Boolean) -> Unit) {
        val voices = try {
            tts?.voices ?: emptySet()
        } catch (_: Exception) {
            emptySet()
        }
        if (voices.isNotEmpty() || triedMs >= 2000) {
            mandarinVoice = pickMandarin(voices)
            useBeep = mandarinVoice == null
            ready = true
            if (mandarinVoice != null) {
                try {
                    tts?.voice = mandarinVoice
                    tts?.language = Locale("zh", "CN")
                } catch (_: Exception) {
                }
                Log.i(TAG, "mandarin voice: ${mandarinVoice?.name}")
            } else {
                Log.w(TAG, "no mandarin voice on device, beep fallback")
            }
            onReady(mandarinVoice != null)
        } else {
            handler.postDelayed({ waitForVoices(triedMs + 200, onReady) }, 200)
        }
    }

    /** 白名单 + 黑名单筛选普通话语音。 */
    private fun pickMandarin(voices: Set<Voice>): Voice? {
        val good = voices.filter { v ->
            val loc = v.locale ?: return@filter false
            val tag = loc.toLanguageTag()
            val langOk = tag == "zh-CN" || tag == "zh-Hans-CN" ||
                (loc.language == "zh" && (loc.country == "CN" || loc.country.isEmpty()))
            if (!langOk) return@filter false
            val name = v.name ?: ""
            if (BAD_NAME_KEYWORDS.any { name.contains(it, ignoreCase = true) }) return@filter false
            if (tag.contains("HK", ignoreCase = true) ||
                tag.contains("TW", ignoreCase = true) ||
                tag.contains("MO", ignoreCase = true)
            ) return@filter false
            true
        }
        if (good.isEmpty()) return null
        // 优先名字里带普通话/Mandarin 的
        return good.firstOrNull {
            val n = it.name ?: ""
            n.contains("普通话") || n.contains("Mandarin", ignoreCase = true) ||
                n.contains("Putonghua", ignoreCase = true) ||
                n.contains("Xiaoxiao") || n.contains("Yunyang")
        } ?: good.first()
    }

    /** 当前是否用蜂鸣兜底（本机无普通话语音）。 */
    fun isBeepFallback(): Boolean = ready && useBeep

    /** 当前选中的普通话语音名（设置页展示用），没有则返回 null。 */
    fun currentVoiceName(): String? = mandarinVoice?.name

    fun speak(text: String) {
        if (!ready) return
        if (useBeep) {
            beep()
            return
        }
        try {
            utterCount++
            tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "m-$utterCount")
        } catch (_: Exception) {
        }
    }

    /** 读秒：只报数字；蜂鸣兜底时哔一声。 */
    fun speakNumber(n: Int) {
        if (!ready) return
        if (useBeep) {
            beep()
            return
        }
        try {
            utterCount++
            tts?.speak(n.toString(), TextToSpeech.QUEUE_FLUSH, null, "m-$utterCount")
        } catch (_: Exception) {
        }
    }

    /** S 波到达：语音播报一句；蜂鸣兜底时连哔三声。 */
    fun speakArrival() {
        if (!ready) return
        if (useBeep) {
            beep()
            handler.postDelayed({ beep() }, 400)
            handler.postDelayed({ beep() }, 800)
            return
        }
        speak("地震波已到达，请注意安全")
    }

    private fun beep() {
        try {
            if (toneGen == null) {
                toneGen = ToneGenerator(
                    android.media.AudioManager.STREAM_ALARM, 80
                )
            }
            toneGen?.startTone(ToneGenerator.TONE_PROP_BEEP, 250)
        } catch (_: Exception) {
        }
    }

    fun shutdown() {
        handler.removeCallbacksAndMessages(null)
        try {
            tts?.stop()
            tts?.shutdown()
        } catch (_: Exception) {
        }
        try {
            toneGen?.release()
        } catch (_: Exception) {
        }
        toneGen = null
        tts = null
    }
}
