package com.quake.warning

import android.content.Context
import android.content.res.AssetFileDescriptor
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.os.Handler
import android.os.Looper
import java.util.Locale

/**
 * 预录普通话语音包播放器（v1.5，用 MediaPlayer 重写）。
 *
 * 背景：本机系统 TTS 的普通话语音不可靠——手机上没有普通话语音时，
 * 倒计时会被粤语/其他语音播报，MandarinTts 的白名单拦不住。
 * 解决：倒计时读秒与固定短语改用预录音频，彻底不依赖手机系统语音。
 *
 * v1.5 改动：之前用 SoundPool，load 是异步的，刚创建播放器就播会因未加载完成而静音，
 * 用户反馈“语音播报依旧没用”。改用 MediaPlayer 同步 prepare，每次播都现场准备，
 * 彻底去掉异步加载问题；仍用 USAGE_ALARM，报警时即使手机静音也能听到。
 *
 * 文件在 res/raw（男女声各一套）：
 * - vp_f_01..vp_f_60 / vp_m_01..vp_m_60：数字 1–60，读作“X秒”（倒计时用）
 * - vp_f_yujing / vp_m_yujing：“地震预警”；vp_f_daoda / vp_m_daoda：“地震到达”
 * - vp_f_d0..vp_f_d9 / vp_m_d0..vp_m_d9：单个数字 0–9（震级用）
 * - vp_f_dian / vp_m_dian：“点”；vp_f_ji / vp_m_ji：“级”
 * - vp_f_wugan / vp_m_wugan：“无感”；vp_f_yougan / vp_m_yougan：“有感”；
 *   vp_f_qianglie / vp_m_qianglie：“强烈”
 *
 * 超过 60 秒的倒计时没有预录文件，调用方回落到系统 TTS（MandarinTts 白名单仍在）。
 */
class VoicePackPlayer(context: Context, pack: String) {

    companion object {
        /** 连续播放数字/词语片段时的间隔（毫秒）；单个数字约 0.4–0.6 秒。 */
        private const val CLIP_GAP_MS = 650L
    }

    private val appContext = context.applicationContext
    private val prefix = if (pack == "male") "vp_m" else "vp_f"
    private val handler = Handler(Looper.getMainLooper())
    private val res = appContext.resources
    private val pkg = appContext.packageName
    private var mediaPlayer: MediaPlayer? = null

    @Volatile
    private var released = false

    /**
     * 同步播放一个预录片段：现场打开资源、同步 prepare、立即播放。
     * 没有异步加载，调用后立即出声（prepare 约几十毫秒）。
     */
    private fun play(name: String): Boolean {
        if (released) return false
        val resId = res.getIdentifier(name, "raw", pkg)
        if (resId == 0) return false
        return try {
            // 停掉正在播的上一个片段，复用同一个 MediaPlayer
            try {
                mediaPlayer?.stop()
            } catch (_: Exception) {
            }
            try {
                mediaPlayer?.reset()
            } catch (_: Exception) {
            }
            if (mediaPlayer == null) {
                mediaPlayer = MediaPlayer().apply {
                    setAudioAttributes(
                        AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_ALARM)
                            .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                            .build()
                    )
                }
            }
            val afd: AssetFileDescriptor = res.openRawResourceFd(resId) ?: return false
            mediaPlayer?.apply {
                setDataSource(afd.fileDescriptor, afd.startOffset, afd.length)
                afd.close()
                prepare()
                start()
            }
            true
        } catch (_: Exception) {
            false
        }
    }

    /** 倒计时读秒：1–60 秒有预录，返回是否已播放。超出 1–60 时返回 false，调用方回落到系统 TTS。 */
    fun playNumber(sec: Int): Boolean {
        if (sec < 1 || sec > 60) return false
        return play(String.format(Locale.US, "%s_%02d", prefix, sec))
    }

    /** 固定短语“地震预警”。 */
    fun playYujing(): Boolean = play("${prefix}_yujing")

    /** 固定短语“地震到达”。 */
    fun playDaoda(): Boolean = play("${prefix}_daoda")

    /**
     * 离线播报震级 + 体感（无网时新地震播报的 fallback，不含地名）。
     * 例如 4.1 级无感 → 依次播 “4”“点”“1”“级”“无感”。
     * 异步按顺序播放，立即返回。
     */
    fun playMagnitudeAndFeeling(mag: Double, feeling: String) {
        if (released) return
        val clips = mutableListOf<String>()
        val magStr = "%.1f".format(Locale.US, mag)
        for (ch in magStr) {
            when (ch) {
                in '0'..'9' -> clips.add("${prefix}_d$ch")
                '.' -> clips.add("${prefix}_dian")
            }
        }
        clips.add("${prefix}_ji")
        when (feeling) {
            "无感" -> clips.add("${prefix}_wugan")
            "有感" -> clips.add("${prefix}_yougan")
            "强烈" -> clips.add("${prefix}_qianglie")
        }
        playSequence(clips, 0)
    }

    private fun playSequence(clips: List<String>, index: Int) {
        if (index >= clips.size || released) return
        play(clips[index])
        handler.postDelayed({ playSequence(clips, index + 1) }, CLIP_GAP_MS)
    }

    /** 试听：依次播“地震预警”→“10秒”→“地震到达”，播完自动释放。 */
    fun playPreview() {
        playYujing()
        handler.postDelayed({ playNumber(10) }, 1300)
        handler.postDelayed({ playDaoda() }, 2600)
        handler.postDelayed({ release() }, 4500)
    }

    fun release() {
        released = true
        handler.removeCallbacksAndMessages(null)
        try {
            mediaPlayer?.stop()
        } catch (_: Exception) {
        }
        try {
            mediaPlayer?.release()
        } catch (_: Exception) {
        }
        mediaPlayer = null
    }
}
