package com.quake.warning

import android.content.Context
import android.content.SharedPreferences
import org.json.JSONArray
import org.json.JSONObject

/**
 * 本地存储集中管理：震感记录、家庭联系人、家庭安全自查、预警记录、
 * AI 分析缓存、外观/提醒方式等偏好。全部只存本机，不上传。
 */
object LocalStore {

    const val PREFS = "prefs"

    fun prefs(context: Context): SharedPreferences =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    // ---------------- 外观与提醒方式 ----------------

    /** 外观：""=未设置（默认深色）/ "dark" / "light" / "system" */
    fun appearance(context: Context): String =
        prefs(context).getString("appearance", "") ?: ""

    fun setAppearance(context: Context, value: String) {
        prefs(context).edit().putString("appearance", value).apply()
    }

    fun isDark(context: Context): Boolean {
        return when (appearance(context)) {
            "light" -> false
            "system" -> {
                val night = context.resources.configuration.uiMode and
                    android.content.res.Configuration.UI_MODE_NIGHT_MASK
                night == android.content.res.Configuration.UI_MODE_NIGHT_YES
            }
            else -> true // 未设置或 dark：默认深色
        }
    }

    /** 减少动态：开启后播报条停滚、呼吸动效关闭 */
    fun reducedMotion(context: Context): Boolean =
        prefs(context).getBoolean("reduced_motion", false)

    fun setReducedMotion(context: Context, value: Boolean) {
        prefs(context).edit().putBoolean("reduced_motion", value).apply()
    }

    /** 警报声开关 / 震动开关 */
    fun soundOn(context: Context): Boolean = prefs(context).getBoolean("sound_on", true)
    fun setSoundOn(context: Context, value: Boolean) {
        prefs(context).edit().putBoolean("sound_on", value).apply()
    }

    fun vibrateOn(context: Context): Boolean = prefs(context).getBoolean("vibrate_on", true)
    fun setVibrateOn(context: Context, value: Boolean) {
        prefs(context).edit().putBoolean("vibrate_on", value).apply()
    }

    /**
     * 倒计时语音包（v1.4）：female 女声（默认）/ male 男声 / system 系统语音。
     * 女声/男声用内置预录普通话音频（倒计时读秒与固定短语），不依赖手机系统语音，
     * 本机没有普通话语音时也不会变成粤语；system 则全部走系统 TTS（MandarinTts 白名单）。
     */
    fun voicePack(context: Context): String =
        prefs(context).getString("voice_pack", "female") ?: "female"

    fun setVoicePack(context: Context, value: String) {
        prefs(context).edit().putString("voice_pack", value).apply()
    }

    // ---------------- 震感记录 ----------------

    /** 震感等级：0 无感 / 1 轻微 / 2 强烈。按 eventId 保存。 */
    fun saveFelt(context: Context, eventId: String, level: Int, location: String, mag: Double) {
        val p = prefs(context)
        val arr = try {
            JSONArray(p.getString("felt_reports", "[]") ?: "[]")
        } catch (_: Exception) {
            JSONArray()
        }
        // 同一地震只保留最新一条
        val kept = JSONArray()
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            if (o.optString("eventId") != eventId) kept.put(o)
        }
        kept.put(JSONObject().apply {
            put("eventId", eventId)
            put("level", level)
            put("location", location)
            put("magnitude", mag)
            put("time", System.currentTimeMillis())
        })
        p.edit().putString("felt_reports", kept.toString()).apply()
    }

    fun feltLevel(context: Context, eventId: String): Int {
        val arr = feltReports(context)
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            if (o.optString("eventId") == eventId) return o.optInt("level", -1)
        }
        return -1
    }

    fun feltReports(context: Context): JSONArray {
        return try {
            JSONArray(prefs(context).getString("felt_reports", "[]") ?: "[]")
        } catch (_: Exception) {
            JSONArray()
        }
    }

    // ---------------- 家庭应急联系人 ----------------

    fun contacts(context: Context): JSONArray {
        return try {
            JSONArray(prefs(context).getString("family_contacts", "[]") ?: "[]")
        } catch (_: Exception) {
            JSONArray()
        }
    }

    fun addContact(context: Context, name: String, phone: String) {
        val arr = contacts(context)
        arr.put(JSONObject().apply {
            put("name", name)
            put("phone", phone)
        })
        prefs(context).edit().putString("family_contacts", arr.toString()).apply()
    }

    fun removeContact(context: Context, index: Int) {
        val arr = contacts(context)
        if (index < 0 || index >= arr.length()) return
        val kept = JSONArray()
        for (i in 0 until arr.length()) {
            if (i != index) kept.put(arr.get(i))
        }
        prefs(context).edit().putString("family_contacts", kept.toString()).apply()
    }

    // ---------------- 家庭安全自查（6 项） ----------------

    val SAFETY_ITEMS = listOf(
        "应急包已备好（水、干粮、急救包、充电宝）",
        "高处重物已固定，家具不易倾倒",
        "全家人都知道附近应急避难场所",
        "家庭应急联系人已存好电话",
        "全家演练过一次地震避险",
        "知道燃气和电源总开关的位置"
    )

    fun safetyChecked(context: Context, index: Int): Boolean =
        prefs(context).getBoolean("safety_$index", false)

    fun setSafetyChecked(context: Context, index: Int, value: Boolean) {
        prefs(context).edit().putBoolean("safety_$index", value).apply()
    }

    fun safetyProgress(context: Context): Int =
        SAFETY_ITEMS.indices.count { safetyChecked(context, it) }

    // ---------------- 预警记录 / 播报记录 ----------------

    /**
     * v1.6.1 扩展为“播报记录”：每次播报都记一条——全屏预警（kind="warning"，
     * leadSec 为提前秒数）和未达预警的通知/语音（kind="notification"，leadSec=-1）。
     * type: "real" 真实 / "test" 测试预览（测试仍用老字段，不写来源等新字段）。
     * eventKey 为事件稳定键（QuakeMath.canonicalEventKey）：同一场地震从多路
     * 数据源先后报来时，只更新已有条目（震级/地点/来源/第几报取最新），不重复记。
     * 新字段全部可选，老版本写下的记录没有这些字段，读取时按缺省处理。
     */
    fun addAlertHistory(
        context: Context,
        type: String,
        location: String,
        magnitude: Double,
        leadSec: Int,
        eventId: String = "",
        source: String = "",
        reportNum: Int = 0,
        kind: String = "",
        eventKey: String = "",
        originTime: Long = 0L
    ) {
        val p = prefs(context)
        val arr = try {
            JSONArray(p.getString("alert_history", "[]") ?: "[]")
        } catch (_: Exception) {
            JSONArray()
        }
        val realKind = when {
            kind.isNotEmpty() -> kind
            type == "test" -> "test"
            else -> "warning"
        }
        // 同一场地震已记过？按 eventKey 全等，或地点相同且发震时刻差 <60 秒判重，更新它
        var target: JSONObject? = null
        if (eventKey.isNotEmpty() || originTime > 0) {
            for (i in 0 until arr.length()) {
                val o = arr.optJSONObject(i) ?: continue
                val sameKey = eventKey.isNotEmpty() && o.optString("eventKey") == eventKey
                val sameEvent = originTime > 0 && o.optLong("originTime") > 0 &&
                    o.optString("location") == location &&
                    kotlin.math.abs(o.optLong("originTime") - originTime) < 60_000
                if (sameKey || sameEvent) {
                    target = o
                    break
                }
            }
        }
        if (target != null) {
            // 修订：地点/震级/来源/第几报取最新；首次播报时间与提前秒数保持原值
            target.put("location", location)
            target.put("magnitude", magnitude)
            if (source.isNotEmpty()) target.put("source", source)
            if (reportNum > 0) target.put("reportNum", reportNum)
            if (eventId.isNotEmpty()) target.put("eventId", eventId)
            if (eventKey.isNotEmpty()) target.put("eventKey", eventKey)
            if (originTime > 0) target.put("originTime", originTime)
        } else {
            arr.put(JSONObject().apply {
                put("type", type)
                put("kind", realKind)
                put("location", location)
                put("magnitude", magnitude)
                put("leadSec", leadSec)
                put("time", System.currentTimeMillis())
                put("eventId", eventId)
                put("source", source)
                put("reportNum", reportNum)
                put("eventKey", eventKey)
                put("originTime", originTime)
            })
        }
        // 只保留最近 50 条
        val kept = JSONArray()
        val start = maxOf(0, arr.length() - 50)
        for (i in start until arr.length()) kept.put(arr.get(i))
        p.edit().putString("alert_history", kept.toString()).apply()
    }

    fun alertHistory(context: Context): JSONArray {
        return try {
            JSONArray(prefs(context).getString("alert_history", "[]") ?: "[]")
        } catch (_: Exception) {
            JSONArray()
        }
    }

    fun clearAlertHistory(context: Context) {
        prefs(context).edit().putString("alert_history", "[]").apply()
    }

    // ---------------- AI 分析缓存（按 eventId） ----------------

    fun aiCache(context: Context, eventId: String): String? =
        prefs(context).getString("ai_$eventId", null)

    fun saveAiCache(context: Context, eventId: String, json: String) {
        prefs(context).edit().putString("ai_$eventId", json).apply()
    }

    // ---------------- 最近地震（完整字段，供列表/详情/AI 用） ----------------

    fun saveRecentFull(context: Context, quakes: List<Quake>) {
        val arr = JSONArray()
        for (q in quakes) {
            arr.put(JSONObject().apply {
                put("eventId", q.eventId)
                put("location", q.location)
                put("magnitude", q.magnitude)
                put("time", q.timeMillis)
                put("depth", q.depthKm ?: -1.0)
                put("latitude", q.latitude)
                put("longitude", q.longitude)
                put("intensity", q.intensity ?: -1)
                // v1.6.1：来源/第几报/报告时间一起存，修订过的记录重读后不丢
                put("source", q.source)
                put("reportNum", q.reportNum)
                put("reportTime", q.reportTimeMillis)
            })
        }
        prefs(context).edit()
            .putString("recent_quakes_full", arr.toString())
            .putLong("last_catalog_at", System.currentTimeMillis())
            .apply()
    }

    /**
     * v1.6.1：用修订后的地震更新本地最近列表（按 sameEvent 判重：归一化 EventID
     * 相等，或地点相同且发震时刻差 <60 秒）。找不到匹配项时追加到队首。
     */
    fun updateRecentQuake(context: Context, quake: Quake) {
        val list = recentFull(context).toMutableList()
        val idx = list.indexOfFirst { QuakeMath.sameEvent(it, quake) }
        if (idx >= 0) list[idx] = quake else list.add(0, quake)
        saveRecentFull(context, list.take(20))
    }

    fun recentFull(context: Context): List<Quake> {
        val out = mutableListOf<Quake>()
        try {
            val arr = JSONArray(
                prefs(context).getString("recent_quakes_full", "[]") ?: "[]"
            )
            for (i in 0 until arr.length()) {
                val o = arr.optJSONObject(i) ?: continue
                out.add(
                    Quake(
                        eventId = o.optString("eventId"),
                        timeMillis = o.optLong("time"),
                        location = o.optString("location"),
                        magnitude = o.optDouble("magnitude"),
                        depthKm = o.optDouble("depth", -1.0).takeIf { it >= 0 },
                        latitude = o.optDouble("latitude"),
                        longitude = o.optDouble("longitude"),
                        intensity = o.optInt("intensity", -1).takeIf { it > 0 },
                        source = o.optString("source", "中国地震台网")
                            .ifEmpty { "中国地震台网" },
                        reportNum = o.optInt("reportNum", 0),
                        reportTimeMillis = o.optLong("reportTime", 0L)
                    )
                )
            }
        } catch (_: Exception) {
        }
        return out
    }

    fun lastCatalogAt(context: Context): Long =
        prefs(context).getLong("last_catalog_at", 0L)
}
