package com.quake.warning

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.Editable
import android.text.SpannableStringBuilder
import android.text.TextWatcher
import android.text.style.ForegroundColorSpan
import android.view.Gravity
import android.view.View
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.HorizontalScrollView
import android.widget.ImageButton
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.google.android.material.bottomnavigation.BottomNavigationView
import okhttp3.Call
import okhttp3.Callback
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import java.io.IOException
import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.TimeZone

/**
 * 主界面（与网页版 v7–v16 同步）：
 * - 底部导航只有 首页 / 我的 两个页签；我的 = 身份卡 + 钻取列表行 + 二级页。
 * - 首页：问候顶栏（圆形搜索）→ 播报条胶囊（约 90 秒一圈，点按暂停）→
 *   Hero 监测卡（状态 + 统计）→ “值得关注”横向海报卡 → 3 个快捷入口 →
 *   “离我最近”→ 最近地震列表（日期分组、震级配色、“24小时最大”“最近最强”徽章，
 *   收起只显示基本信息，点开看详情：台网速报文案、地图、AI 分析、震感记录）。
 * - 监测打开即自动启动；推送断开只在 Hero 卡和底部迷你状态条显示，
 *   不再另弹重复的“推送未连接”提示。
 * - 深色为默认外观（无保存过的外观偏好时）；浅色在“我的 > 提醒方式”里切换。
 */
class MainActivity : AppCompatActivity() {

    private val beijing = TimeZone.getTimeZone("Asia/Shanghai")
    private val client = OkHttpClient()
    private val handler = Handler(Looper.getMainLooper())

    private var dark = true
    private var appliedAppearance = ""
    private var quakes: List<Quake> = emptyList()
    private var weather: WeatherHelper.Forecast? = null
    private var userLat = 0.0
    private var userLon = 0.0

    private var magFilter = 0.0
    private var sortMode = 0 // 0 时间 / 1 距离
    private var searchQuery = ""

    private var tickerPaused = false
    private var tickerStep = 0f
    private var tickerMax = 0
    private val tickerRunnable = object : Runnable {
        override fun run() {
            val sv = findViewById<HorizontalScrollView>(R.id.tickerScroll)
            if (!tickerPaused && tickerMax > 0) {
                val next = sv.scrollX + tickerStep
                if (next >= tickerMax) sv.scrollTo(0, 0) else sv.scrollBy(tickerStep.toInt(), 0)
            }
            handler.postDelayed(this, 50)
        }
    }

    private val cardViews = mutableMapOf<String, View>()
    private val expandedIds = mutableSetOf<String>()

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()
    private fun tc1(): Int = if (dark) 0xFFFFFFFF.toInt() else 0xFF1A2E1A.toInt()
    private fun tc2(): Int = if (dark) 0xFFA8C4A0.toInt() else 0xFF4A6B4A.toInt()
    private fun cardBg(): Int = if (dark) R.drawable.glass_card else R.drawable.glass_card_light

    private fun magColor(mag: Double): Int = when {
        mag < 4.0 -> ContextCompat.getColor(this, R.color.mag_low)
        mag < 5.0 -> ContextCompat.getColor(this, R.color.mag_mid)
        mag < 6.0 -> ContextCompat.getColor(this, R.color.mag_high)
        else -> ContextCompat.getColor(this, R.color.mag_severe)
    }

    private fun prefs() = getSharedPreferences("prefs", Context.MODE_PRIVATE)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        dark = LocalStore.isDark(this)
        appliedAppearance = LocalStore.appearance(this)
        loadUserLocation()
        applyStaticTheme()
        setupTopBar()
        setupBottomNav()
        setupListControls()
        setupShortcuts()
        findViewById<LinearLayout>(R.id.heroCard).setOnClickListener {
            openMyPage("settings")
        }
        findViewById<Button>(R.id.btnHeroRetry).setOnClickListener {
            ContextCompat.startForegroundService(this, Intent(this, WarningService::class.java))
            refreshAll(true)
        }
        findViewById<TextView>(R.id.tvFeaturedHeader).setOnClickListener {
            scrollToList()
        }
        findViewById<LinearLayout>(R.id.tickerCapsule).setOnClickListener {
            toggleTickerPause()
        }
        // 监测打开即自动启动（首次打开默认开）
        if (!prefs().contains("service_wanted")) {
            prefs().edit().putBoolean("service_wanted", true).apply()
        }
        if (prefs().getBoolean("service_wanted", true)) {
            ContextCompat.startForegroundService(this, Intent(this, WarningService::class.java))
        }
        requestPermissionsIfNeeded()
        refreshAll(true)
    }

    override fun onResume() {
        super.onResume()
        // 外观在提醒方式里改过，回来就重建
        if (LocalStore.appearance(this) != appliedAppearance) {
            recreate()
            return
        }
        loadUserLocation()
        refreshStatus()
        renderHomeFromCache()
        renderMy()
    }

    override fun onDestroy() {
        handler.removeCallbacks(tickerRunnable)
        super.onDestroy()
    }

    // ---------------- 外观 ----------------

    private fun applyStaticTheme() {
        if (dark) return // XML 默认就是深色
        findViewById<View>(R.id.rootMain).setBackgroundResource(R.drawable.bg_light)
        findViewById<View>(R.id.heroCard).setBackgroundResource(cardBg())
        findViewById<View>(R.id.tickerCapsule).setBackgroundResource(cardBg())
        findViewById<View>(R.id.myCard).setBackgroundResource(cardBg())
        val t1 = listOf(
            R.id.tvGreeting, R.id.tvCityTop, R.id.tvHeroStatus,
            R.id.tvStatCount, R.id.tvStatMax24, R.id.tvStatMax7,
            R.id.tvFeaturedHeader, R.id.tvNearestHeader, R.id.tvListHeader,
            R.id.tvMyCity
        )
        for (id in t1) findViewById<TextView>(id).setTextColor(tc1())
        val t2 = listOf(
            R.id.tvDate, R.id.tvHeroCity, R.id.tvHeroWeather,
            R.id.tvTickerState, R.id.tvDataStatus, R.id.tvMyStatus,
            R.id.tvMyThresholds, R.id.tvMyDataStatus, R.id.tvMiniStatus
        )
        for (id in t2) findViewById<TextView>(id).setTextColor(tc2())
        findViewById<TextView>(R.id.tvTicker).setTextColor(tc1())
        // 浅色下快捷入口与搜索框也换浅色底
        findViewById<Button>(R.id.btnShortcutPreview).apply {
            setBackgroundResource(cardBg())
            setTextColor(tc1())
        }
        findViewById<Button>(R.id.btnShortcutShelter).apply {
            setBackgroundResource(cardBg())
            setTextColor(tc1())
        }
        findViewById<EditText>(R.id.etSearch).apply {
            setBackgroundResource(cardBg())
            setTextColor(tc1())
        }
    }

    // ---------------- 顶栏 / 导航 ----------------

    private fun setupTopBar() {
        findViewById<TextView>(R.id.tvGreeting).text = "你好"
        findViewById<TextView>(R.id.tvDate).text = WeatherHelper.todayLabel()
        updateCityTop()
        findViewById<ImageButton>(R.id.btnSearch).setOnClickListener {
            val et = findViewById<EditText>(R.id.etSearch)
            if (et.visibility == View.GONE) {
                et.visibility = View.VISIBLE
                et.requestFocus()
            } else {
                et.visibility = View.GONE
                et.setText("")
            }
        }
    }

    private fun updateCityTop() {
        val city = prefs().getString("user_city", "") ?: ""
        findViewById<TextView>(R.id.tvCityTop).text = city.ifEmpty { "未设置城市" }
    }

    private fun setupBottomNav() {
        val nav = findViewById<BottomNavigationView>(R.id.bottomNav)
        nav.setOnItemSelectedListener { item ->
            when (item.itemId) {
                R.id.nav_home -> showHome()
                R.id.nav_my -> showMy()
            }
            true
        }
        nav.selectedItemId = R.id.nav_home
    }

    private fun showHome() {
        findViewById<ScrollView>(R.id.homeScroll).visibility = View.VISIBLE
        findViewById<ScrollView>(R.id.myScroll).visibility = View.GONE
        findViewById<View>(R.id.tickerCapsule).visibility = View.VISIBLE
        findViewById<ImageButton>(R.id.btnSearch).visibility = View.VISIBLE
        if (!tickerPaused && tickerMax > 0) handler.post(tickerRunnable)
    }

    private fun showMy() {
        findViewById<ScrollView>(R.id.homeScroll).visibility = View.GONE
        findViewById<ScrollView>(R.id.myScroll).visibility = View.VISIBLE
        findViewById<View>(R.id.tickerCapsule).visibility = View.GONE
        findViewById<ImageButton>(R.id.btnSearch).visibility = View.GONE
        handler.removeCallbacks(tickerRunnable)
        renderMy()
    }

    private fun openMyPage(page: String) {
        startActivity(Intent(this, MyPageActivity::class.java).apply {
            putExtra("page", page)
        })
    }

    private fun setupShortcuts() {
        findViewById<Button>(R.id.btnShortcutPreview).setOnClickListener { openMyPage("preview") }
        findViewById<Button>(R.id.btnShortcutShelter).setOnClickListener { openMyPage("shelter") }
        findViewById<Button>(R.id.btnShortcutGuide).setOnClickListener { openMyPage("guide") }
    }

    private fun scrollToList() {
        val sv = findViewById<ScrollView>(R.id.homeScroll)
        val target = findViewById<LinearLayout>(R.id.llQuakes)
        sv.post {
            val loc = IntArray(2)
            target.getLocationOnScreen(loc)
            val sloc = IntArray(2)
            sv.getLocationOnScreen(sloc)
            sv.smoothScrollTo(0, sv.scrollY + (loc[1] - sloc[1]) - dp(16))
        }
    }

    // ---------------- 位置 / 权限 / 服务 ----------------

    private fun loadUserLocation() {
        userLat = prefs().getFloat("user_lat", 0f).toDouble()
        userLon = prefs().getFloat("user_lon", 0f).toDouble()
    }

    private fun requestPermissionsIfNeeded() {
        val needed = mutableListOf<String>()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
            != PackageManager.PERMISSION_GRANTED
        ) {
            needed.add(Manifest.permission.POST_NOTIFICATIONS)
        }
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
            != PackageManager.PERMISSION_GRANTED
        ) {
            needed.add(Manifest.permission.ACCESS_FINE_LOCATION)
        }
        if (needed.isNotEmpty()) {
            ActivityCompat.requestPermissions(this, needed.toTypedArray(), 101)
        }
    }

    // ---------------- 状态 ----------------

    /** 推送状态只在这里显示（Hero 卡 + 底部迷你状态条），不另弹重复提示。 */
    private fun refreshStatus() {
        val status = prefs().getString("service_status", "stopped") ?: "stopped"
        val last = prefs().getLong("last_update", 0L)
        val heroDot = findViewById<TextView>(R.id.tvHeroDot)
        val heroStatus = findViewById<TextView>(R.id.tvHeroStatus)
        val btnRetry = findViewById<Button>(R.id.btnHeroRetry)
        val mini = findViewById<TextView>(R.id.tvMiniStatus)
        val timeText = if (last > 0) {
            val diffMin = (System.currentTimeMillis() - last) / 60000
            if (diffMin < 1) "刚刚更新" else "$diffMin 分钟前更新"
        } else {
            "尚未更新"
        }
        when (status) {
            "ws_connected" -> {
                heroDot.setTextColor(ContextCompat.getColor(this, R.color.neon_green))
                heroStatus.text = "守护中"
                btnRetry.visibility = View.GONE
                mini.text = "推送已连接 · $timeText"
            }
            "polling" -> {
                heroDot.setTextColor(ContextCompat.getColor(this, R.color.status_warn))
                heroStatus.text = "推送断开 · 轮询兜底中（30 秒一次）"
                btnRetry.visibility = View.VISIBLE
                mini.text = "推送断开 · 轮询兜底中 · $timeText"
            }
            "connecting" -> {
                heroDot.setTextColor(ContextCompat.getColor(this, R.color.status_warn))
                heroStatus.text = "正在连接台网推送通道…"
                btnRetry.visibility = View.GONE
                mini.text = "正在连接推送通道…"
            }
            else -> {
                heroDot.setTextColor(ContextCompat.getColor(this, R.color.status_warn))
                heroStatus.text = "服务未运行"
                btnRetry.visibility = View.VISIBLE
                mini.text = "服务未运行 · $timeText"
            }
        }
        val city = prefs().getString("user_city", "") ?: ""
        findViewById<TextView>(R.id.tvHeroCity).text =
            if (city.isNotEmpty()) "监测城市：$city" else "未设置监测城市，请去“我的 > 预警设置”选城市"
        findViewById<TextView>(R.id.tvDataStatus).text =
            "数据来源：中国地震台网 · " +
                if (LocalStore.lastCatalogAt(this) > 0) {
                    "更新于 " + SimpleDateFormat("HH:mm:ss", Locale.CHINA).apply {
                        timeZone = beijing
                    }.format(Date(LocalStore.lastCatalogAt(this)))
                } else {
                    "尚未更新"
                }
    }

    // ---------------- 数据拉取 ----------------

    private fun refreshAll(showSkeleton: Boolean) {
        if (showSkeleton) {
            findViewById<LinearLayout>(R.id.llSkeleton).visibility = View.VISIBLE
        }
        val request = Request.Builder().url(WarningService.CATALOG_URL).build()
        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                runOnUiThread {
                    findViewById<LinearLayout>(R.id.llSkeleton).visibility = View.GONE
                    Toast.makeText(this@MainActivity, "获取失败：${e.message}", Toast.LENGTH_SHORT).show()
                    refreshStatus()
                }
            }

            override fun onResponse(call: Call, response: Response) {
                val body = response.body?.string() ?: return
                val list = EewParser.parseCatalog(body)
                LocalStore.saveRecentFull(this@MainActivity, list.take(20))
                runOnUiThread {
                    findViewById<LinearLayout>(R.id.llSkeleton).visibility = View.GONE
                    quakes = LocalStore.recentFull(this@MainActivity)
                    renderHome()
                    refreshStatus()
                }
            }
        })
        if (userLat != 0.0 || userLon != 0.0) {
            WeatherHelper.fetch(userLat, userLon) { f ->
                weather = f
                runOnUiThread {
                    renderTicker()
                    renderHeroWeather()
                }
            }
        }
        findViewById<Button>(R.id.btnRefreshQuakes).setOnClickListener { refreshAll(true) }
    }

    private fun renderHomeFromCache() {
        quakes = LocalStore.recentFull(this)
        renderHome()
        renderTicker()
        renderHeroWeather()
    }

    private fun renderHeroWeather() {
        val tv = findViewById<TextView>(R.id.tvHeroWeather)
        val f = weather
        tv.text = if (f == null) {
            ""
        } else {
            val temp = f.tempNow?.let { "${it.toInt()}℃ " } ?: ""
            "当地天气：${WeatherHelper.weatherCodeText(f.codeNow)} $temp" +
                "风速${f.windNow.toInt()}km/h"
        }
    }

    // ---------------- 播报条 ----------------

    private fun renderTicker() {
        val items = mutableListOf<Pair<String, Int>>()
        val timeFmt = SimpleDateFormat("HH:mm", Locale.CHINA).apply { timeZone = beijing }
        for (q in quakes.take(3)) {
            items.add(
                "${q.magnitude}级 ${q.location} · ${timeFmt.format(Date(q.timeMillis))}" to
                    magColor(q.magnitude)
            )
        }
        weather?.let { f ->
            for ((text, level) in WeatherHelper.tickerWeatherItems(f)) {
                val color = when (level) {
                    2 -> ContextCompat.getColor(this, R.color.mag_severe)
                    1 -> ContextCompat.getColor(this, R.color.mag_mid)
                    else -> 0xFF7FB3D5.toInt()
                }
                items.add(text to color)
            }
        }
        if (items.isEmpty()) {
            findViewById<TextView>(R.id.tvTicker).text = "正在获取最新地震与天气播报…"
            return
        }
        val sb = SpannableStringBuilder()
        for ((text, color) in items) {
            if (sb.isNotEmpty()) sb.append("      ")
            val start = sb.length
            sb.append("● ")
            sb.setSpan(
                ForegroundColorSpan(color), start, sb.length,
                SpannableStringBuilder.SPAN_EXCLUSIVE_EXCLUSIVE
            )
            sb.append(text)
        }
        val tv = findViewById<TextView>(R.id.tvTicker)
        tv.text = sb
        findViewById<TextView>(R.id.tvTickerDot)
            .setTextColor(items.first().second)
        startTickerScroll()
    }

    private fun startTickerScroll() {
        handler.removeCallbacks(tickerRunnable)
        if (LocalStore.reducedMotion(this)) {
            findViewById<TextView>(R.id.tvTickerState).text = "已暂停（已减少动态）"
            return
        }
        val sv = findViewById<HorizontalScrollView>(R.id.tickerScroll)
        val tv = findViewById<TextView>(R.id.tvTicker)
        sv.post {
            val total = tv.width - sv.width
            if (total > 0) {
                tickerMax = total
                tickerStep = total / (90f * 20f) // 约 90 秒一圈
                if (!tickerPaused) {
                    findViewById<TextView>(R.id.tvTickerState).text = "滚动中"
                    handler.post(tickerRunnable)
                }
            }
        }
    }

    private fun toggleTickerPause() {
        tickerPaused = !tickerPaused
        findViewById<TextView>(R.id.tvTickerState).text =
            if (tickerPaused) "已暂停" else "滚动中"
        if (!tickerPaused) handler.post(tickerRunnable)
        else handler.removeCallbacks(tickerRunnable)
    }

    // ---------------- 首页渲染 ----------------

    private fun renderHome() {
        renderHeroStats()
        renderFeatured()
        renderNearest()
        renderList()
        updateCityTop()
    }

    private fun renderHeroStats() {
        val now = System.currentTimeMillis()
        val last24 = quakes.filter { it.timeMillis >= now - 24 * 3600_000L }
        val last7 = quakes.filter { it.timeMillis >= now - 7 * 24 * 3600_000L }
        findViewById<TextView>(R.id.tvStatCount).text = last24.size.toString()
        findViewById<TextView>(R.id.tvStatMax24).text =
            last24.maxByOrNull { it.magnitude }?.let { "${it.magnitude}级" } ?: "-"
        findViewById<TextView>(R.id.tvStatMax7).text =
            last7.maxByOrNull { it.magnitude }?.let { "${it.magnitude}级" } ?: "-"
    }

    private fun renderFeatured() {
        val ll = findViewById<LinearLayout>(R.id.llFeatured)
        ll.removeAllViews()
        if (quakes.isEmpty()) return
        val now = System.currentTimeMillis()
        val latest = quakes.maxByOrNull { it.timeMillis }
        val max24 = quakes.filter { it.timeMillis >= now - 24 * 3600_000L }
            .maxByOrNull { it.magnitude }
        val max7 = quakes.filter { it.timeMillis >= now - 7 * 24 * 3600_000L }
            .maxByOrNull { it.magnitude }
        val seen = mutableSetOf<String>()
        val cards = listOf(
            "最新一场" to latest,
            "24小时最大" to max24,
            "近7天最大" to max7
        )
        for ((label, q) in cards) {
            if (q == null || !seen.add(q.eventId)) continue
            ll.addView(buildFeaturedCard(label, q))
        }
    }

    private fun buildFeaturedCard(label: String, q: Quake): View {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundResource(cardBg())
            setPadding(dp(14), dp(14), dp(14), dp(14))
            val lp = LinearLayout.LayoutParams(dp(250), dp(150))
            lp.marginEnd = dp(12)
            layoutParams = lp
        }
        // 震级大数字 + 地震波纹环
        val ringBox = android.widget.RelativeLayout(this).apply {
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(64)
            )
        }
        val ring1 = android.widget.ImageView(this).apply {
            setImageResource(R.drawable.wave_ring)
            alpha = 0.6f
            val lp = android.widget.RelativeLayout.LayoutParams(dp(58), dp(58))
            lp.addRule(android.widget.RelativeLayout.CENTER_IN_PARENT)
            layoutParams = lp
        }
        val ring2 = android.widget.ImageView(this).apply {
            setImageResource(R.drawable.wave_ring)
            alpha = 0.9f
            val lp = android.widget.RelativeLayout.LayoutParams(dp(38), dp(38))
            lp.addRule(android.widget.RelativeLayout.CENTER_IN_PARENT)
            layoutParams = lp
        }
        val tvMag = TextView(this).apply {
            text = "${q.magnitude}"
            textSize = 30f
            setTypeface(null, android.graphics.Typeface.BOLD)
            setTextColor(magColor(q.magnitude))
            gravity = Gravity.CENTER
            val lp = android.widget.RelativeLayout.LayoutParams(
                android.widget.RelativeLayout.LayoutParams.WRAP_CONTENT,
                android.widget.RelativeLayout.LayoutParams.WRAP_CONTENT
            )
            lp.addRule(android.widget.RelativeLayout.CENTER_IN_PARENT)
            layoutParams = lp
        }
        ringBox.addView(ring1)
        ringBox.addView(ring2)
        ringBox.addView(tvMag)
        card.addView(ringBox)
        card.addView(TextView(this).apply {
            text = label
            textSize = 12f
            setTextColor(tc2())
            gravity = Gravity.CENTER
        })
        card.addView(TextView(this).apply {
            text = q.location
            textSize = 15f
            setTypeface(null, android.graphics.Typeface.BOLD)
            setTextColor(tc1())
            gravity = Gravity.CENTER
            val lp = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
            lp.topMargin = dp(4)
            layoutParams = lp
        })
        card.addView(TextView(this).apply {
            text = SimpleDateFormat("MM-dd HH:mm", Locale.CHINA).apply {
                timeZone = beijing
            }.format(Date(q.timeMillis))
            textSize = 12f
            setTextColor(tc2())
            gravity = Gravity.CENTER
        })
        card.setOnClickListener { locateQuake(q.eventId) }
        return card
    }

    private fun renderNearest() {
        val ll = findViewById<LinearLayout>(R.id.llNearest)
        ll.removeAllViews()
        if (userLat == 0.0 && userLon == 0.0) {
            ll.addView(TextView(this).apply {
                text = "设置监测城市后显示离你最近的地震"
                textSize = 13f
                setTextColor(tc2())
            })
            return
        }
        val nearest = quakes
            .map { q -> q to QuakeMath.distanceKm(userLat, userLon, q.latitude, q.longitude) }
            .sortedBy { it.second }
            .take(3)
        val timeFmt = SimpleDateFormat("MM-dd HH:mm", Locale.CHINA).apply { timeZone = beijing }
        for ((q, dist) in nearest) {
            val intensity = q.intensity ?: QuakeMath.estimateIntensity(q.magnitude, dist)
            val arrival = QuakeMath.sArrivalMillis(q.timeMillis, dist)
            val sText = if (arrival <= System.currentTimeMillis()) "S波已到达"
            else "S波将于${(arrival - System.currentTimeMillis()) / 1000}秒后到达"
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setBackgroundResource(cardBg())
                setPadding(dp(12), dp(10), dp(12), dp(10))
                val lp = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                )
                lp.bottomMargin = dp(8)
                layoutParams = lp
            }
            row.addView(TextView(this).apply {
                text = "${q.magnitude}"
                textSize = 15f
                setTypeface(null, android.graphics.Typeface.BOLD)
                setTextColor(magColor(q.magnitude))
            })
            row.addView(TextView(this).apply {
                text = "  ${q.location} · 约${dist.toInt()}公里 · 预计烈度${intensity}度 · $sText"
                textSize = 14f
                setTextColor(tc1())
                val lp = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                layoutParams = lp
            })
            row.addView(TextView(this).apply {
                text = timeFmt.format(Date(q.timeMillis))
                textSize = 12f
                setTextColor(tc2())
            })
            row.setOnClickListener { locateQuake(q.eventId) }
            ll.addView(row)
        }
    }

    // ---------------- 列表：筛选 / 搜索 / 排序 / 分组 / 徽章 ----------------

    private fun setupListControls() {
        val spinnerFilter = findViewById<Spinner>(R.id.spinnerFilter)
        spinnerFilter.adapter = ArrayAdapter(
            this, android.R.layout.simple_spinner_item,
            listOf("全部", "4级以上", "5级以上")
        ).apply {
            setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        }
        spinnerFilter.onItemSelectedListener =
            object : android.widget.AdapterView.OnItemSelectedListener {
                override fun onItemSelected(
                    parent: android.widget.AdapterView<*>?, view: View?,
                    position: Int, id: Long
                ) {
                    magFilter = when (position) {
                        1 -> 4.0
                        2 -> 5.0
                        else -> 0.0
                    }
                    renderList()
                }

                override fun onNothingSelected(parent: android.widget.AdapterView<*>?) {}
            }
        val spinnerSort = findViewById<Spinner>(R.id.spinnerSort)
        spinnerSort.adapter = ArrayAdapter(
            this, android.R.layout.simple_spinner_item,
            listOf("按时间", "按距离")
        ).apply {
            setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        }
        spinnerSort.onItemSelectedListener =
            object : android.widget.AdapterView.OnItemSelectedListener {
                override fun onItemSelected(
                    parent: android.widget.AdapterView<*>?, view: View?,
                    position: Int, id: Long
                ) {
                    sortMode = position
                    renderList()
                }

                override fun onNothingSelected(parent: android.widget.AdapterView<*>?) {}
            }
        findViewById<EditText>(R.id.etSearch).addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) {
                searchQuery = s?.toString()?.trim() ?: ""
                renderList()
            }
        })
    }

    private fun filteredQuakes(): List<Quake> {
        var list = quakes.filter { it.magnitude >= magFilter }
        if (searchQuery.isNotEmpty()) {
            list = list.filter { it.location.contains(searchQuery) }
        }
        return when (sortMode) {
            1 -> {
                if (userLat == 0.0 && userLon == 0.0) {
                    list.sortedByDescending { it.timeMillis }
                } else {
                    list.sortedBy {
                        QuakeMath.distanceKm(userLat, userLon, it.latitude, it.longitude)
                    }
                }
            }
            else -> list.sortedByDescending { it.timeMillis }
        }
    }

    private fun dayGroup(timeMillis: Long): String {
        val fmt = SimpleDateFormat("yyyy-MM-dd", Locale.CHINA).apply { timeZone = beijing }
        val day = fmt.format(Date(timeMillis))
        val today = fmt.format(Date())
        val cal = Calendar.getInstance(beijing).apply { add(Calendar.DAY_OF_YEAR, -1) }
        val yesterday = fmt.format(cal.time)
        return when (day) {
            today -> "今天"
            yesterday -> "昨天"
            else -> "更早"
        }
    }

    private fun renderList() {
        val ll = findViewById<LinearLayout>(R.id.llQuakes)
        ll.removeAllViews()
        cardViews.clear()
        val list = filteredQuakes()
        if (list.isEmpty()) {
            ll.addView(TextView(this).apply {
                text = if (quakes.isEmpty()) "点“刷新”获取台网最新速报" else "没有符合条件的地震"
                textSize = 14f
                setTextColor(tc2())
                setPadding(dp(4), dp(8), dp(4), dp(8))
            })
            return
        }
        val now = System.currentTimeMillis()
        val max24 = list.filter { it.timeMillis >= now - 24 * 3600_000L }
            .maxByOrNull { it.magnitude }
        val max7 = list.filter { it.timeMillis >= now - 7 * 24 * 3600_000L }
            .maxByOrNull { it.magnitude }
        var lastGroup: String? = null
        for (q in list) {
            val group = dayGroup(q.timeMillis)
            if (group != lastGroup) {
                lastGroup = group
                ll.addView(TextView(this).apply {
                    text = group
                    textSize = 13f
                    setTypeface(null, android.graphics.Typeface.BOLD)
                    setTextColor(tc2())
                    val lp = LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        LinearLayout.LayoutParams.WRAP_CONTENT
                    )
                    lp.topMargin = dp(10)
                    lp.bottomMargin = dp(6)
                    layoutParams = lp
                })
            }
            val badges = mutableListOf<String>()
            if (max24 != null && q.eventId == max24.eventId) badges.add("24小时最大")
            if (max7 != null && q.eventId == max7.eventId) badges.add("最近最强")
            ll.addView(buildQuakeCard(q, badges))
        }
    }

    // ---------------- 地震卡片（收起基本信息，点开展开详情） ----------------

    private fun buildQuakeCard(q: Quake, badges: List<String>): View {
        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundResource(cardBg())
            setPadding(dp(12), dp(12), dp(12), dp(12))
            val lp = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
            lp.bottomMargin = dp(8)
            layoutParams = lp
        }
        cardViews[q.eventId] = container

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val magCircle = TextView(this).apply {
            text = "${q.magnitude}"
            textSize = 15f
            setTypeface(null, android.graphics.Typeface.BOLD)
            setTextColor(0xFFFFFFFF.toInt())
            gravity = Gravity.CENTER
            val bg = ContextCompat.getDrawable(
                this@MainActivity, R.drawable.mag_circle
            )?.mutate() as? GradientDrawable
            bg?.setColor(magColor(q.magnitude))
            background = bg
            val lp = LinearLayout.LayoutParams(dp(52), dp(52))
            layoutParams = lp
        }
        val middle = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            val lp = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            lp.marginStart = dp(10)
            layoutParams = lp
        }
        middle.addView(TextView(this).apply {
            text = q.location
            textSize = 16f
            setTypeface(null, android.graphics.Typeface.BOLD)
            setTextColor(tc1())
        })
        val hasLoc = userLat != 0.0 || userLon != 0.0
        val distText = if (hasLoc) {
            " · 距你约${QuakeMath.distanceKm(userLat, userLon, q.latitude, q.longitude).toInt()}公里"
        } else ""
        middle.addView(TextView(this).apply {
            text = SimpleDateFormat("MM-dd HH:mm", Locale.CHINA).apply {
                timeZone = beijing
            }.format(Date(q.timeMillis)) + distText
            textSize = 13f
            setTextColor(tc2())
        })
        if (badges.isNotEmpty()) {
            val badgeRow = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                val lp = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                )
                lp.topMargin = dp(4)
                layoutParams = lp
            }
            for (b in badges) {
                badgeRow.addView(TextView(this).apply {
                    text = b
                    textSize = 11f
                    setTextColor(ContextCompat.getColor(this@MainActivity, R.color.neon_green))
                    setBackgroundResource(R.drawable.badge_bg)
                    setPadding(dp(8), dp(3), dp(8), dp(3))
                    val blp = LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.WRAP_CONTENT,
                        LinearLayout.LayoutParams.WRAP_CONTENT
                    )
                    blp.marginEnd = dp(6)
                    layoutParams = blp
                })
            }
            middle.addView(badgeRow)
        }
        val chevron = TextView(this).apply {
            text = "›"
            textSize = 22f
            setTextColor(tc2())
        }
        header.addView(magCircle)
        header.addView(middle)
        header.addView(chevron)
        container.addView(header)

        // 详情（默认收起）
        val detail = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            visibility = if (expandedIds.contains(q.eventId)) View.VISIBLE else View.GONE
            val lp = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
            lp.topMargin = dp(10)
            layoutParams = lp
        }
        // 台网速报文案（行内展示，不跳微博）
        detail.addView(TextView(this).apply {
            text = flashReportText(q)
            textSize = 14f
            setTextColor(tc1())
        })
        detail.addView(Button(this).apply {
            text = "在地图中查看震中"
            setOnClickListener {
                val url = "https://uri.amap.com/marker?position=${q.longitude},${q.latitude}" +
                    "&name=" + URLEncoder.encode(q.location, "UTF-8") +
                    "&coordinate=gaode"
                startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
            }
        })
        // AI 分析区
        detail.addView(TextView(this).apply {
            text = "AI 分析"
            textSize = 15f
            setTypeface(null, android.graphics.Typeface.BOLD)
            setTextColor(tc1())
            val lp = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
            lp.topMargin = dp(12)
            layoutParams = lp
        })
        val tvAiLocal = TextView(this).apply {
            text = ""
            textSize = 13f
            setTextColor(tc2())
            detail.addView(this)
        }
        val tvAiHistory = TextView(this).apply {
            text = "正在查询历史地震…"
            textSize = 13f
            setTextColor(tc2())
            val lp = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
            lp.topMargin = dp(8)
            layoutParams = lp
            detail.addView(this)
        }
        val tvAiCasualty = TextView(this).apply {
            text = "正在查询伤亡数据…"
            textSize = 13f
            setTextColor(tc2())
            val lp = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
            lp.topMargin = dp(8)
            layoutParams = lp
            detail.addView(this)
        }
        // 震感记录
        val feltRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            val lp = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
            lp.topMargin = dp(12)
            layoutParams = lp
        }
        feltRow.addView(TextView(this).apply {
            text = "你感受到震动了吗？"
            textSize = 13f
            setTextColor(tc1())
            val lp = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            layoutParams = lp
        })
        val tvFeltStatus = TextView(this).apply {
            textSize = 12f
            setTextColor(tc2())
            feltRow.addView(this)
        }
        val updateFelt = {
            val level = LocalStore.feltLevel(this, q.eventId)
            tvFeltStatus.text = when (level) {
                0 -> "已记录：无感"
                1 -> "已记录：轻微震感"
                2 -> "已记录：强烈震感"
                else -> ""
            }
        }
        updateFelt()
        for ((label, level) in listOf("无感" to 0, "轻微" to 1, "强烈" to 2)) {
            feltRow.addView(Button(this).apply {
                text = label
                setOnClickListener {
                    LocalStore.saveFelt(this@MainActivity, q.eventId, level, q.location, q.magnitude)
                    updateFelt()
                    Toast.makeText(this@MainActivity, "震感已记录", Toast.LENGTH_SHORT).show()
                }
            })
        }
        detail.addView(feltRow)
        container.addView(detail)

        header.setOnClickListener {
            val open = detail.visibility != View.VISIBLE
            detail.visibility = if (open) View.VISIBLE else View.GONE
            chevron.rotation = if (open) 90f else 0f
            if (open) {
                expandedIds.add(q.eventId)
                // 每次展开都调 loadAi：有缓存时直接用缓存，不重复联网
                loadAi(q, tvAiLocal, tvAiHistory, tvAiCasualty)
            } else {
                expandedIds.remove(q.eventId)
            }
        }
        // 列表重建后仍保持展开态时，立即恢复 AI 内容（走缓存，不重复联网）
        if (expandedIds.contains(q.eventId)) {
            loadAi(q, tvAiLocal, tvAiHistory, tvAiCasualty)
        }
        return container
    }

    /** 台网速报标准格式文案（由目录真实字段拼成，行内展示，不跳微博）。 */
    private fun flashReportText(q: Quake): String {
        val timeText = SimpleDateFormat("MM月dd日HH时mm分", Locale.CHINA).apply {
            timeZone = beijing
        }.format(Date(q.timeMillis))
        val depthText = q.depthKm?.let { "，震源深度${it.toInt()}千米" } ?: ""
        return "中国地震台网正式测定：$timeText，${q.location}发生${q.magnitude}级地震$depthText。" +
            "（@中国地震台网速报）"
    }

    private fun loadAi(
        q: Quake,
        tvLocal: TextView,
        tvHistory: TextView,
        tvCasualty: TextView
    ) {
        tvLocal.text = AiAnalysis.buildLocalAnalysis(q, userLat, userLon)
        AiAnalysis.load(this, q, userLat, userLon) { result ->
            runOnUiThread {
                tvHistory.text = when (result.historyState) {
                    AiAnalysis.STATE_OK -> result.historyText
                    AiAnalysis.STATE_NONE -> "历史最大地震：该区域公开目录内暂无记录"
                    AiAnalysis.STATE_FAILED -> result.historyText ?: "历史地震查询失败"
                    else -> "正在查询历史地震…"
                }
                tvCasualty.text = when (result.casualtyState) {
                    AiAnalysis.STATE_OK -> result.casualtyText
                    AiAnalysis.STATE_NONE -> "当时伤亡情况：暂无公开伤亡数据"
                    AiAnalysis.STATE_FAILED -> result.casualtyText ?: "伤亡数据查询失败"
                    else -> "正在查询伤亡数据…"
                }
            }
        }
    }

    private fun locateQuake(eventId: String) {
        val v = cardViews[eventId] ?: return
        // 先切到首页
        findViewById<BottomNavigationView>(R.id.bottomNav).selectedItemId = R.id.nav_home
        v.post {
            // 展开该条详情
            val header = (v as LinearLayout).getChildAt(0)
            val detail = v.getChildAt(1)
            if (detail.visibility != View.VISIBLE) header.performClick()
            val sv = findViewById<ScrollView>(R.id.homeScroll)
            val loc = IntArray(2)
            v.getLocationOnScreen(loc)
            val sloc = IntArray(2)
            sv.getLocationOnScreen(sloc)
            sv.smoothScrollTo(0, sv.scrollY + (loc[1] - sloc[1]) - dp(120))
        }
    }

    // ---------------- 我的 ----------------

    private fun renderMy() {
        val city = prefs().getString("user_city", "") ?: ""
        findViewById<TextView>(R.id.tvMyCity).text =
            if (city.isNotEmpty()) city else "未设置监测城市"
        val status = prefs().getString("service_status", "stopped") ?: "stopped"
        findViewById<TextView>(R.id.tvMyStatus).text = when (status) {
            "ws_connected" -> "守护中 · 推送已连接"
            "polling" -> "推送断开 · 轮询兜底中"
            "connecting" -> "正在连接…"
            else -> "服务未运行"
        }
        val magLabel = prefs().getString("mag_label", "不限") ?: "不限"
        val intLabel = prefs().getString("intensity_label", "不限") ?: "不限"
        val leadLabel = prefs().getString("lead_label", "5秒") ?: "5秒"
        findViewById<TextView>(R.id.tvMyThresholds).text =
            "震级≥$magLabel · 烈度≥$intLabel · 提前$leadLabel"
        val statusText = prefs().getString("service_status", "stopped") ?: "stopped"
        val last = prefs().getLong("last_update", 0L)
        findViewById<TextView>(R.id.tvMyDataStatus).text =
            "推送：$statusText · " +
                if (last > 0) {
                    "上次刷新 " + SimpleDateFormat("HH:mm:ss", Locale.CHINA).apply {
                        timeZone = beijing
                    }.format(Date(last))
                } else {
                    "尚未刷新"
                } + " · 数据来源：中国地震台网（Wolfx 接口）· 天气：Open-Meteo"

        val voiceText = if (prefs().getBoolean("voice_on", true)) "开" else "关"
        val appearanceText = if (LocalStore.isDark(this)) "深色" else "浅色"
        val rows = listOf(
            Triple("预警设置", "震级≥$magLabel · 烈度≥$intLabel · 提前$leadLabel", "settings"),
            Triple("提醒方式", "$appearanceText · 语音播报$voiceText", "remind"),
            Triple("播报预览", "", "preview"),
            Triple("预警记录", "${LocalStore.alertHistory(this).length()} 条", "history"),
            Triple("震感记录", "${LocalStore.feltReports(this).length()} 条", "felt"),
            Triple("避难场所", "", "shelter"),
            Triple("家庭联系人", "${LocalStore.contacts(this).length()} 人", "contacts"),
            Triple(
                "家庭安全自查",
                "已完成 ${LocalStore.safetyProgress(this)}/${LocalStore.SAFETY_ITEMS.size} 项",
                "safety"
            ),
            Triple("帮助与支持", "", "help"),
            Triple("应急指南", "", "guide"),
            Triple("关于", "版本 1.1", "about")
        )
        val ll = findViewById<LinearLayout>(R.id.llMyRows)
        ll.removeAllViews()
        for ((title, value, page) in rows) {
            ll.addView(buildMyRow(title, value, page))
        }
    }

    private fun buildMyRow(title: String, value: String, page: String): View {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setBackgroundResource(cardBg())
            setPadding(dp(16), dp(14), dp(16), dp(14))
            val lp = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
            lp.bottomMargin = dp(8)
            layoutParams = lp
        }
        row.addView(TextView(this).apply {
            text = title
            textSize = 16f
            setTextColor(tc1())
            val lp = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            layoutParams = lp
        })
        if (value.isNotEmpty()) {
            row.addView(TextView(this).apply {
                text = value
                textSize = 13f
                setTextColor(tc2())
                val lp = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                )
                lp.marginEnd = dp(8)
                layoutParams = lp
            })
        }
        row.addView(TextView(this).apply {
            text = "›"
            textSize = 18f
            setTypeface(null, android.graphics.Typeface.BOLD)
            setTextColor(0xFF0B0F0B.toInt())
            gravity = Gravity.CENTER
            background = ContextCompat.getDrawable(this@MainActivity, R.drawable.arrow_circle)
            val lp = LinearLayout.LayoutParams(dp(28), dp(28))
            layoutParams = lp
        })
        row.setOnClickListener { openMyPage(page) }
        return row
    }
}
