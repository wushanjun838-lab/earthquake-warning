package com.quake.warning

import android.Manifest
import android.animation.ObjectAnimator
import android.app.Dialog
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.Editable
import android.text.SpannableStringBuilder
import android.text.TextWatcher
import android.text.style.ForegroundColorSpan
import android.view.Gravity
import android.view.View
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageButton
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.google.android.material.bottomnavigation.BottomNavigationView
import okhttp3.Call
import okhttp3.Callback
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import org.json.JSONObject
import java.io.IOException
import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.TimeZone

/**
 * 主界面（v1.3：首页夜景地图 + 五页签 + 毛玻璃详情弹窗）：
 * - 底部导航五页签：首页 / 地震地图 / 数据分析 / 预警 / 我的，
 *   各页一个 ScrollView 切换；监测服务（WarningService）常驻，不受切页影响。
 * - 首页：问候顶栏 → 播报条胶囊 → 夜景地图背景（最新震中红点 2 秒脉冲，
 *   半透明聚光卡 + 24小时地震数/近7天最大两块统计）→ 监测状态卡 →
 *   “值得关注”震级着色毛玻璃横向海报卡 → 3 个快捷入口 →
 *   “离我最近”（震中烈度 / 我所在地预计烈度双芯片）→ 最近地震列表
 *   （体感药丸按用户所在地预计烈度算，点开是毛玻璃详情弹窗，不再行内展开）。
 * - 地震地图：USGS / EMSC 全球地震，世界地图上按真实经纬度打点，
 *   点标记看详情卡 + AI 分析；全球地震仅供查看，绝不触发预警弹窗和倒计时。
 * - 数据分析：近 7 天 CENC 目录统计（每日数量、震级分布、最活跃地区，
 *   纯 View 条形图）+ 7 天 AI 总分析（本地规则汇总先行，在线模型后台替换）。
 * - 预警：报警状态与阈值摘要、提醒开关、测试预警、预警记录。
 * - 烈度显示规则（v1.3 修正）：震中烈度只显示台网给的数值；用户所在地
 *   预计烈度一律由震级 + 震中距衰减估算，绝不拿震中烈度当成本地烈度。
 */
class MainActivity : AppCompatActivity() {

    private val beijing = TimeZone.getTimeZone("Asia/Shanghai")
    private val client = OkHttpClient()
    private val handler = Handler(Looper.getMainLooper())

    private var dark = true
    private var appliedAppearance = ""
    private var quakes: List<Quake> = emptyList()
    private var weather: WeatherHelper.Forecast? = null
    private var userLat = 0.0
    private var userLon = 0.0

    private var magFilter = 0.0
    private var sortMode = 0 // 0 时间 / 1 距离
    private var searchQuery = ""

    private var tickerPaused = false
    private var tickerStep = 0f
    private var tickerMax = 0
    private val tickerRunnable = object : Runnable {
        override fun run() {
            val sv = findViewById<HorizontalScrollView>(R.id.tickerScroll)
            if (!tickerPaused && tickerMax > 0) {
                val next = sv.scrollX + tickerStep
                if (next >= tickerMax) sv.scrollTo(0, 0) else sv.scrollBy(tickerStep.toInt(), 0)
            }
            handler.postDelayed(this, 50)
        }
    }

    private var currentTab = "home"

    // 地震地图页
    private var mapQuakes: List<Quake> = emptyList()
    private var mapSource = "usgs" // usgs / emsc
    private var mapRange = "day" // day / week（仅 USGS）
    private var mapLoadedAt = 0L
    private var selectedMapQuake: Quake? = null
    private var selectedMapQuakeSource = ""

    // 数据分析页 AI 汇总
    private var analysisAiDay = ""
    private var analysisAiLoading = false

    // 新地震语音播报去重
    private var seenQuakeIds = mutableSetOf<String>()
    private var firstCatalogLoad = true
    private var newQuakeTts: MandarinTts? = null

    // 首页震中脉冲动画
    private var epiPulseAnimators = mutableListOf<ObjectAnimator>()

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()
    private fun tc1(): Int = if (dark) 0xFFFFFFFF.toInt() else 0xFF1A2E1A.toInt()
    private fun tc2(): Int = if (dark) 0xFFA8C4A0.toInt() else 0xFF4A6B4A.toInt()
    private fun cardBg(): Int = if (dark) R.drawable.glass_card else R.drawable.glass_card_light

    private fun magColor(mag: Double): Int = when {
        mag < 4.0 -> ContextCompat.getColor(this, R.color.mag_low)
        mag < 5.0 -> ContextCompat.getColor(this, R.color.mag_mid)
        mag < 6.0 -> ContextCompat.getColor(this, R.color.mag_high)
        else -> ContextCompat.getColor(this, R.color.mag_severe)
    }

    private fun feelColor(local: Int): Int = when {
        local <= 2 -> ContextCompat.getColor(this, R.color.neon_green)
        local <= 4 -> ContextCompat.getColor(this, R.color.mag_mid)
        else -> ContextCompat.getColor(this, R.color.mag_severe)
    }

    private fun prefs() = getSharedPreferences("prefs", Context.MODE_PRIVATE)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        dark = LocalStore.isDark(this)
        appliedAppearance = LocalStore.appearance(this)
        loadUserLocation()
        applyStaticTheme()
        setupTopBar()
        setupBottomNav()
        setupListControls()
        setupShortcuts()
        setupMapPage()
        setupAnalysisPage()
        setupAlertPage()
        findViewById<LinearLayout>(R.id.heroCard).setOnClickListener {
            openMyPage("settings")
        }
        findViewById<Button>(R.id.btnHeroRetry).setOnClickListener {
            ContextCompat.startForegroundService(this, Intent(this, WarningService::class.java))
            refreshAll(true)
        }
        findViewById<TextView>(R.id.tvFeaturedHeader).setOnClickListener {
            scrollToList()
        }
        findViewById<LinearLayout>(R.id.tickerCapsule).setOnClickListener {
            toggleTickerPause()
        }
        findViewById<LinearLayout>(R.id.warnBanner).setOnClickListener {
            findViewById<BottomNavigationView>(R.id.bottomNav).selectedItemId = R.id.nav_alert
        }
        findViewById<Button>(R.id.btnRefreshQuakes).setOnClickListener { refreshAll(true) }
        // 新地震语音播报用的普通话 TTS（提前初始化好，有新地震时直接读）
        newQuakeTts = MandarinTts(this).also { it.init {} }
        // 监测打开即自动启动（首次打开默认开）
        if (!prefs().contains("service_wanted")) {
            prefs().edit().putBoolean("service_wanted", true).apply()
        }
        if (prefs().getBoolean("service_wanted", true)) {
            ContextCompat.startForegroundService(this, Intent(this, WarningService::class.java))
        }
        requestPermissionsIfNeeded()
        refreshAll(true)
    }

    override fun onResume() {
        super.onResume()
        // 外观在提醒方式里改过，回来就重建
        if (LocalStore.appearance(this) != appliedAppearance) {
            recreate()
            return
        }
        loadUserLocation()
        refreshStatus()
        renderHomeFromCache()
        renderMy()
        when (currentTab) {
            "analysis" -> renderAnalysis()
            "alert" -> renderAlertPage()
            "map" -> renderMapMarkers()
        }
    }

    override fun onDestroy() {
        handler.removeCallbacks(tickerRunnable)
        for (a in epiPulseAnimators) a.cancel()
        epiPulseAnimators.clear()
        newQuakeTts?.shutdown()
        super.onDestroy()
    }

    // ---------------- 外观 ----------------

    private fun applyStaticTheme() {
        if (dark) return // XML 默认就是深色
        findViewById<View>(R.id.rootMain).setBackgroundResource(R.drawable.bg_light)
        findViewById<View>(R.id.heroCard).setBackgroundResource(cardBg())
        findViewById<View>(R.id.tickerCapsule).setBackgroundResource(cardBg())
        findViewById<View>(R.id.myCard).setBackgroundResource(cardBg())
        val t1 = listOf(
            R.id.tvGreeting, R.id.tvCityTop, R.id.tvHeroStatus,
            R.id.tvStatCount, R.id.tvStatMax7,
            R.id.tvFeaturedHeader, R.id.tvNearestHeader, R.id.tvListHeader,
            R.id.tvMyCity, R.id.tvWarnTitle, R.id.tvAlertStatus
        )
        for (id in t1) findViewById<TextView>(id).setTextColor(tc1())
        val t2 = listOf(
            R.id.tvDate, R.id.tvHeroCity, R.id.tvHeroWeather,
            R.id.tvTickerState, R.id.tvDataStatus, R.id.tvMyStatus,
            R.id.tvMyThresholds, R.id.tvMyDataStatus, R.id.tvMiniStatus,
            R.id.tvWarnSub, R.id.tvAlertThresholds, R.id.tvMapStatus,
            R.id.tvAnalysisNote
        )
        for (id in t2) findViewById<TextView>(id).setTextColor(tc2())
        findViewById<TextView>(R.id.tvTicker).setTextColor(tc1())
        // 浅色下快捷入口与搜索框也换浅色底
        findViewById<Button>(R.id.btnShortcutPreview).apply {
            setBackgroundResource(cardBg())
            setTextColor(tc1())
        }
        findViewById<Button>(R.id.btnShortcutShelter).apply {
            setBackgroundResource(cardBg())
            setTextColor(tc1())
        }
        findViewById<EditText>(R.id.etSearch).apply {
            setBackgroundResource(cardBg())
            setTextColor(tc1())
        }
        for (id in listOf(
            R.id.switchVoice, R.id.switchNewQuakeVoice,
            R.id.switchSound, R.id.switchVibrate
        )) {
            findViewById<Switch>(id).setTextColor(tc1())
        }
    }

    // ---------------- 顶栏 / 导航 ----------------

    private fun setupTopBar() {
        findViewById<TextView>(R.id.tvGreeting).text = "你好"
        findViewById<TextView>(R.id.tvDate).text = WeatherHelper.todayLabel()
        updateCityTop()
        findViewById<ImageButton>(R.id.btnSearch).setOnClickListener {
            val et = findViewById<EditText>(R.id.etSearch)
            if (et.visibility == View.GONE) {
                et.visibility = View.VISIBLE
                et.requestFocus()
            } else {
                et.visibility = View.GONE
                et.setText("")
            }
        }
    }

    private fun updateCityTop() {
        val city = prefs().getString("user_city", "") ?: ""
        findViewById<TextView>(R.id.tvCityTop).text = city.ifEmpty { "未设置城市" }
    }

    private fun setupBottomNav() {
        val nav = findViewById<BottomNavigationView>(R.id.bottomNav)
        nav.setOnItemSelectedListener { item ->
            when (item.itemId) {
                R.id.nav_home -> showTab("home")
                R.id.nav_map -> showTab("map")
                R.id.nav_analysis -> showTab("analysis")
                R.id.nav_alert -> showTab("alert")
                R.id.nav_my -> showTab("my")
            }
            true
        }
        nav.selectedItemId = R.id.nav_home
    }

    private fun showTab(tab: String) {
        currentTab = tab
        findViewById<ScrollView>(R.id.homeScroll).visibility =
            if (tab == "home") View.VISIBLE else View.GONE
        findViewById<ScrollView>(R.id.mapScroll).visibility =
            if (tab == "map") View.VISIBLE else View.GONE
        findViewById<ScrollView>(R.id.analysisScroll).visibility =
            if (tab == "analysis") View.VISIBLE else View.GONE
        findViewById<ScrollView>(R.id.alertScroll).visibility =
            if (tab == "alert") View.VISIBLE else View.GONE
        findViewById<ScrollView>(R.id.myScroll).visibility =
            if (tab == "my") View.VISIBLE else View.GONE
        val onHome = tab == "home"
        findViewById<View>(R.id.tickerCapsule).visibility =
            if (onHome) View.VISIBLE else View.GONE
        findViewById<ImageButton>(R.id.btnSearch).visibility =
            if (onHome) View.VISIBLE else View.GONE
        if (onHome) {
            if (!tickerPaused && tickerMax > 0) handler.post(tickerRunnable)
        } else {
            handler.removeCallbacks(tickerRunnable)
        }
        when (tab) {
            "map" -> {
                updateMapButtons()
                if (mapQuakes.isEmpty() ||
                    System.currentTimeMillis() - mapLoadedAt > 5 * 60_000L
                ) {
                    fetchMapData()
                } else {
                    renderMapMarkers()
                }
            }
            "analysis" -> renderAnalysis()
            "alert" -> renderAlertPage()
            "my" -> renderMy()
        }
    }

    private fun openMyPage(page: String) {
        startActivity(Intent(this, MyPageActivity::class.java).apply {
            putExtra("page", page)
        })
    }

    private fun setupShortcuts() {
        findViewById<Button>(R.id.btnShortcutPreview).setOnClickListener { openMyPage("preview") }
        findViewById<Button>(R.id.btnShortcutShelter).setOnClickListener { openMyPage("shelter") }
        findViewById<Button>(R.id.btnShortcutGuide).setOnClickListener { openMyPage("guide") }
    }

    private fun scrollToList() {
        val sv = findViewById<ScrollView>(R.id.homeScroll)
        val target = findViewById<LinearLayout>(R.id.llQuakes)
        sv.post {
            val loc = IntArray(2)
            target.getLocationOnScreen(loc)
            val sloc = IntArray(2)
            sv.getLocationOnScreen(sloc)
            sv.smoothScrollTo(0, sv.scrollY + (loc[1] - sloc[1]) - dp(16))
        }
    }

    // ---------------- 位置 / 权限 / 服务 ----------------

    private fun loadUserLocation() {
        userLat = prefs().getFloat("user_lat", 0f).toDouble()
        userLon = prefs().getFloat("user_lon", 0f).toDouble()
    }

    private fun requestPermissionsIfNeeded() {
        val needed = mutableListOf<String>()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
            != PackageManager.PERMISSION_GRANTED
        ) {
            needed.add(Manifest.permission.POST_NOTIFICATIONS)
        }
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
            != PackageManager.PERMISSION_GRANTED
        ) {
            needed.add(Manifest.permission.ACCESS_FINE_LOCATION)
        }
        if (needed.isNotEmpty()) {
            ActivityCompat.requestPermissions(this, needed.toTypedArray(), 101)
        }
    }

    // ---------------- 通用小组件 ----------------

    /** 震级着色毛玻璃背景：震级色低透明度填充 + 同色描边。 */
    private fun tintedGlass(color: Int): GradientDrawable {
        return GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = dp(22).toFloat()
            setColor(Color.argb(0x2E, Color.red(color), Color.green(color), Color.blue(color)))
            setStroke(dp(1), color)
        }
    }

    /** 小芯片背景（圆角描边 + 低透明度同色填充）。 */
    private fun chipBackground(color: Int): GradientDrawable {
        return GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = dp(11).toFloat()
            setColor(Color.argb(0x1F, Color.red(color), Color.green(color), Color.blue(color)))
            setStroke(dp(1), color)
        }
    }

    private fun makeChip(text: String, color: Int): TextView {
        return TextView(this).apply {
            this.text = text
            textSize = 11f
            setTextColor(color)
            setPadding(dp(8), dp(3), dp(8), dp(3))
            background = chipBackground(color)
        }
    }

    /** 统计行：左标题右数值（毛玻璃卡片）。 */
    private fun buildStatRow(key: String, value: String): View {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setBackgroundResource(cardBg())
            setPadding(dp(14), dp(12), dp(14), dp(12))
            val lp = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
            lp.bottomMargin = dp(8)
            layoutParams = lp
        }
        row.addView(TextView(this).apply {
            text = key
            textSize = 14f
            setTextColor(tc2())
            val lp = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            layoutParams = lp
        })
        row.addView(TextView(this).apply {
            text = value
            textSize = 15f
            setTypeface(null, android.graphics.Typeface.BOLD)
            setTextColor(tc1())
        })
        return row
    }

    /** 横向条形图的一行：标签 + 按比例宽度的色条 + 数值。 */
    private fun buildBarRow(label: String, value: Int, maxValue: Int, color: Int): View {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(4), 0, dp(4))
        }
        row.addView(TextView(this).apply {
            text = label
            textSize = 13f
            setTextColor(tc1())
            val lp = LinearLayout.LayoutParams(dp(64), LinearLayout.LayoutParams.WRAP_CONTENT)
            layoutParams = lp
        })
        val barWrap = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            val lp = LinearLayout.LayoutParams(0, dp(18), 1f)
            layoutParams = lp
        }
        val frac = if (maxValue > 0) value.toFloat() / maxValue else 0f
        if (frac > 0f) {
            barWrap.addView(View(this).apply {
                background = GradientDrawable().apply {
                    shape = GradientDrawable.RECTANGLE
                    cornerRadius = dp(4).toFloat()
                    setColor(color)
                }
                val lp = LinearLayout.LayoutParams(
                    0, LinearLayout.LayoutParams.MATCH_PARENT, frac
                )
                layoutParams = lp
            })
            if (frac < 1f) {
                barWrap.addView(View(this).apply {
                    val lp = LinearLayout.LayoutParams(
                        0, LinearLayout.LayoutParams.MATCH_PARENT, 1f - frac
                    )
                    layoutParams = lp
                })
            }
        }
        row.addView(barWrap)
        row.addView(TextView(this).apply {
            text = value.toString()
            textSize = 13f
            setTypeface(null, android.graphics.Typeface.BOLD)
            setTextColor(tc1())
            val lp = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
            lp.marginStart = dp(8)
            layoutParams = lp
        })
        return row
    }

    // ---------------- 状态 ----------------

    /** 推送状态只在这里显示（监测卡 + 底部迷你状态条 + 预警横幅），不另弹重复提示。 */
    private fun refreshStatus() {
        val status = prefs().getString("service_status", "stopped") ?: "stopped"
        val last = prefs().getLong("last_update", 0L)
        val heroDot = findViewById<TextView>(R.id.tvHeroDot)
        val heroStatus = findViewById<TextView>(R.id.tvHeroStatus)
        val btnRetry = findViewById<Button>(R.id.btnHeroRetry)
        val mini = findViewById<TextView>(R.id.tvMiniStatus)
        val timeText = if (last > 0) {
            val diffMin = (System.currentTimeMillis() - last) / 60000
            if (diffMin < 1) "刚刚更新" else "$diffMin 分钟前更新"
        } else {
            "尚未更新"
        }
        when (status) {
            "ws_connected" -> {
                heroDot.setTextColor(ContextCompat.getColor(this, R.color.neon_green))
                heroStatus.text = "守护中"
                btnRetry.visibility = View.GONE
                mini.text = "推送已连接 · $timeText"
            }
            "polling" -> {
                heroDot.setTextColor(ContextCompat.getColor(this, R.color.status_warn))
                heroStatus.text = "推送断开 · 轮询兜底中（30 秒一次）"
                btnRetry.visibility = View.VISIBLE
                mini.text = "推送断开 · 轮询兜底中 · $timeText"
            }
            "connecting" -> {
                heroDot.setTextColor(ContextCompat.getColor(this, R.color.status_warn))
                heroStatus.text = "正在连接台网推送通道…"
                btnRetry.visibility = View.GONE
                mini.text = "正在连接推送通道…"
            }
            else -> {
                heroDot.setTextColor(ContextCompat.getColor(this, R.color.status_warn))
                heroStatus.text = "服务未运行"
                btnRetry.visibility = View.VISIBLE
                mini.text = "服务未运行 · $timeText"
            }
        }
        findViewById<TextView>(R.id.tvWarnTitle).text =
            if (status == "stopped") "地震预警未开启" else "地震预警已开启"
        findViewById<TextView>(R.id.tvWarnSub).text = "附近暂无强震 · ${mini.text}"
        val city = prefs().getString("user_city", "") ?: ""
        findViewById<TextView>(R.id.tvHeroCity).text =
            if (city.isNotEmpty()) "监测城市：$city" else "未设置监测城市，请去“我的 > 预警设置”选城市"
        findViewById<TextView>(R.id.tvDataStatus).text =
            "数据来源：中国地震台网 · " +
                if (LocalStore.lastCatalogAt(this) > 0) {
                    "更新于 " + SimpleDateFormat("HH:mm:ss", Locale.CHINA).apply {
                        timeZone = beijing
                    }.format(Date(LocalStore.lastCatalogAt(this)))
                } else {
                    "尚未更新"
                }
    }

    // ---------------- 数据拉取 ----------------

    private fun refreshAll(showSkeleton: Boolean) {
        if (showSkeleton) {
            findViewById<LinearLayout>(R.id.llSkeleton).visibility = View.VISIBLE
        }
        val request = Request.Builder().url(WarningService.CATALOG_URL).build()
        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                runOnUiThread {
                    findViewById<LinearLayout>(R.id.llSkeleton).visibility = View.GONE
                    Toast.makeText(this@MainActivity, "获取失败：${e.message}", Toast.LENGTH_SHORT).show()
                    refreshStatus()
                }
            }

            override fun onResponse(call: Call, response: Response) {
                val body = response.body?.string() ?: return
                val list = EewParser.parseCatalog(body)
                LocalStore.saveRecentFull(this@MainActivity, list.take(20))
                runOnUiThread {
                    findViewById<LinearLayout>(R.id.llSkeleton).visibility = View.GONE
                    // 新地震语音播报：只对本次刷新后新出现的地震播报，
                    // 首次加载只记下已有 ID，不播报，避免一打开就连读几十条
                    val newOnes = if (firstCatalogLoad) {
                        emptyList()
                    } else {
                        list.filter { it.eventId !in seenQuakeIds }
                    }
                    seenQuakeIds.addAll(list.map { it.eventId })
                    firstCatalogLoad = false
                    quakes = LocalStore.recentFull(this@MainActivity)
                    renderHome()
                    refreshStatus()
                    announceNewQuakes(newOnes)
                }
            }
        })
        if (userLat != 0.0 || userLon != 0.0) {
            WeatherHelper.fetch(userLat, userLon) { f ->
                weather = f
                runOnUiThread {
                    renderTicker()
                    renderHeroWeather()
                }
            }
        }
    }

    /** 新地震语音播报：3.0 级以上、未达报警阈值的新地震，用普通话读一遍。 */
    private fun announceNewQuakes(newOnes: List<Quake>) {
        if (newOnes.isEmpty()) return
        if (!prefs().getBoolean("voice_on", true)) return
        if (!prefs().getBoolean("voice_new_quake_on", true)) return
        // 达到报警阈值的交给 WarningService 的预警弹窗播报，这里不重复读
        val eligible = newOnes.filter { q ->
            q.magnitude >= 3.0 && !wouldAlert(q)
        }
        if (eligible.isEmpty()) return
        val q = eligible.maxByOrNull { it.magnitude } ?: return
        val hasLoc = userLat != 0.0 || userLon != 0.0
        val text = buildString {
            append("${q.location}发生${q.magnitude}级地震")
            if (hasLoc) {
                val dist = QuakeMath.distanceKm(userLat, userLon, q.latitude, q.longitude)
                val local = QuakeMath.estimateIntensity(q.magnitude, dist)
                append("，距你约${dist.toInt()}公里，我所在地预计${local}度，${QuakeMath.feelingText(local)}")
            }
        }
        newQuakeTts?.speak(text)
    }

    /** 按 WarningService.evaluate 同样的阈值判断：这场地震会不会触发预警弹窗。 */
    private fun wouldAlert(q: Quake): Boolean {
        if (userLat == 0.0 && userLon == 0.0) return false
        val dist = QuakeMath.distanceKm(userLat, userLon, q.latitude, q.longitude)
        val sArrival = QuakeMath.sArrivalMillis(q.timeMillis, dist)
        val leadSec = (sArrival - System.currentTimeMillis()) / 1000
        if (leadSec < prefs().getInt("min_lead_sec", 5)) return false
        if (q.magnitude < prefs().getFloat("min_mag", 0f).toDouble()) return false
        val intensity = q.intensity ?: QuakeMath.estimateIntensity(q.magnitude, dist)
        if (intensity < prefs().getInt("min_intensity", 0)) return false
        return true
    }

    private fun renderHomeFromCache() {
        quakes = LocalStore.recentFull(this)
        renderHome()
        renderTicker()
        renderHeroWeather()
    }

    private fun renderHeroWeather() {
        val tv = findViewById<TextView>(R.id.tvHeroWeather)
        val f = weather
        tv.text = if (f == null) {
            ""
        } else {
            val temp = f.tempNow?.let { "${it.toInt()}℃ " } ?: ""
            "当地天气：${WeatherHelper.weatherCodeText(f.codeNow)} $temp" +
                "风速${f.windNow.toInt()}km/h"
        }
    }

    // ---------------- 播报条 ----------------

    private fun renderTicker() {
        val items = mutableListOf<Pair<String, Int>>()
        val timeFmt = SimpleDateFormat("HH:mm", Locale.CHINA).apply { timeZone = beijing }
        for (q in quakes.take(3)) {
            items.add(
                "${q.magnitude}级 ${q.location} · ${timeFmt.format(Date(q.timeMillis))}" to
                    magColor(q.magnitude)
            )
        }
        weather?.let { f ->
            for ((text, level) in WeatherHelper.tickerWeatherItems(f)) {
                val color = when (level) {
                    2 -> ContextCompat.getColor(this, R.color.mag_severe)
                    1 -> ContextCompat.getColor(this, R.color.mag_mid)
                    else -> 0xFF7FB3D5.toInt()
                }
                items.add(text to color)
            }
        }
        if (items.isEmpty()) {
            findViewById<TextView>(R.id.tvTicker).text = "正在获取最新地震与天气播报…"
            return
        }
        val sb = SpannableStringBuilder()
        for ((text, color) in items) {
            if (sb.isNotEmpty()) sb.append("      ")
            val start = sb.length
            sb.append("● ")
            sb.setSpan(
                ForegroundColorSpan(color), start, sb.length,
                SpannableStringBuilder.SPAN_EXCLUSIVE_EXCLUSIVE
            )
            sb.append(text)
        }
        val tv = findViewById<TextView>(R.id.tvTicker)
        tv.text = sb
        findViewById<TextView>(R.id.tvTickerDot)
            .setTextColor(items.first().second)
        startTickerScroll()
    }

    private fun startTickerScroll() {
        handler.removeCallbacks(tickerRunnable)
        if (LocalStore.reducedMotion(this)) {
            findViewById<TextView>(R.id.tvTickerState).text = "已暂停（已减少动态）"
            return
        }
        val sv = findViewById<HorizontalScrollView>(R.id.tickerScroll)
        val tv = findViewById<TextView>(R.id.tvTicker)
        sv.post {
            val total = tv.width - sv.width
            if (total > 0) {
                tickerMax = total
                tickerStep = total / (90f * 20f) // 约 90 秒一圈
                if (!tickerPaused) {
                    findViewById<TextView>(R.id.tvTickerState).text = "滚动中"
                    handler.post(tickerRunnable)
                }
            }
        }
    }

    private fun toggleTickerPause() {
        tickerPaused = !tickerPaused
        findViewById<TextView>(R.id.tvTickerState).text =
            if (tickerPaused) "已暂停" else "滚动中"
        if (!tickerPaused) handler.post(tickerRunnable)
        else handler.removeCallbacks(tickerRunnable)
    }

    // ---------------- 首页渲染 ----------------

    private fun renderHome() {
        renderSpotlight()
        renderHeroStats()
        renderFeatured()
        renderNearest()
        renderList()
        updateCityTop()
        if (currentTab == "analysis") renderAnalysis()
    }

    /** 聚光卡：最新一场中国地震 + 地图上的震中红点。 */
    private fun renderSpotlight() {
        val latest = quakes.maxByOrNull { it.timeMillis }
        val card = findViewById<LinearLayout>(R.id.spotCard)
        if (latest == null) {
            findViewById<TextView>(R.id.tvSpotMag).text = "-"
            findViewById<TextView>(R.id.tvSpotPlace).text = "暂无地震数据"
            findViewById<TextView>(R.id.tvSpotMeta).text = ""
            positionEpicenterDot(null)
            card.setOnClickListener(null)
            return
        }
        val mag = latest.magnitude
        val color = magColor(mag)
        findViewById<TextView>(R.id.tvSpotMag).apply {
            text = "$mag"
            setTextColor(color)
        }
        val level = when {
            mag < 3.0 -> "微震"
            mag < 4.5 -> "有感地震"
            mag < 6.0 -> "中强震"
            mag < 7.0 -> "强震"
            else -> "大地震"
        }
        findViewById<TextView>(R.id.tvSpotLevel).apply {
            text = level
            setTextColor(color)
            background = chipBackground(color)
        }
        card.background = tintedGlass(color)
        findViewById<TextView>(R.id.tvSpotPlace).text = latest.location
        val timeText = SimpleDateFormat("MM-dd HH:mm", Locale.CHINA).apply {
            timeZone = beijing
        }.format(Date(latest.timeMillis))
        val depthText = latest.depthKm?.let { " · 深度${it.toInt()}千米" } ?: ""
        val distText = if (userLat != 0.0 || userLon != 0.0) {
            " · 距你约${QuakeMath.distanceKm(userLat, userLon, latest.latitude, latest.longitude).toInt()}公里"
        } else ""
        findViewById<TextView>(R.id.tvSpotMeta).text = "$timeText$depthText$distText"
        card.setOnClickListener { showQuakeDetailDialog(latest, "cenc") }
        positionEpicenterDot(latest)
    }

    /**
     * 震中红点：按最新震中真实经纬度定位在夜景地图上
     * （底图覆盖经度 73–135、纬度 18–54；x%=(lon-73)/62，y%=(54-lat)/36）。
     * 震中在图外时不画假点，改显示“最新震中在本图范围外”。
     * 红点带 2 秒脉冲环（缩放 + 淡出，双环错开 1 秒）；减少动态时只留静态红点。
     */
    private fun positionEpicenterDot(q: Quake?) {
        val layer = findViewById<FrameLayout>(R.id.mapMarkerLayer)
        for (a in epiPulseAnimators) a.cancel()
        epiPulseAnimators.clear()
        layer.removeAllViews()
        findViewById<TextView>(R.id.tvMapNote).visibility = View.GONE
        if (q == null) return
        val xPct = (q.longitude - 73) / 62.0
        val yPct = (54 - q.latitude) / 36.0
        if (xPct < 0 || xPct > 1 || yPct < 0 || yPct > 1) {
            findViewById<TextView>(R.id.tvMapNote).visibility = View.VISIBLE
            return
        }
        layer.post {
            val w = layer.width
            val h = layer.height
            if (w == 0 || h == 0) return@post
            val cx = (w * xPct).toInt()
            val cy = (h * yPct).toInt()
            for (delay in listOf(0L, 1000L)) {
                val ring = View(this).apply {
                    setBackgroundResource(R.drawable.epi_ring)
                    val size = dp(60)
                    layoutParams = FrameLayout.LayoutParams(size, size).apply {
                        leftMargin = cx - size / 2
                        topMargin = cy - size / 2
                    }
                }
                layer.addView(ring)
                if (!LocalStore.reducedMotion(this)) {
                    val sx = ObjectAnimator.ofFloat(ring, "scaleX", 0.6f, 2.4f).apply {
                        duration = 2000
                        repeatCount = ObjectAnimator.INFINITE
                        startDelay = delay
                    }
                    val sy = ObjectAnimator.ofFloat(ring, "scaleY", 0.6f, 2.4f).apply {
                        duration = 2000
                        repeatCount = ObjectAnimator.INFINITE
                        startDelay = delay
                    }
                    val al = ObjectAnimator.ofFloat(ring, "alpha", 0.95f, 0f).apply {
                        duration = 2000
                        repeatCount = ObjectAnimator.INFINITE
                        startDelay = delay
                    }
                    sx.start()
                    sy.start()
                    al.start()
                    epiPulseAnimators.addAll(listOf(sx, sy, al))
                }
            }
            val dot = View(this).apply {
                setBackgroundResource(R.drawable.epi_dot)
                val size = dp(22)
                layoutParams = FrameLayout.LayoutParams(size, size).apply {
                    leftMargin = cx - size / 2
                    topMargin = cy - size / 2
                }
            }
            layer.addView(dot)
        }
    }

    private fun renderHeroStats() {
        val now = System.currentTimeMillis()
        val last24 = quakes.filter { it.timeMillis >= now - 24 * 3600_000L }
        val last7 = quakes.filter { it.timeMillis >= now - 7 * 24 * 3600_000L }
        findViewById<TextView>(R.id.tvStatCount).text = last24.size.toString()
        findViewById<TextView>(R.id.tvStatMax7).text =
            last7.maxByOrNull { it.magnitude }?.let { "${it.magnitude}级" } ?: "-"
    }

    private fun renderFeatured() {
        val ll = findViewById<LinearLayout>(R.id.llFeatured)
        ll.removeAllViews()
        if (quakes.isEmpty()) return
        val now = System.currentTimeMillis()
        val latest = quakes.maxByOrNull { it.timeMillis }
        val max24 = quakes.filter { it.timeMillis >= now - 24 * 3600_000L }
            .maxByOrNull { it.magnitude }
        val max7 = quakes.filter { it.timeMillis >= now - 7 * 24 * 3600_000L }
            .maxByOrNull { it.magnitude }
        val seen = mutableSetOf<String>()
        val cards = listOf(
            "最新一场" to latest,
            "24小时最大" to max24,
            "近7天最大" to max7
        )
        for ((label, q) in cards) {
            if (q == null || !seen.add(q.eventId)) continue
            ll.addView(buildFeaturedCard(label, q))
        }
    }

    private fun buildFeaturedCard(label: String, q: Quake): View {
        val color = magColor(q.magnitude)
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = tintedGlass(color)
            setPadding(dp(14), dp(14), dp(14), dp(14))
            val lp = LinearLayout.LayoutParams(dp(250), dp(150))
            lp.marginEnd = dp(12)
            layoutParams = lp
        }
        // 震级大数字 + 地震波纹环
        val ringBox = android.widget.RelativeLayout(this).apply {
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(64)
            )
        }
        val ring1 = android.widget.ImageView(this).apply {
            setImageResource(R.drawable.wave_ring)
            alpha = 0.6f
            val lp = android.widget.RelativeLayout.LayoutParams(dp(58), dp(58))
            lp.addRule(android.widget.RelativeLayout.CENTER_IN_PARENT)
            layoutParams = lp
        }
        val ring2 = android.widget.ImageView(this).apply {
            setImageResource(R.drawable.wave_ring)
            alpha = 0.9f
            val lp = android.widget.RelativeLayout.LayoutParams(dp(38), dp(38))
            lp.addRule(android.widget.RelativeLayout.CENTER_IN_PARENT)
            layoutParams = lp
        }
        val tvMag = TextView(this).apply {
            text = "${q.magnitude}"
            textSize = 30f
            setTypeface(null, android.graphics.Typeface.BOLD)
            setTextColor(color)
            gravity = Gravity.CENTER
            val lp = android.widget.RelativeLayout.LayoutParams(
                android.widget.RelativeLayout.LayoutParams.WRAP_CONTENT,
                android.widget.RelativeLayout.LayoutParams.WRAP_CONTENT
            )
            lp.addRule(android.widget.RelativeLayout.CENTER_IN_PARENT)
            layoutParams = lp
        }
        ringBox.addView(ring1)
        ringBox.addView(ring2)
        ringBox.addView(tvMag)
        card.addView(ringBox)
        card.addView(TextView(this).apply {
            text = label
            textSize = 12f
            setTextColor(tc2())
            gravity = Gravity.CENTER
        })
        card.addView(TextView(this).apply {
            text = q.location
            textSize = 15f
            setTypeface(null, android.graphics.Typeface.BOLD)
            setTextColor(tc1())
            gravity = Gravity.CENTER
            val lp = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
            lp.topMargin = dp(4)
            layoutParams = lp
        })
        card.addView(TextView(this).apply {
            text = SimpleDateFormat("MM-dd HH:mm", Locale.CHINA).apply {
                timeZone = beijing
            }.format(Date(q.timeMillis))
            textSize = 12f
            setTextColor(tc2())
            gravity = Gravity.CENTER
        })
        card.setOnClickListener { showQuakeDetailDialog(q, "cenc") }
        return card
    }

    /** 离我最近：震中烈度与我所在地预计烈度分开显示，绝不混用。 */
    private fun renderNearest() {
        val ll = findViewById<LinearLayout>(R.id.llNearest)
        ll.removeAllViews()
        if (userLat == 0.0 && userLon == 0.0) {
            ll.addView(TextView(this).apply {
                text = "设置监测城市后显示离你最近的地震"
                textSize = 13f
                setTextColor(tc2())
            })
            return
        }
        val nearest = quakes
            .map { q -> q to QuakeMath.distanceKm(userLat, userLon, q.latitude, q.longitude) }
            .sortedBy { it.second }
            .take(3)
        val timeFmt = SimpleDateFormat("MM-dd HH:mm", Locale.CHINA).apply { timeZone = beijing }
        val red = ContextCompat.getColor(this, R.color.mag_severe)
        for ((q, dist) in nearest) {
            val epiText = q.intensity?.let { "震中烈度 ${it}度" } ?: "震中烈度 未公布"
            val local = QuakeMath.estimateIntensity(q.magnitude, dist)
            val feeling = QuakeMath.feelingText(local)
            val arrival = QuakeMath.sArrivalMillis(q.timeMillis, dist)
            val sText = if (arrival <= System.currentTimeMillis()) "S波已到达"
            else "S波将于${(arrival - System.currentTimeMillis()) / 1000}秒后到达"
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setBackgroundResource(cardBg())
                setPadding(dp(12), dp(12), dp(12), dp(12))
                val lp = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                )
                lp.bottomMargin = dp(8)
                layoutParams = lp
            }
            row.addView(TextView(this).apply {
                text = "${q.magnitude}"
                textSize = 17f
                setTypeface(null, android.graphics.Typeface.BOLD)
                setTextColor(magColor(q.magnitude))
            })
            val middle = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                val lp = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                lp.marginStart = dp(10)
                layoutParams = lp
            }
            middle.addView(TextView(this).apply {
                text = "${q.location} · 约${dist.toInt()}公里"
                textSize = 14f
                setTextColor(tc1())
            })
            val chips = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                val lp = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                )
                lp.topMargin = dp(6)
                layoutParams = lp
            }
            val chipEpi = makeChip(epiText, red)
            chipEpi.layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { marginEnd = dp(8) }
            chips.addView(chipEpi)
            chips.addView(makeChip("我所在地 ${local}度 · $feeling", feelColor(local)))
            middle.addView(chips)
            row.addView(middle)
            val right = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.END
            }
            right.addView(TextView(this).apply {
                text = timeFmt.format(Date(q.timeMillis))
                textSize = 12f
                setTextColor(tc2())
            })
            right.addView(TextView(this).apply {
                text = sText
                textSize = 11f
                setTextColor(tc2())
                val lp = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                )
                lp.topMargin = dp(2)
                layoutParams = lp
            })
            row.addView(right)
            row.setOnClickListener { showQuakeDetailDialog(q, "cenc") }
            ll.addView(row)
        }
    }

    // ---------------- 列表：筛选 / 搜索 / 排序 / 分组 / 徽章 ----------------

    private fun setupListControls() {
        val spinnerFilter = findViewById<Spinner>(R.id.spinnerFilter)
        spinnerFilter.adapter = ArrayAdapter(
            this, android.R.layout.simple_spinner_item,
            listOf("全部", "4级以上", "5级以上")
        ).apply {
            setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        }
        spinnerFilter.onItemSelectedListener =
            object : android.widget.AdapterView.OnItemSelectedListener {
                override fun onItemSelected(
                    parent: android.widget.AdapterView<*>?, view: View?,
                    position: Int, id: Long
                ) {
                    magFilter = when (position) {
                        1 -> 4.0
                        2 -> 5.0
                        else -> 0.0
                    }
                    renderList()
                }

                override fun onNothingSelected(parent: android.widget.AdapterView<*>?) {}
            }
        val spinnerSort = findViewById<Spinner>(R.id.spinnerSort)
        spinnerSort.adapter = ArrayAdapter(
            this, android.R.layout.simple_spinner_item,
            listOf("按时间", "按距离")
        ).apply {
            setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        }
        spinnerSort.onItemSelectedListener =
            object : android.widget.AdapterView.OnItemSelectedListener {
                override fun onItemSelected(
                    parent: android.widget.AdapterView<*>?, view: View?,
                    position: Int, id: Long
                ) {
                    sortMode = position
                    renderList()
                }

                override fun onNothingSelected(parent: android.widget.AdapterView<*>?) {}
            }
        findViewById<EditText>(R.id.etSearch).addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) {
                searchQuery = s?.toString()?.trim() ?: ""
                renderList()
            }
        })
    }

    private fun filteredQuakes(): List<Quake> {
        var list = quakes.filter { it.magnitude >= magFilter }
        if (searchQuery.isNotEmpty()) {
            list = list.filter { it.location.contains(searchQuery) }
        }
        return when (sortMode) {
            1 -> {
                if (userLat == 0.0 && userLon == 0.0) {
                    list.sortedByDescending { it.timeMillis }
                } else {
                    list.sortedBy {
                        QuakeMath.distanceKm(userLat, userLon, it.latitude, it.longitude)
                    }
                }
            }
            else -> list.sortedByDescending { it.timeMillis }
        }
    }

    private fun dayGroup(timeMillis: Long): String {
        val fmt = SimpleDateFormat("yyyy-MM-dd", Locale.CHINA).apply { timeZone = beijing }
        val day = fmt.format(Date(timeMillis))
        val today = fmt.format(Date())
        val cal = Calendar.getInstance(beijing).apply { add(Calendar.DAY_OF_YEAR, -1) }
        val yesterday = fmt.format(cal.time)
        return when (day) {
            today -> "今天"
            yesterday -> "昨天"
            else -> "更早"
        }
    }

    private fun renderList() {
        val ll = findViewById<LinearLayout>(R.id.llQuakes)
        ll.removeAllViews()
        val list = filteredQuakes()
        if (list.isEmpty()) {
            ll.addView(TextView(this).apply {
                text = if (quakes.isEmpty()) "点“刷新”获取台网最新速报" else "没有符合条件的地震"
                textSize = 14f
                setTextColor(tc2())
                setPadding(dp(4), dp(8), dp(4), dp(8))
            })
            return
        }
        val now = System.currentTimeMillis()
        val max24 = list.filter { it.timeMillis >= now - 24 * 3600_000L }
            .maxByOrNull { it.magnitude }
        val max7 = list.filter { it.timeMillis >= now - 7 * 24 * 3600_000L }
            .maxByOrNull { it.magnitude }
        var lastGroup: String? = null
        for (q in list) {
            val group = dayGroup(q.timeMillis)
            if (group != lastGroup) {
                lastGroup = group
                ll.addView(TextView(this).apply {
                    text = group
                    textSize = 13f
                    setTypeface(null, android.graphics.Typeface.BOLD)
                    setTextColor(tc2())
                    val lp = LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        LinearLayout.LayoutParams.WRAP_CONTENT
                    )
                    lp.topMargin = dp(10)
                    lp.bottomMargin = dp(6)
                    layoutParams = lp
                })
            }
            val badges = mutableListOf<String>()
            if (max24 != null && q.eventId == max24.eventId) badges.add("24小时最大")
            if (max7 != null && q.eventId == max7.eventId) badges.add("最近最强")
            ll.addView(buildQuakeCard(q, badges))
        }
    }

    // ---------------- 地震卡片（基本信息 + 体感药丸，点开毛玻璃详情弹窗） ----------------

    private fun buildQuakeCard(q: Quake, badges: List<String>): View {
        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundResource(cardBg())
            setPadding(dp(12), dp(12), dp(12), dp(12))
            val lp = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
            lp.bottomMargin = dp(8)
            layoutParams = lp
        }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val magCircle = TextView(this).apply {
            text = "${q.magnitude}"
            textSize = 15f
            setTypeface(null, android.graphics.Typeface.BOLD)
            setTextColor(0xFFFFFFFF.toInt())
            gravity = Gravity.CENTER
            val bg = ContextCompat.getDrawable(
                this@MainActivity, R.drawable.mag_circle
            )?.mutate() as? GradientDrawable
            bg?.setColor(magColor(q.magnitude))
            background = bg
            val lp = LinearLayout.LayoutParams(dp(52), dp(52))
            layoutParams = lp
        }
        val middle = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            val lp = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            lp.marginStart = dp(10)
            layoutParams = lp
        }
        middle.addView(TextView(this).apply {
            text = q.location
            textSize = 16f
            setTypeface(null, android.graphics.Typeface.BOLD)
            setTextColor(tc1())
        })
        val hasLoc = userLat != 0.0 || userLon != 0.0
        val distText = if (hasLoc) {
            " · 距你约${QuakeMath.distanceKm(userLat, userLon, q.latitude, q.longitude).toInt()}公里"
        } else ""
        middle.addView(TextView(this).apply {
            text = SimpleDateFormat("MM-dd HH:mm", Locale.CHINA).apply {
                timeZone = beijing
            }.format(Date(q.timeMillis)) + distText
            textSize = 13f
            setTextColor(tc2())
        })
        if (badges.isNotEmpty()) {
            val badgeRow = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                val lp = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                )
                lp.topMargin = dp(4)
                layoutParams = lp
            }
            for (b in badges) {
                badgeRow.addView(TextView(this).apply {
                    text = b
                    textSize = 11f
                    setTextColor(ContextCompat.getColor(this@MainActivity, R.color.neon_green))
                    setBackgroundResource(R.drawable.badge_bg)
                    setPadding(dp(8), dp(3), dp(8), dp(3))
                    val blp = LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.WRAP_CONTENT,
                        LinearLayout.LayoutParams.WRAP_CONTENT
                    )
                    blp.marginEnd = dp(6)
                    layoutParams = blp
                })
            }
            middle.addView(badgeRow)
        }
        header.addView(magCircle)
        header.addView(middle)
        // 体感药丸：按用户所在地预计烈度算（无感/有感/强烈），未设置位置时不显示
        val local = QuakeMath.localIntensity(q, userLat, userLon)
        if (local != null) {
            val pill = makeChip(QuakeMath.feelingText(local), feelColor(local))
            pill.textSize = 12f
            pill.layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { marginEnd = dp(6) }
            header.addView(pill)
        }
        header.addView(TextView(this).apply {
            text = "›"
            textSize = 22f
            setTextColor(tc2())
        })
        container.addView(header)
        container.setOnClickListener { showQuakeDetailDialog(q, "cenc") }
        return container
    }

    // ---------------- 毛玻璃详情弹窗（速报 / 地图 / AI 分析 / 震感记录） ----------------

    /**
     * 点列表/海报卡/离我最近/聚光卡/地图标记后打开。
     * source: "cenc" 中国地震台网速报 / "usgs" / "emsc" 全球地震。
     * 弹窗内容可滚动，文字多时自动滚动查看，不撑破弹窗。
     */
    private fun showQuakeDetailDialog(q: Quake, source: String) {
        val dialog = Dialog(this)
        val scroll = ScrollView(this)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundResource(cardBg())
            setPadding(dp(18), dp(18), dp(18), dp(18))
        }
        scroll.addView(root)

        // 标题：震级圆 + 地点 + 时间
        val titleRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        titleRow.addView(TextView(this).apply {
            text = "${q.magnitude}"
            textSize = 18f
            setTypeface(null, android.graphics.Typeface.BOLD)
            setTextColor(0xFFFFFFFF.toInt())
            gravity = Gravity.CENTER
            val bg = ContextCompat.getDrawable(
                this@MainActivity, R.drawable.mag_circle
            )?.mutate() as? GradientDrawable
            bg?.setColor(magColor(q.magnitude))
            background = bg
            val lp = LinearLayout.LayoutParams(dp(56), dp(56))
            layoutParams = lp
        })
        val titleMid = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            val lp = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            lp.marginStart = dp(12)
            layoutParams = lp
        }
        titleMid.addView(TextView(this).apply {
            text = q.location
            textSize = 18f
            setTypeface(null, android.graphics.Typeface.BOLD)
            setTextColor(tc1())
        })
        titleMid.addView(TextView(this).apply {
            text = SimpleDateFormat("yyyy年MM月dd日 HH:mm", Locale.CHINA).apply {
                timeZone = beijing
            }.format(Date(q.timeMillis)) +
                (q.depthKm?.let { " · 深度${it.toInt()}千米" } ?: "")
            textSize = 13f
            setTextColor(tc2())
        })
        titleRow.addView(titleMid)
        root.addView(titleRow)

        // 双烈度芯片：震中烈度 / 我所在地预计烈度
        val chips = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            val lp = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
            lp.topMargin = dp(12)
            layoutParams = lp
        }
        val epiText = q.intensity?.let { "震中烈度 ${it}度" } ?: "震中烈度 未公布"
        val chipEpi = makeChip(epiText, ContextCompat.getColor(this, R.color.mag_severe))
        chipEpi.layoutParams = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.WRAP_CONTENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply { marginEnd = dp(8) }
        chips.addView(chipEpi)
        val local = QuakeMath.localIntensity(q, userLat, userLon)
        if (local != null) {
            val dist = QuakeMath.distanceKm(userLat, userLon, q.latitude, q.longitude)
            chips.addView(
                makeChip(
                    "我所在地 ${local}度 · ${QuakeMath.feelingText(local)}（约${dist.toInt()}公里）",
                    feelColor(local)
                )
            )
        }
        root.addView(chips)

        // 速报文案
        root.addView(TextView(this).apply {
            text = if (source == "cenc") flashReportText(q) else flashReportTextGlobal(q, source)
            textSize = 14f
            setTextColor(tc1())
            val lp = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
            lp.topMargin = dp(14)
            layoutParams = lp
        })

        // 地图
        root.addView(Button(this).apply {
            text = "在地图中查看震中"
            val lp = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
            lp.topMargin = dp(10)
            layoutParams = lp
            setOnClickListener {
                val url = "https://uri.amap.com/marker?position=${q.longitude},${q.latitude}" +
                    "&name=" + URLEncoder.encode(q.location, "UTF-8") +
                    "&coordinate=gaode"
                startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
            }
        })

        // AI 分析区
        root.addView(TextView(this).apply {
            text = "AI 分析"
            textSize = 15f
            setTypeface(null, android.graphics.Typeface.BOLD)
            setTextColor(tc1())
            val lp = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
            lp.topMargin = dp(14)
            layoutParams = lp
        })
        val tvAiLocal = TextView(this).apply {
            text = ""
            textSize = 13f
            setTextColor(tc2())
            root.addView(this)
        }
        val tvAiHistory = TextView(this).apply {
            text = "正在查询历史地震…"
            textSize = 13f
            setTextColor(tc2())
            val lp = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
            lp.topMargin = dp(8)
            layoutParams = lp
            root.addView(this)
        }
        val tvAiCasualty = TextView(this).apply {
            text = "正在查询伤亡数据…"
            textSize = 13f
            setTextColor(tc2())
            val lp = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
            lp.topMargin = dp(8)
            layoutParams = lp
            root.addView(this)
        }

        // 震感记录（仅中国速报）
        if (source == "cenc") {
            val feltRow = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                val lp = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                )
                lp.topMargin = dp(14)
                layoutParams = lp
            }
            feltRow.addView(TextView(this).apply {
                text = "你感受到震动了吗？"
                textSize = 13f
                setTextColor(tc1())
                val lp = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                layoutParams = lp
            })
            val tvFeltStatus = TextView(this).apply {
                textSize = 12f
                setTextColor(tc2())
                feltRow.addView(this)
            }
            val updateFelt = {
                val level = LocalStore.feltLevel(this, q.eventId)
                tvFeltStatus.text = when (level) {
                    0 -> "已记录：无感"
                    1 -> "已记录：轻微震感"
                    2 -> "已记录：强烈震感"
                    else -> ""
                }
            }
            updateFelt()
            for ((label, level) in listOf("无感" to 0, "轻微" to 1, "强烈" to 2)) {
                feltRow.addView(Button(this).apply {
                    text = label
                    setOnClickListener {
                        LocalStore.saveFelt(this@MainActivity, q.eventId, level, q.location, q.magnitude)
                        updateFelt()
                        Toast.makeText(this@MainActivity, "震感已记录", Toast.LENGTH_SHORT).show()
                    }
                })
            }
            root.addView(feltRow)
        }

        root.addView(Button(this).apply {
            text = "关闭"
            val lp = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
            lp.topMargin = dp(16)
            layoutParams = lp
            setOnClickListener { dialog.dismiss() }
        })

        dialog.setContentView(scroll)
        dialog.window?.setBackgroundDrawableResource(android.R.color.transparent)
        val dm = resources.displayMetrics
        dialog.window?.setLayout(dm.widthPixels - dp(48), (dm.heightPixels * 0.8).toInt())
        dialog.show()
        loadAi(q, tvAiLocal, tvAiHistory, tvAiCasualty)
    }

    /** 台网速报标准格式文案（由目录真实字段拼成，行内展示，不跳微博）。 */
    private fun flashReportText(q: Quake): String {
        val timeText = SimpleDateFormat("MM月dd日HH时mm分", Locale.CHINA).apply {
            timeZone = beijing
        }.format(Date(q.timeMillis))
        val depthText = q.depthKm?.let { "，震源深度${it.toInt()}千米" } ?: ""
        return "中国地震台网正式测定：$timeText，${q.location}发生${q.magnitude}级地震$depthText。" +
            "（@中国地震台网速报）"
    }

    /** 全球地震速报文案（USGS / EMSC 真实字段拼成）。 */
    private fun flashReportTextGlobal(q: Quake, source: String): String {
        val timeText = SimpleDateFormat("MM月dd日HH时mm分", Locale.CHINA).apply {
            timeZone = beijing
        }.format(Date(q.timeMillis))
        val depthText = q.depthKm?.let { "，震源深度${it.toInt()}千米" } ?: ""
        val org = if (source == "emsc") "欧洲地中海地震中心（EMSC）" else "美国地质调查局（USGS）"
        return "$org 测定：$timeText，${q.location}发生${q.magnitude}级地震$depthText。"
    }

    private fun loadAi(
        q: Quake,
        tvLocal: TextView,
        tvHistory: TextView,
        tvCasualty: TextView
    ) {
        tvLocal.text = AiAnalysis.buildLocalAnalysis(q, userLat, userLon)
        AiAnalysis.load(this, q, userLat, userLon) { result ->
            runOnUiThread {
                // 在线模型返回后，分析文字会从本地规则版换成在线版
                tvLocal.text = result.localAnalysis
                tvHistory.text = when (result.historyState) {
                    AiAnalysis.STATE_OK -> result.historyText
                    AiAnalysis.STATE_NONE -> "历史最大地震：该区域公开目录内暂无记录"
                    AiAnalysis.STATE_FAILED -> result.historyText ?: "历史地震查询失败"
                    else -> "正在查询历史地震…"
                }
                tvCasualty.text = when (result.casualtyState) {
                    AiAnalysis.STATE_OK -> result.casualtyText
                    AiAnalysis.STATE_NONE -> "当时伤亡情况：暂无公开伤亡数据"
                    AiAnalysis.STATE_FAILED -> result.casualtyText ?: "伤亡数据查询失败"
                    else -> "正在查询伤亡数据…"
                }
            }
        }
    }

    // ---------------- 地震地图（全球，仅供查看，绝不触发预警） ----------------

    private fun setupMapPage() {
        findViewById<Button>(R.id.btnMapUsgs).setOnClickListener {
            if (mapSource != "usgs") {
                mapSource = "usgs"
                updateMapButtons()
                fetchMapData()
            }
        }
        findViewById<Button>(R.id.btnMapEmsc).setOnClickListener {
            if (mapSource != "emsc") {
                mapSource = "emsc"
                updateMapButtons()
                fetchMapData()
            }
        }
        findViewById<Button>(R.id.btnMapDay).setOnClickListener {
            if (mapRange != "day") {
                mapRange = "day"
                updateMapButtons()
                fetchMapData()
            }
        }
        findViewById<Button>(R.id.btnMapWeek).setOnClickListener {
            if (mapRange != "week") {
                mapRange = "week"
                updateMapButtons()
                fetchMapData()
            }
        }
        findViewById<Button>(R.id.btnMapDetailAi).setOnClickListener {
            selectedMapQuake?.let { showQuakeDetailDialog(it, selectedMapQuakeSource) }
        }
    }

    private fun updateMapButtons() {
        findViewById<Button>(R.id.btnMapUsgs).apply {
            setBackgroundResource(if (mapSource == "usgs") R.drawable.btn_green else cardBg())
            setTextColor(if (mapSource == "usgs") 0xFF0B0F0B.toInt() else tc1())
        }
        findViewById<Button>(R.id.btnMapEmsc).apply {
            setBackgroundResource(if (mapSource == "emsc") R.drawable.btn_green else cardBg())
            setTextColor(if (mapSource == "emsc") 0xFF0B0F0B.toInt() else tc1())
        }
        findViewById<Button>(R.id.btnMapDay).apply {
            setBackgroundResource(if (mapRange == "day") R.drawable.btn_green else cardBg())
            setTextColor(if (mapRange == "day") 0xFF0B0F0B.toInt() else tc1())
        }
        findViewById<Button>(R.id.btnMapWeek).apply {
            setBackgroundResource(if (mapRange == "week") R.drawable.btn_green else cardBg())
            setTextColor(if (mapRange == "week") 0xFF0B0F0B.toInt() else tc1())
        }
    }

    private fun fetchMapData() {
        val url = when (mapSource) {
            "emsc" -> "https://www.seismicportal.eu/fdsnws/event/1/query" +
                "?format=json&limit=100&minmag=4.0"
            else -> if (mapRange == "week") {
                "https://earthquake.usgs.gov/earthquakes/feed/v1.0/summary/4.5_week.geojson"
            } else {
                "https://earthquake.usgs.gov/earthquakes/feed/v1.0/summary/2.5_day.geojson"
            }
        }
        findViewById<TextView>(R.id.tvMapStatus).text = "正在加载全球地震…"
        client.newCall(Request.Builder().url(url).build()).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                runOnUiThread {
                    findViewById<TextView>(R.id.tvMapStatus).text =
                        "全球地震加载失败（${e.message}），请检查网络后重试"
                    Toast.makeText(this@MainActivity, "全球地震加载失败", Toast.LENGTH_SHORT).show()
                }
            }

            override fun onResponse(call: Call, response: Response) {
                val body = response.body?.string() ?: ""
                val list = if (mapSource == "emsc") parseEmscJson(body) else parseUsgsGeoJson(body)
                runOnUiThread {
                    mapQuakes = list.sortedByDescending { it.timeMillis }
                    mapLoadedAt = System.currentTimeMillis()
                    val srcName = if (mapSource == "emsc") "EMSC 欧洲地中海地震中心" else "USGS 美国地质调查局"
                    findViewById<TextView>(R.id.tvMapStatus).text =
                        "数据来源：$srcName · 共 ${mapQuakes.size} 场 · " +
                            SimpleDateFormat("HH:mm:ss", Locale.CHINA).apply {
                                timeZone = beijing
                            }.format(Date(mapLoadedAt))
                    findViewById<LinearLayout>(R.id.llMapDetail).visibility = View.GONE
                    selectedMapQuake = null
                    renderMapMarkers()
                }
            }
        })
    }

    /** USGS GeoJSON：features[].properties.mag/place/time，geometry.coordinates=[lon, lat, depth]。 */
    private fun parseUsgsGeoJson(body: String): List<Quake> {
        val out = mutableListOf<Quake>()
        try {
            val features = JSONObject(body).optJSONArray("features") ?: return out
            for (i in 0 until features.length()) {
                val f = features.optJSONObject(i) ?: continue
                val props = f.optJSONObject("properties") ?: continue
                val coords = f.optJSONObject("geometry")?.optJSONArray("coordinates") ?: continue
                val mag = props.optDouble("mag", Double.NaN)
                if (mag.isNaN()) continue
                val depth = coords.optDouble(2, Double.NaN).takeIf { !it.isNaN() }
                val id = "usgs-" + f.optString("id", "${props.optLong("time", 0)}")
                out.add(
                    Quake(
                        id, props.optLong("time", 0L),
                        props.optString("place", "未知地点"),
                        mag, depth,
                        coords.optDouble(1, 0.0), coords.optDouble(0, 0.0), null
                    )
                )
            }
        } catch (_: Exception) {
        }
        return out
    }

    /** EMSC FDSNWS JSON：features[].properties.mag/time/lat/lon/depth/flynn_region。 */
    private fun parseEmscJson(body: String): List<Quake> {
        val out = mutableListOf<Quake>()
        try {
            val features = JSONObject(body).optJSONArray("features") ?: return out
            val timeFmt = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss", Locale.US).apply {
                timeZone = TimeZone.getTimeZone("UTC")
            }
            for (i in 0 until features.length()) {
                val f = features.optJSONObject(i) ?: continue
                val props = f.optJSONObject("properties") ?: continue
                val mag = props.optDouble("mag", Double.NaN)
                if (mag.isNaN()) continue
                val timeStr = props.optString("time", "").substringBefore('.')
                val time = try {
                    timeFmt.parse(timeStr)?.time ?: 0L
                } catch (_: Exception) {
                    0L
                }
                val lat = props.optDouble("lat", Double.NaN)
                val lon = props.optDouble("lon", Double.NaN)
                if (lat.isNaN() || lon.isNaN()) continue
                val depth = props.optDouble("depth", Double.NaN).takeIf { !it.isNaN() }
                val place = props.optString("flynn_region", "")
                    .ifEmpty { props.optString("place", "未知地点") }
                out.add(Quake("emsc-$time-$lat-$lon", time, place, mag, depth, lat, lon, null))
            }
        } catch (_: Exception) {
        }
        return out
    }

    /** 世界地图按真实经纬度打点（等距圆柱投影：x%=(lon+180)/360，y%=(90-lat)/180）。 */
    private fun renderMapMarkers() {
        val layer = findViewById<FrameLayout>(R.id.worldMarkerLayer)
        layer.post {
            layer.removeAllViews()
            val w = layer.width
            val h = layer.height
            if (w == 0 || h == 0) return@post
            val shown = mapQuakes.sortedByDescending { it.magnitude }.take(80)
            for (q in shown) {
                val xPct = (q.longitude + 180) / 360.0
                val yPct = (90 - q.latitude) / 180.0
                if (xPct < 0 || xPct > 1 || yPct < 0 || yPct > 1) continue
                val size = (dp(10) + (q.magnitude * 1.2).toInt()).coerceAtMost(dp(22))
                val dot = View(this).apply {
                    background = GradientDrawable().apply {
                        shape = GradientDrawable.OVAL
                        setColor(magColor(q.magnitude))
                        setStroke(dp(1), 0xFFFFFFFF.toInt())
                    }
                    layoutParams = FrameLayout.LayoutParams(size, size).apply {
                        leftMargin = (w * xPct).toInt() - size / 2
                        topMargin = (h * yPct).toInt() - size / 2
                    }
                    setOnClickListener { selectMapQuake(q) }
                }
                layer.addView(dot)
            }
        }
    }

    private fun selectMapQuake(q: Quake) {
        selectedMapQuake = q
        selectedMapQuakeSource = mapSource
        findViewById<LinearLayout>(R.id.llMapDetail).visibility = View.VISIBLE
        findViewById<TextView>(R.id.tvMapDetailTitle).text = "${q.magnitude}级 · ${q.location}"
        val timeText = SimpleDateFormat("MM-dd HH:mm", Locale.CHINA).apply {
            timeZone = beijing
        }.format(Date(q.timeMillis))
        val depthText = q.depthKm?.let { " · 深度${it.toInt()}千米" } ?: ""
        val distText = if (userLat != 0.0 || userLon != 0.0) {
            " · 距你约${QuakeMath.distanceKm(userLat, userLon, q.latitude, q.longitude).toInt()}公里"
        } else ""
        findViewById<TextView>(R.id.tvMapDetailMeta).text = "$timeText$depthText$distText"
    }

    // ---------------- 数据分析（近 7 天 CENC 目录统计 + AI 总分析） ----------------

    private fun setupAnalysisPage() {
        findViewById<Button>(R.id.btnAnalysisAiRefresh).setOnClickListener {
            // 强制重新分析：清除当天缓存后重算
            analysisAiDay = ""
            renderAnalysis()
        }
    }

    /** 地区归一：取地名中第一个“市/县/州”之前（含）部分，如“四川宜宾市”。 */
    private fun regionKey(location: String): String {
        val idx = listOf(location.indexOf("市"), location.indexOf("县"), location.indexOf("州"))
            .filter { it > 0 }.minOrNull()
        return if (idx != null) location.substring(0, idx + 1) else location.take(8)
    }

    private fun renderAnalysis() {
        val now = System.currentTimeMillis()
        val last7 = quakes.filter { it.timeMillis >= now - 7 * 24 * 3600_000L }

        val stats = findViewById<LinearLayout>(R.id.llAnalysisStats)
        stats.removeAllViews()
        val max7 = last7.maxByOrNull { it.magnitude }
        val regions = last7.groupBy { regionKey(it.location) }
            .mapValues { it.value.size }
            .entries.sortedByDescending { it.value }
        val topRegion = regions.firstOrNull()
        stats.addView(buildStatRow("近7天地震数", "${last7.size} 场"))
        stats.addView(
            buildStatRow(
                "近7天最大震级",
                max7?.let { "${it.magnitude}级 · ${it.location}" } ?: "-"
            )
        )
        stats.addView(
            buildStatRow(
                "最活跃地区",
                topRegion?.let { "${it.key} · ${it.value} 场" } ?: "-"
            )
        )

        // 每日地震数
        val daily = findViewById<LinearLayout>(R.id.llDailyBars)
        daily.removeAllViews()
        val dayFmt = SimpleDateFormat("MM-dd", Locale.CHINA).apply { timeZone = beijing }
        val counts = (6 downTo 0).map { d ->
            val cal = Calendar.getInstance(beijing).apply {
                add(Calendar.DAY_OF_YEAR, -d)
                set(Calendar.HOUR_OF_DAY, 0)
                set(Calendar.MINUTE, 0)
                set(Calendar.SECOND, 0)
                set(Calendar.MILLISECOND, 0)
            }
            val start = cal.timeInMillis
            val end = start + 24 * 3600_000L
            val label = dayFmt.format(Date(start))
            val c = last7.count { it.timeMillis in start until end }
            label to c
        }
        val maxDaily = counts.maxOfOrNull { it.second } ?: 0
        for ((label, c) in counts) {
            daily.addView(
                buildBarRow(label, c, maxDaily, ContextCompat.getColor(this, R.color.neon_green))
            )
        }

        // 震级分布
        val mag = findViewById<LinearLayout>(R.id.llMagBars)
        mag.removeAllViews()
        val magCounts = listOf(
            "<3级" to last7.count { it.magnitude < 3.0 },
            "3–4级" to last7.count { it.magnitude >= 3.0 && it.magnitude < 4.0 },
            "4–5级" to last7.count { it.magnitude >= 4.0 && it.magnitude < 5.0 },
            "5–6级" to last7.count { it.magnitude >= 5.0 && it.magnitude < 6.0 },
            "6级以上" to last7.count { it.magnitude >= 6.0 }
        )
        val maxMag = magCounts.maxOfOrNull { it.second } ?: 0
        for ((label, c) in magCounts) {
            mag.addView(
                buildBarRow(label, c, maxMag, ContextCompat.getColor(this, R.color.mag_mid))
            )
        }

        // 最活跃地区
        val reg = findViewById<LinearLayout>(R.id.llRegionBars)
        reg.removeAllViews()
        val topRegions = regions.take(5)
        val maxReg = topRegions.maxOfOrNull { it.value } ?: 0
        if (topRegions.isEmpty()) {
            reg.addView(TextView(this).apply {
                text = "暂无数据"
                textSize = 13f
                setTextColor(tc2())
            })
        }
        for ((name, c) in topRegions) {
            reg.addView(
                buildBarRow(name, c, maxReg, ContextCompat.getColor(this, R.color.mag_low))
            )
        }

        renderAnalysisAi(last7, counts, magCounts, topRegions)
    }

    /** 7 天 AI 总分析：本地规则汇总先行，在线模型成功后替换并按天缓存。 */
    private fun renderAnalysisAi(
        last7: List<Quake>,
        counts: List<Pair<String, Int>>,
        magCounts: List<Pair<String, Int>>,
        topRegions: List<Map.Entry<String, Int>>
    ) {
        val tv = findViewById<TextView>(R.id.tvAnalysisAi)
        val now = System.currentTimeMillis()
        val max7 = last7.maxByOrNull { it.magnitude }
        val dayKey = SimpleDateFormat("yyyy-MM-dd", Locale.CHINA).apply {
            timeZone = beijing
        }.format(Date(now))
        val statsText = buildString {
            append("近7天中国地震共 ${last7.size} 场；")
            if (max7 != null) {
                append(
                    "最大 ${max7.magnitude}级（${max7.location}，" +
                        SimpleDateFormat("MM月dd日", Locale.CHINA).apply {
                            timeZone = beijing
                        }.format(Date(max7.timeMillis)) + "）；"
                )
            }
            append("每日数量：${counts.joinToString("、") { "${it.first}${it.second}场" }}；")
            append("震级分布：${magCounts.joinToString("、") { "${it.first}${it.second}场" }}；")
            if (topRegions.isNotEmpty()) {
                append("最活跃地区：${topRegions.joinToString("、") { "${it.key}${it.value}场" }}。")
            }
        }
        val localText = "智能分析（本地规则汇总）\n$statsText\n" +
            if (last7.isEmpty()) {
                "近7天目录内暂无地震记录。"
            } else if ((max7?.magnitude ?: 0.0) >= 6.0) {
                "近7天出现 6 级以上强震，请关注官方后续速报，做好防范。"
            } else {
                "近7天以中小地震为主，未出现 6 级以上强震，整体活动平稳。"
            } +
            "\n（以上为按本次统计的本地规则汇总，仅供参考，不构成预报。）"
        // 当天缓存的在线分析优先
        val cacheKey = "agg-7d-$dayKey"
        val cached = LocalStore.aiCache(this, cacheKey)
        if (!cached.isNullOrEmpty()) {
            try {
                val online = JSONObject(cached).optString("onlineText")
                if (online.isNotEmpty()) {
                    tv.text = "智能分析（在线模型生成）\n$online"
                    return
                }
            } catch (_: Exception) {
            }
        }
        tv.text = localText
        if (analysisAiLoading || analysisAiDay == dayKey) return
        analysisAiLoading = true
        analysisAiDay = dayKey
        OnlineAi.analyzeAggregate(statsText) { text ->
            analysisAiLoading = false
            if (text == null) return@analyzeAggregate
            try {
                LocalStore.saveAiCache(
                    this, cacheKey,
                    JSONObject().apply { put("onlineText", text) }.toString()
                )
            } catch (_: Exception) {
            }
            runOnUiThread { tv.text = "智能分析（在线模型生成）\n$text" }
        }
    }

    // ---------------- 预警页 ----------------

    private fun setupAlertPage() {
        findViewById<Switch>(R.id.switchVoice).setOnCheckedChangeListener { _, on ->
            prefs().edit().putBoolean("voice_on", on).apply()
        }
        findViewById<Switch>(R.id.switchNewQuakeVoice).setOnCheckedChangeListener { _, on ->
            prefs().edit().putBoolean("voice_new_quake_on", on).apply()
        }
        findViewById<Switch>(R.id.switchSound).setOnCheckedChangeListener { _, on ->
            LocalStore.setSoundOn(this, on)
        }
        findViewById<Switch>(R.id.switchVibrate).setOnCheckedChangeListener { _, on ->
            LocalStore.setVibrateOn(this, on)
        }
        findViewById<Button>(R.id.btnAlertSettings).setOnClickListener { openMyPage("settings") }
        findViewById<Button>(R.id.btnTestAlert).setOnClickListener {
            startActivity(Intent(this, AlertActivity::class.java).apply {
                putExtra("test", true)
                putExtra("voice", prefs().getBoolean("voice_on", true))
            })
        }
        findViewById<Button>(R.id.btnClearHistory).setOnClickListener {
            LocalStore.clearAlertHistory(this)
            renderAlertPage()
            Toast.makeText(this, "已清空", Toast.LENGTH_SHORT).show()
        }
    }

    private fun renderAlertPage() {
        val status = prefs().getString("service_status", "stopped") ?: "stopped"
        findViewById<TextView>(R.id.tvAlertStatus).text = when (status) {
            "ws_connected" -> "守护中 · 推送已连接"
            "polling" -> "推送断开 · 轮询兜底中"
            "connecting" -> "正在连接…"
            else -> "服务未运行"
        }
        val magLabel = prefs().getString("mag_label", "不限") ?: "不限"
        val intLabel = prefs().getString("intensity_label", "不限") ?: "不限"
        val leadLabel = prefs().getString("lead_label", "5秒") ?: "5秒"
        findViewById<TextView>(R.id.tvAlertThresholds).text =
            "报警阈值：震级≥$magLabel · 烈度≥$intLabel · 提前$leadLabel"
        findViewById<Switch>(R.id.switchVoice).isChecked = prefs().getBoolean("voice_on", true)
        findViewById<Switch>(R.id.switchNewQuakeVoice).isChecked =
            prefs().getBoolean("voice_new_quake_on", true)
        findViewById<Switch>(R.id.switchSound).isChecked = LocalStore.soundOn(this)
        findViewById<Switch>(R.id.switchVibrate).isChecked = LocalStore.vibrateOn(this)

        val ll = findViewById<LinearLayout>(R.id.llAlertHistory)
        ll.removeAllViews()
        val arr = LocalStore.alertHistory(this)
        if (arr.length() == 0) {
            ll.addView(TextView(this).apply {
                text = "暂无预警记录"
                textSize = 14f
                setTextColor(tc2())
            })
            return
        }
        val fmt = SimpleDateFormat("MM-dd HH:mm", Locale.CHINA)
        for (i in arr.length() - 1 downTo 0) {
            val o = arr.optJSONObject(i) ?: continue
            val type = if (o.optString("type") == "test") "测试预览" else "真实预警"
            ll.addView(
                buildStatRow(
                    "$type · ${o.optString("location")} ${o.optDouble("magnitude")}级",
                    fmt.format(Date(o.optLong("time"))) + " · 提前 ${o.optInt("leadSec")} 秒报警"
                )
            )
        }
    }

    // ---------------- 我的 ----------------

    private fun renderMy() {
        val city = prefs().getString("user_city", "") ?: ""
        findViewById<TextView>(R.id.tvMyCity).text =
            if (city.isNotEmpty()) city else "未设置监测城市"
        val status = prefs().getString("service_status", "stopped") ?: "stopped"
        findViewById<TextView>(R.id.tvMyStatus).text = when (status) {
            "ws_connected" -> "守护中 · 推送已连接"
            "polling" -> "推送断开 · 轮询兜底中"
            "connecting" -> "正在连接…"
            else -> "服务未运行"
        }
        val magLabel = prefs().getString("mag_label", "不限") ?: "不限"
        val intLabel = prefs().getString("intensity_label", "不限") ?: "不限"
        val leadLabel = prefs().getString("lead_label", "5秒") ?: "5秒"
        findViewById<TextView>(R.id.tvMyThresholds).text =
            "震级≥$magLabel · 烈度≥$intLabel · 提前$leadLabel"
        val statusText = prefs().getString("service_status", "stopped") ?: "stopped"
        val last = prefs().getLong("last_update", 0L)
        findViewById<TextView>(R.id.tvMyDataStatus).text =
            "推送：$statusText · " +
                if (last > 0) {
                    "上次刷新 " + SimpleDateFormat("HH:mm:ss", Locale.CHINA).apply {
                        timeZone = beijing
                    }.format(Date(last))
                } else {
                    "尚未刷新"
                } + " · 数据来源：中国地震台网（Wolfx 接口）· 天气：Open-Meteo"

        val voiceText = if (prefs().getBoolean("voice_on", true)) "开" else "关"
        val appearanceText = if (LocalStore.isDark(this)) "深色" else "浅色"
        val rows = listOf(
            Triple("预警设置", "震级≥$magLabel · 烈度≥$intLabel · 提前$leadLabel", "settings"),
            Triple("提醒方式", "$appearanceText · 语音播报$voiceText", "remind"),
            Triple("播报预览", "", "preview"),
            Triple("预警记录", "${LocalStore.alertHistory(this).length()} 条", "history"),
            Triple("震感记录", "${LocalStore.feltReports(this).length()} 条", "felt"),
            Triple("避难场所", "", "shelter"),
            Triple("家庭联系人", "${LocalStore.contacts(this).length()} 人", "contacts"),
            Triple(
                "家庭安全自查",
                "已完成 ${LocalStore.safetyProgress(this)}/${LocalStore.SAFETY_ITEMS.size} 项",
                "safety"
            ),
            Triple("帮助与支持", "", "help"),
            Triple("应急指南", "", "guide"),
            Triple("关于", "版本 1.3", "about")
        )
        val ll = findViewById<LinearLayout>(R.id.llMyRows)
        ll.removeAllViews()
        for ((title, value, page) in rows) {
            ll.addView(buildMyRow(title, value, page))
        }
    }

    private fun buildMyRow(title: String, value: String, page: String): View {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setBackgroundResource(cardBg())
            setPadding(dp(16), dp(14), dp(16), dp(14))
            val lp = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
            lp.bottomMargin = dp(8)
            layoutParams = lp
        }
        row.addView(TextView(this).apply {
            text = title
            textSize = 16f
            setTextColor(tc1())
            val lp = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            layoutParams = lp
        })
        if (value.isNotEmpty()) {
            row.addView(TextView(this).apply {
                text = value
                textSize = 13f
                setTextColor(tc2())
                val lp = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                )
                lp.marginEnd = dp(8)
                layoutParams = lp
            })
        }
        row.addView(TextView(this).apply {
            text = "›"
            textSize = 18f
            setTypeface(null, android.graphics.Typeface.BOLD)
            setTextColor(0xFF0B0F0B.toInt())
            gravity = Gravity.CENTER
            background = ContextCompat.getDrawable(this@MainActivity, R.drawable.arrow_circle)
            val lp = LinearLayout.LayoutParams(dp(28), dp(28))
            layoutParams = lp
        })
        row.setOnClickListener { openMyPage(page) }
        return row
    }
}
