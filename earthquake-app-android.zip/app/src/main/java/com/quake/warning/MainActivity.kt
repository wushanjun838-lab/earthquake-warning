package com.quake.warning

import android.Manifest
import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.AnimatorSet
import android.animation.ObjectAnimator
import android.animation.ValueAnimator
import android.view.animation.DecelerateInterpolator
import android.app.Dialog
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.Editable
import android.text.SpannableStringBuilder
import android.text.TextWatcher
import android.text.style.ForegroundColorSpan
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.inputmethod.InputMethodManager
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageButton
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.Switch
import android.util.Log
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.google.android.material.bottomnavigation.BottomNavigationView
import okhttp3.Call
import okhttp3.Callback
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import org.json.JSONObject
import java.io.IOException
import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.TimeZone

/**
 * 主界面（v1.4：首页世界地图 + 五页签 + 毛玻璃详情弹窗 + GPS 默认定位）：
 * - 底部导航五页签：首页 / 地震地图 / 数据分析 / 预警 / 我的，
 *   各页一个 ScrollView 切换；监测服务（WarningService）常驻，不受切页影响。
 * - 首页：顶栏“地震监测 · 日期 · 城市 · GPS”→ 播报条胶囊 →
 *   世界地图（太平洋居中，USGS 全球震中标记 + 用户绿点，+/- 缩放，
 *   左下角“最近一场距你 X 公里 · 体感”）→ 紧凑安全条
 *   （呼吸绿点、GPS自动定位、2分钟前更新、查看详情/重试连接）→
 *   左右并排：红色“最新强震”卡（USGS 过去 24 小时最强）+ “最新地震”
 *   （USGS 按震级前 3 场，排除红卡那场）→ “地震活动”折线图
 *   （CENC 目录近 7 天每日次数 + 3 个小统计）→ 3 个快捷入口 →
 *   “地震预警已开启”横幅。列表体感药丸按用户所在地预计烈度算，
 *   点开是毛玻璃详情弹窗，不再行内展开。
 * - 定位：默认 GPS 自动定位（启动时取手机位置，找最近城市做监测城市）；
 *   手动选城市仍保留在“我的 > 预警设置”，作为覆盖项。
 * - 地震地图：USGS / EMSC 全球地震，世界地图上按真实经纬度打点，
 *   点标记看详情卡 + AI 分析；全球地震仅供查看，绝不触发预警弹窗和倒计时。
 * - 数据分析：近 7 天 CENC 目录统计（每日数量、震级分布、最活跃地区，
 *   纯 View 条形图）+ 7 天 AI 总分析（本地规则汇总先行，在线模型后台替换）。
 * - 预警：报警状态与阈值摘要、提醒开关、测试预警、预警记录。
 * - 烈度显示规则（v1.3 修正）：震中烈度只显示台网给的数值；用户所在地
 *   预计烈度一律由震级 + 震中距衰减估算，绝不拿震中烈度当成本地烈度。
 */
class MainActivity : AppCompatActivity() {

    private val beijing = TimeZone.getTimeZone("Asia/Shanghai")
    private val client = OkHttpClient()
    private val handler = Handler(Looper.getMainLooper())

    /**
     * v1.6.1：地震报告修订接收——同一场地震另一路数据源发来更新的报告时，
     * 把内存里的目录同步成最新值并重画首页（震级/地点/来源/第几报）。
     */
    private val revisionReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent?.action != WarningService.ACTION_EEW_REVISION) return
            val key = intent.getStringExtra("event_key") ?: return
            val newLoc = intent.getStringExtra("location") ?: return
            val newMag = intent.getDoubleExtra("magnitude", -1.0)
            if (newMag < 0) return
            val newSource = intent.getStringExtra("source") ?: ""
            val newReportNum = intent.getIntExtra("report_num", 0)
            val newInt = intent.getIntExtra("intensity", -1)
            val newDepth = intent.getDoubleExtra("depth", -1.0)
            val originTime = intent.getLongExtra("time", 0L)
            val newLat = intent.getDoubleExtra("latitude", 0.0)
            val newLon = intent.getDoubleExtra("longitude", 0.0)
            val probe = Quake(
                "", originTime, newLoc, newMag, null, newLat, newLon, null
            )
            fun refresh(list: List<Quake>): List<Quake> {
                val idx = list.indexOfFirst {
                    QuakeMath.canonicalEventKey(it) == key || QuakeMath.sameEvent(it, probe)
                }
                if (idx < 0) return list
                val old = list[idx]
                val updated = old.copy(
                    location = newLoc, magnitude = newMag,
                    depthKm = newDepth.takeIf { it >= 0 } ?: old.depthKm,
                    intensity = newInt.takeIf { it > 0 } ?: old.intensity,
                    source = newSource.ifEmpty { old.source },
                    reportNum = if (newReportNum > 0) newReportNum else old.reportNum
                )
                return list.toMutableList().also { it[idx] = updated }
            }
            var changed = false
            val newCatalog = refresh(catalogFull)
            if (newCatalog !== catalogFull) {
                catalogFull = newCatalog
                changed = true
            }
            val newQuakes = refresh(quakes)
            if (newQuakes !== quakes) {
                quakes = newQuakes
                changed = true
            }
            if (changed) renderHome()
        }
    }

    private var dark = true
    private var appliedAppearance = ""
    private var quakes: List<Quake> = emptyList()
    private var weather: WeatherHelper.Forecast? = null
    private var userLat = 0.0
    private var userLon = 0.0

    private var searchQuery = ""
    // v1.6：地名搜索“历史最大”缓存（关键词 -> 历史最大地震；null = 已查过、无公开记录）
    private val searchHistCache = LinkedHashMap<String, Quake?>()
    // 正在查询中的关键词，避免每次按键重复发请求
    private val searchHistInflight = mutableSetOf<String>()
    // 首页 v1.4：CENC 完整目录（最新 50 条，供折线图统计）与 USGS 全球（供地图/红卡/最新列表）
    private var catalogFull: List<Quake> = emptyList()
    private var usgsHome: List<Quake> = emptyList()
    private var strongestGlobal: Quake? = null
    private var homeMapZoom = 1f
    // v1.6.2：上一次是否由“点标记飞过去”放大（仅此时弹窗关闭才飞回原视图）
    private var homeMapFlown = false
    private val homeMapPulseAnimators = mutableListOf<ValueAnimator>()
    private var placeNameTts: PlaceNameTts? = null
    private var voicePackPlayerHome: VoicePackPlayer? = null

    private var tickerPaused = false
    private var tickerStep = 0f
    private var tickerMax = 0
    private val tickerRunnable = object : Runnable {
        override fun run() {
            val sv = findViewById<HorizontalScrollView>(R.id.tickerScroll)
            if (!tickerPaused && tickerMax > 0) {
                val next = sv.scrollX + tickerStep
                if (next >= tickerMax) sv.scrollTo(0, 0) else sv.scrollBy(tickerStep.toInt(), 0)
            }
            handler.postDelayed(this, 50)
        }
    }

    private var currentTab = "home"

    // 地震地图页
    private var mapQuakes: List<Quake> = emptyList()
    private var mapSource = "usgs" // usgs / emsc
    private var mapRange = "day" // day / week（仅 USGS）
    private var mapLoadedAt = 0L
    private var selectedMapQuake: Quake? = null
    private var selectedMapQuakeSource = ""

    // 数据分析页 AI 汇总
    private var analysisAiDay = ""
    private var analysisAiLoading = false

    // 新地震语音播报去重
    private var seenQuakeIds = mutableSetOf<String>()
    private var firstCatalogLoad = true

    // GPS 定位：正在要位置时为 true（避免重复请求）
    private var gpsLookupRunning = false

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    // v1.4.9 触屏交互：按压缩放 + 轻震动反馈，让按钮/卡片摸起来有回应。
    private fun pressable(v: View) {
        v.setOnTouchListener { view, ev ->
            when (ev.action) {
                MotionEvent.ACTION_DOWN -> {
                    view.animate().scaleX(0.96f).scaleY(0.96f).setDuration(80).start()
                    view.performHapticFeedback(android.view.HapticFeedbackConstants.VIRTUAL_KEY)
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    view.animate().scaleX(1f).scaleY(1f).setDuration(120).start()
                }
            }
            false
        }
    }

    // v1.4.9 入场动画：首页内容淡入 + 轻微上滑，只播一次。
    private fun playEnterAnimation() {
        val root = findViewById<View>(R.id.rootMain) ?: return
        root.alpha = 0f
        root.translationY = dp(12).toFloat()
        root.animate().alpha(1f).translationY(0f).setDuration(320).start()
    }
    private fun tc1(): Int = if (dark) 0xFFFFFFFF.toInt() else 0xFF1A2E1A.toInt()
    private fun tc2(): Int = if (dark) 0xFFA8C4A0.toInt() else 0xFF4A6B4A.toInt()
    private fun cardBg(): Int = if (dark) R.drawable.glass_dark else R.drawable.glass_card_light

    private fun magColor(mag: Double): Int = when {
        mag < 4.0 -> ContextCompat.getColor(this, R.color.mag_low)
        mag < 5.0 -> ContextCompat.getColor(this, R.color.mag_mid)
        mag < 6.0 -> ContextCompat.getColor(this, R.color.mag_high)
        else -> ContextCompat.getColor(this, R.color.mag_severe)
    }

    private fun feelColor(local: Int): Int = when {
        local <= 2 -> ContextCompat.getColor(this, R.color.neon_green)
        local <= 4 -> ContextCompat.getColor(this, R.color.mag_mid)
        else -> ContextCompat.getColor(this, R.color.mag_severe)
    }

    /** v1.6：浅玻璃上体感 pill 的实底色。无感用深绿（亮绿底配白字看不清），其余用震感色实底。 */
    private fun feelPillColor(local: Int): Int =
        if (local <= 2) 0xFF2E7A1E.toInt() else feelColor(local)

    private fun prefs() = getSharedPreferences("prefs", Context.MODE_PRIVATE)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // 先定主题（v1.4.9）：必须在 setContentView 之前解析深/浅色与外观模式，
        // 否则 onResume 会因 appliedAppearance 还是初始值而误判“外观变了”反复 recreate，造成跟随系统模式闪屏。
        dark = LocalStore.isDark(this)
        appliedAppearance = LocalStore.appearance(this)
        // 安全启动（v1.4.8）：先把主界面画出来再做别的，让开屏立刻消失；
        // 所有初始化都推迟到第一帧之后，每一步单独 try-catch，一步坏了也不拖垮整个启动。
        try {
            setContentView(R.layout.activity_main)
        } catch (e: Throwable) {
            val tv = TextView(this)
            tv.text = "界面加载失败：\n" + Log.getStackTraceString(e)
            tv.setTextIsSelectable(true)
            tv.setPadding(24, 24, 24, 24)
            setContentView(tv)
            return
        }
        findViewById<View>(R.id.rootMain).post { runSafeStartup() }
    }

    private fun runSafeStartup() {
        val steps: List<Pair<String, () -> Unit>> = listOf(
            "loadUserLocation" to {
                loadUserLocation()
            },
            "applyStaticTheme" to { applyStaticTheme() },
            "setupTopBar" to { setupTopBar() },
            "setupBottomNav" to { setupBottomNav() },
            "setupHomeMap" to { setupHomeMap() },
            "setupShortcuts" to { setupShortcuts() },
            "setupMapPage" to { setupMapPage() },
            "setupAnalysisPage" to { setupAnalysisPage() },
            "setupAlertPage" to { setupAlertPage() },
            "listeners+service" to {
                findViewById<LinearLayout>(R.id.tickerCapsule).setOnClickListener {
                    toggleTickerPause()
                }
                findViewById<LinearLayout>(R.id.warnBanner).setOnClickListener {
                    findViewById<BottomNavigationView>(R.id.bottomNav).selectedItemId = R.id.nav_alert
                }
                // v1.6.1：监听地震报告修订（另一路数据源的更新报告），刷新首页列表显示
                registerReceiver(revisionReceiver, IntentFilter(WarningService.ACTION_EEW_REVISION))
                findViewById<Button>(R.id.btnRefreshQuakes).setOnClickListener { refreshAll(true) }
                if (!prefs().contains("service_wanted")) {
                    prefs().edit().putBoolean("service_wanted", true).apply()
                }
                if (prefs().getBoolean("service_wanted", true)) {
                    ContextCompat.startForegroundService(this, Intent(this, WarningService::class.java))
                }
            },
            "requestPermissions" to { requestPermissionsIfNeeded() },
            "initGpsLocation" to { initGpsLocation() },
            "refreshAll" to { refreshAll(true) }
        )
        for ((name, action) in steps) {
            try {
                action()
            } catch (e: Throwable) {
                Log.e("STARTUP", "step " + name + " failed, continuing", e)
            }
        }
        playEnterAnimation()
    }

    override fun onResume() {
        super.onResume()
        // 外观在提醒方式里改过，回来就重建
        if (LocalStore.appearance(this) != appliedAppearance) {
            recreate()
            return
        }
        loadUserLocation()
        // v1.6.2：每次回到前台，若 GPS 定位已超过 2 分钟没更新，重新定位一次
        // （用户经常出差/移动；只在前台做，不做持续后台定位）
        if (locationSource() == "gps") {
            val fixAge = System.currentTimeMillis() - prefs().getLong("user_fix_time", 0L)
            if (fixAge >= 120_000) fetchGpsLocation()
        }
        refreshStatus()
        renderHomeFromCache()
        renderMy()
        when (currentTab) {
            "analysis" -> renderAnalysis()
            "alert" -> renderAlertPage()
            "map" -> renderMapMarkers()
        }
    }

    override fun onDestroy() {
        try {
            unregisterReceiver(revisionReceiver)
        } catch (_: Exception) {
        }
        handler.removeCallbacks(tickerRunnable)
        placeNameTts?.release()
        voicePackPlayerHome?.release()
        super.onDestroy()
    }

    // ---------------- 外观 ----------------

    private fun applyStaticTheme() {
        if (dark) return // XML 默认就是深色
        findViewById<View>(R.id.rootMain).setBackgroundResource(R.drawable.bg_light)
        findViewById<View>(R.id.waveCard).setBackgroundResource(cardBg())
        findViewById<View>(R.id.tickerCapsule).setBackgroundResource(cardBg())
        findViewById<View>(R.id.myCard).setBackgroundResource(cardBg())
        val t1 = listOf(
            R.id.tvGreeting, R.id.tvCityTop,
            R.id.tvWaveCountVal, R.id.tvWaveMax7Val, R.id.tvWaveTotalVal,
            R.id.tvWaveSectionTitle,
            R.id.tvMyCity, R.id.tvWarnTitle, R.id.tvAlertStatus
        )
        for (id in t1) findViewById<TextView>(id).setTextColor(tc1())
        val t2 = listOf(
            R.id.tvDate, R.id.tvWaveSectionSub,
            R.id.tvTickerState, R.id.tvDataStatus, R.id.tvMyStatus,
            R.id.tvMyThresholds, R.id.tvMyDataStatus, R.id.tvMiniStatus,
            R.id.tvWarnSub, R.id.tvAlertThresholds, R.id.tvMapStatus,
            R.id.tvAnalysisNote
        )
        for (id in t2) findViewById<TextView>(id).setTextColor(tc2())
        findViewById<TextView>(R.id.tvTicker).setTextColor(tc1())
        // 浅色下快捷入口与搜索框也换浅色底
        findViewById<Button>(R.id.btnShortcutPreview).apply {
            setBackgroundResource(cardBg())
            setTextColor(tc1())
        }
        findViewById<Button>(R.id.btnShortcutShelter).apply {
            setBackgroundResource(cardBg())
            setTextColor(tc1())
        }
        findViewById<EditText>(R.id.etSearch).apply {
            setBackgroundResource(cardBg())
            setTextColor(tc1())
        }
        for (id in listOf(
            R.id.switchVoice, R.id.switchNewQuakeVoice,
            R.id.switchSound, R.id.switchVibrate
        )) {
            findViewById<Switch>(id).setTextColor(tc1())
        }
    }

    // ---------------- 顶栏 / 导航 ----------------

    private fun setupTopBar() {
        findViewById<TextView>(R.id.tvGreeting).text = "地震监测"
        findViewById<TextView>(R.id.tvDate).text = WeatherHelper.todayLabel()
        updateCityTop()
        findViewById<ImageButton>(R.id.btnSearch).setOnClickListener {
            val et = findViewById<EditText>(R.id.etSearch)
            val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
            if (et.visibility == View.GONE) {
                et.visibility = View.VISIBLE
                et.requestFocus()
                imm.showSoftInput(et, InputMethodManager.SHOW_IMPLICIT)
            } else {
                et.visibility = View.GONE
                et.setText("")
                imm.hideSoftInputFromWindow(et.windowToken, 0)
            }
        }
        // 搜索框：过滤右侧“最新地震”的 3 条（按中文地名或英文原名）
        findViewById<EditText>(R.id.etSearch).addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) {
                searchQuery = s?.toString()?.trim() ?: ""
                renderHomeLatest()
                renderSearchResult()
            }
        })
    }

    /** 定位来源：gps（默认，手机定位）/ manual（用户在“我的 > 预警设置”手动选城市）。 */
    private fun locationSource(): String = prefs().getString("location_source", "gps") ?: "gps"

    private fun updateCityTop() {
        val city = prefs().getString("user_city", "") ?: ""
        findViewById<TextView>(R.id.tvCityTop).text = when {
            city.isEmpty() -> "未设置城市"
            locationSource() == "gps" -> "$city · GPS"
            else -> city
        }
    }

    private fun setupBottomNav() {
        val nav = findViewById<BottomNavigationView>(R.id.bottomNav)
        nav.setOnItemSelectedListener { item ->
            when (item.itemId) {
                R.id.nav_home -> showTab("home")
                R.id.nav_map -> showTab("map")
                R.id.nav_analysis -> showTab("analysis")
                R.id.nav_alert -> showTab("alert")
                R.id.nav_my -> showTab("my")
            }
            true
        }
        nav.selectedItemId = R.id.nav_home
    }

    private fun showTab(tab: String) {
        currentTab = tab
        findViewById<ScrollView>(R.id.homeScroll).visibility =
            if (tab == "home") View.VISIBLE else View.GONE
        findViewById<ScrollView>(R.id.mapScroll).visibility =
            if (tab == "map") View.VISIBLE else View.GONE
        findViewById<ScrollView>(R.id.analysisScroll).visibility =
            if (tab == "analysis") View.VISIBLE else View.GONE
        findViewById<ScrollView>(R.id.alertScroll).visibility =
            if (tab == "alert") View.VISIBLE else View.GONE
        findViewById<ScrollView>(R.id.myScroll).visibility =
            if (tab == "my") View.VISIBLE else View.GONE
        val onHome = tab == "home"
        findViewById<View>(R.id.tickerCapsule).visibility =
            if (onHome) View.VISIBLE else View.GONE
        findViewById<ImageButton>(R.id.btnSearch).visibility =
            if (onHome) View.VISIBLE else View.GONE
        if (onHome) {
            if (!tickerPaused && tickerMax > 0) handler.post(tickerRunnable)
        } else {
            handler.removeCallbacks(tickerRunnable)
        }
        when (tab) {
            "map" -> {
                updateMapButtons()
                if (mapQuakes.isEmpty() ||
                    System.currentTimeMillis() - mapLoadedAt > 5 * 60_000L
                ) {
                    fetchMapData()
                } else {
                    renderMapMarkers()
                }
            }
            "analysis" -> renderAnalysis()
            "alert" -> renderAlertPage()
            "my" -> renderMy()
        }
    }

    private fun openMyPage(page: String) {
        startActivity(Intent(this, MyPageActivity::class.java).apply {
            putExtra("page", page)
        })
    }

    private fun setupShortcuts() {
        findViewById<Button>(R.id.btnShortcutPreview).setOnClickListener { openMyPage("preview") }
        findViewById<Button>(R.id.btnShortcutShelter).setOnClickListener { openMyPage("shelter") }
        findViewById<Button>(R.id.btnShortcutGuide).setOnClickListener { openMyPage("guide") }
    }

    // ---------------- 位置 / 权限 / 服务 ----------------

    private fun loadUserLocation() {
        userLat = prefs().getFloat("user_lat", 0f).toDouble()
        userLon = prefs().getFloat("user_lon", 0f).toDouble()
    }

    /**
     * GPS 默认定位（v1.4）：App 启动时默认用手机定位，不用手动输入城市。
     * 只在 location_source == "gps"（默认）时自动定位；用户在“我的 > 预警设置”
     * 手动选过城市后 location_source = "manual"，不再自动覆盖。
     * 权限拒绝或一时拿不到定位时，用上次保存的城市顶着，App 照常能用。
     */
    private fun initGpsLocation() {
        if (locationSource() != "gps") return
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
            != PackageManager.PERMISSION_GRANTED
        ) return // 权限在 requestPermissionsIfNeeded 里一起要；拿到后再定位
        fetchGpsLocation()
    }

    /**
     * v1.6.2 定位精度：上次位置只在“新鲜（<2 分钟）且精度 ≤1000 米”时才直接用；
     * 否则要一次实时单次定位（GPS 优先，没有 GPS 用网络定位，15 秒超时）。
     * 超时无新位置时退回上次位置（有总比没有强），再没有就保留已保存的城市。
     * 只在前台调用（启动 + 每次回到前台），不做持续后台定位（省电）。
     */
    private fun fetchGpsLocation() {
        if (gpsLookupRunning) return
        gpsLookupRunning = true
        val lm = try {
            getSystemService(Context.LOCATION_SERVICE) as LocationManager
        } catch (_: Exception) {
            null
        }
        if (lm == null) {
            gpsLookupRunning = false
            return
        }
        // 上次位置：新鲜（<2 分钟）且精度够（≤1000 米，或无精度信息）才直接用
        val last = try {
            lm.getLastKnownLocation(LocationManager.GPS_PROVIDER)
                ?: lm.getLastKnownLocation(LocationManager.NETWORK_PROVIDER)
        } catch (_: SecurityException) {
            null
        }
        if (last != null && isFreshFix(last)) {
            gpsLookupRunning = false
            onGpsLocation(last.latitude, last.longitude)
            return
        }
        // 否则要一次实时定位；超时无新位置时退回上次位置（若有）
        requestFreshFix(lm, last)
    }

    /** 上次位置是否新鲜可用：2 分钟内，且精度 ≤1000 米（无精度信息时视为可用）。 */
    private fun isFreshFix(loc: Location): Boolean {
        val ageMs = System.currentTimeMillis() - loc.time
        if (ageMs < 0 || ageMs >= 120_000) return false
        return !loc.hasAccuracy() || loc.accuracy <= 1000f
    }

    /** 要一次实时单次定位（GPS 优先，没有 GPS 用网络定位）；15 秒超时无新位置时退回上次位置。 */
    private fun requestFreshFix(lm: LocationManager, fallback: Location?) {
        var done = false
        lateinit var timeout: Runnable
        val listener = object : LocationListener {
            override fun onLocationChanged(loc: Location) {
                if (done) return
                done = true
                handler.removeCallbacks(timeout)
                try { lm.removeUpdates(this) } catch (_: Exception) {}
                gpsLookupRunning = false
                onGpsLocation(loc.latitude, loc.longitude)
            }
            override fun onProviderDisabled(provider: String) {}
            override fun onProviderEnabled(provider: String) {}
            @Deprecated("Deprecated in Java")
            override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {}
        }
        timeout = Runnable {
            if (done) return@Runnable
            done = true
            gpsLookupRunning = false
            try { lm.removeUpdates(listener) } catch (_: Exception) {}
            if (fallback != null) {
                // 超时无新位置：退回上次位置（有总比没有强）
                onGpsLocation(fallback.latitude, fallback.longitude)
            }
        }
        try {
            if (lm.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
                lm.requestSingleUpdate(LocationManager.GPS_PROVIDER, listener, Looper.getMainLooper())
            } else if (lm.isProviderEnabled(LocationManager.NETWORK_PROVIDER)) {
                lm.requestSingleUpdate(LocationManager.NETWORK_PROVIDER, listener, Looper.getMainLooper())
            } else {
                done = true
                gpsLookupRunning = false
                if (fallback != null) onGpsLocation(fallback.latitude, fallback.longitude)
                return
            }
        } catch (_: SecurityException) {
            done = true
            gpsLookupRunning = false
            if (fallback != null) onGpsLocation(fallback.latitude, fallback.longitude)
            return
        }
        handler.postDelayed(timeout, 15_000)
    }

    /** 拿到经纬度后，在已有的城市列表里找最近的城市作为监测城市。 */
    private fun onGpsLocation(lat: Double, lon: Double) {
        if (lat == 0.0 && lon == 0.0) return
        if (locationSource() != "gps") return
        val city = CityData.cities.minByOrNull { QuakeMath.distanceKm(lat, lon, it.lat, it.lon) } ?: return
        prefs().edit()
            .putString("user_city", city.name)
            .putFloat("user_lat", lat.toFloat())
            .putFloat("user_lon", lon.toFloat())
            .putLong("user_fix_time", System.currentTimeMillis())
            .putString("location_source", "gps")
            .apply()
        userLat = lat
        userLon = lon
        updateCityTop()
        refreshStatus()
        renderHome()
        // 天气按新位置重取（跑马灯里的天气条目）
        WeatherHelper.fetch(userLat, userLon) { f ->
            weather = f
            runOnUiThread { renderTicker() }
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int, permissions: Array<out String>, grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 101) {
            val idx = permissions.indexOf(Manifest.permission.ACCESS_FINE_LOCATION)
            if (idx >= 0 && grantResults.getOrNull(idx) == PackageManager.PERMISSION_GRANTED) {
                fetchGpsLocation()
            }
        }
    }

    private fun requestPermissionsIfNeeded() {
        val needed = mutableListOf<String>()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
            != PackageManager.PERMISSION_GRANTED
        ) {
            needed.add(Manifest.permission.POST_NOTIFICATIONS)
        }
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
            != PackageManager.PERMISSION_GRANTED
        ) {
            needed.add(Manifest.permission.ACCESS_FINE_LOCATION)
        }
        if (needed.isNotEmpty()) {
            ActivityCompat.requestPermissions(this, needed.toTypedArray(), 101)
        }
    }

    // ---------------- 通用小组件 ----------------

    /** 小芯片背景（圆角描边 + 低透明度同色填充）。 */
    private fun chipBackground(color: Int): GradientDrawable {
        return GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = dp(11).toFloat()
            setColor(Color.argb(0x1F, Color.red(color), Color.green(color), Color.blue(color)))
            setStroke(dp(1), color)
        }
    }

    private fun makeChip(text: String, color: Int): TextView {
        return TextView(this).apply {
            this.text = text
            textSize = 11f
            setTextColor(color)
            setPadding(dp(8), dp(3), dp(8), dp(3))
            background = chipBackground(color)
        }
    }

    /** 统计行：左标题右数值（毛玻璃卡片）。 */
    private fun buildStatRow(key: String, value: String): View {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setBackgroundResource(cardBg())
            setPadding(dp(14), dp(12), dp(14), dp(12))
            val lp = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
            lp.bottomMargin = dp(8)
            layoutParams = lp
        }
        row.addView(TextView(this).apply {
            text = key
            textSize = 14f
            setTextColor(tc2())
            val lp = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            layoutParams = lp
        })
        row.addView(TextView(this).apply {
            text = value
            textSize = 15f
            setTypeface(null, android.graphics.Typeface.BOLD)
            setTextColor(tc1())
        })
        return row
    }

    /** v1.6.2：曲线图卡片——深色毛玻璃底 + 平滑折线图（圆点 + 数值 + 面积渐变）。 */
    private fun buildChartCard(data: List<Pair<String, Int>>, lineColor: Int): View {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundResource(R.drawable.glass_dark)
            elevation = dp(8).toFloat()
            setPadding(dp(16), dp(12), dp(16), dp(12))
            val lp = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
            layoutParams = lp
        }
        val chart = WaveformChartView(this).apply {
            setData(data.map { WaveformChartView.DayPoint(it.first, it.second) })
            setLineColor(lineColor)
            setShowValueLabels(true)
            val lp = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                dp(180)
            )
            layoutParams = lp
        }
        card.addView(chart)
        return card
    }

    /** v1.6.2：最活跃地区排名行——名次 + 地名 + 场次，纯文本无条形。 */
    private fun buildRegionRankRow(rank: Int, name: String, count: Int): View {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(4), dp(8), dp(4), dp(8))
            val lp = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
            layoutParams = lp
        }
        row.addView(TextView(this).apply {
            text = "$rank"
            textSize = 15f
            setTypeface(null, Typeface.BOLD)
            setTextColor(ContextCompat.getColor(this@MainActivity, R.color.neon_green))
            gravity = Gravity.CENTER
            val lp = LinearLayout.LayoutParams(dp(28), LinearLayout.LayoutParams.WRAP_CONTENT)
            layoutParams = lp
        })
        row.addView(TextView(this).apply {
            text = name
            textSize = 14f
            setTextColor(tc1())
            val lp = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            lp.marginStart = dp(8)
            layoutParams = lp
        })
        row.addView(TextView(this).apply {
            text = "$count 场"
            textSize = 14f
            setTypeface(null, Typeface.BOLD)
            setTextColor(tc1())
        })
        return row
    }

    // ---------------- 状态 ----------------

    /** 推送状态只在这里显示（顶栏小字 + 底部迷你状态条 + 预警横幅），不另弹重复提示。
     *  v1.5.2：安全卡片已取消，状态改为顶栏“地震监测”下面的小字（日期 · 安全 · 监测中）。 */
    private fun refreshStatus() {
        val status = prefs().getString("service_status", "stopped") ?: "stopped"
        val last = prefs().getLong("last_update", 0L)
        val mini = findViewById<TextView>(R.id.tvMiniStatus)
        val timeText = if (last > 0) {
            val diffMin = (System.currentTimeMillis() - last) / 60000
            if (diffMin < 1) "刚刚更新" else "$diffMin 分钟前更新"
        } else {
            "尚未更新"
        }
        val titleText: String
        when (status) {
            "ws_connected" -> {
                titleText = "安全 · 监测中"
                mini.text = "推送已连接 · $timeText"
            }
            "polling" -> {
                titleText = "推送断开 · 轮询兜底中"
                mini.text = "推送断开 · 轮询兜底中 · $timeText"
            }
            "connecting" -> {
                titleText = "正在连接推送通道…"
                mini.text = "正在连接推送通道…"
            }
            else -> {
                titleText = "服务未运行"
                mini.text = "服务未运行 · $timeText"
            }
        }
        // 顶栏小字：日期 · 安全状态（小字、半透明感，替代原来的安全卡片）
        findViewById<TextView>(R.id.tvDate).text =
            "${WeatherHelper.todayLabel()} · $titleText · $timeText"
        findViewById<TextView>(R.id.tvWarnTitle).text =
            if (status == "stopped") "地震预警未开启" else "地震预警已开启"
        findViewById<TextView>(R.id.tvWarnSub).text = "附近暂无强震 · ${mini.text}"
        findViewById<TextView>(R.id.tvDataStatus).text =
            "数据来源：中国地震台网 · " +
                if (LocalStore.lastCatalogAt(this) > 0) {
                    "更新于 " + SimpleDateFormat("HH:mm:ss", Locale.CHINA).apply {
                        timeZone = beijing
                    }.format(Date(LocalStore.lastCatalogAt(this)))
                } else {
                    "尚未更新"
                }
    }


    // ---------------- 数据拉取 ----------------

    private fun refreshAll(showSkeleton: Boolean) {
        if (showSkeleton) {
            findViewById<LinearLayout>(R.id.llSkeleton).visibility = View.VISIBLE
        }
        val request = Request.Builder().url(WarningService.CATALOG_URL).build()
        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                runOnUiThread {
                    findViewById<LinearLayout>(R.id.llSkeleton).visibility = View.GONE
                    Toast.makeText(this@MainActivity, "获取失败：${e.message}", Toast.LENGTH_SHORT).show()
                    refreshStatus()
                }
            }

            override fun onResponse(call: Call, response: Response) {
                val body = response.body?.string() ?: return
                val list = EewParser.parseCatalog(body)
                catalogFull = list
                LocalStore.saveRecentFull(this@MainActivity, list.take(20))
                runOnUiThread {
                    findViewById<LinearLayout>(R.id.llSkeleton).visibility = View.GONE
                    // 新地震语音播报：只对本次刷新后新出现的地震播报，
                    // 首次加载只记下已有 ID，不播报，避免一打开就连读几十条
                    val newOnes = if (firstCatalogLoad) {
                        emptyList()
                    } else {
                        list.filter { it.eventId !in seenQuakeIds }
                    }
                    seenQuakeIds.addAll(list.map { it.eventId })
                    firstCatalogLoad = false
                    quakes = LocalStore.recentFull(this@MainActivity)
                    renderHome()
                    refreshStatus()
                    announceNewQuakes(newOnes)
                }
            }
        })
        if (userLat != 0.0 || userLon != 0.0) {
            WeatherHelper.fetch(userLat, userLon) { f ->
                weather = f
                runOnUiThread {
                    renderTicker()
                }
            }
        }
        // 首页全球数据（USGS，失败时静默，首页已有 CENC 数据兜底）
        fetchUsgsHome()
    }

    /**
     * 新地震语音播报（v1.4，三层 fallback，铁律：宁可不报地名，也不报粤语）：
     * 1) 地名：在线普通话 TTS（Google Translate TTS，带缓存），取到就播并缓存；
     * 2) 在线取失败：跳过地名，只用预录语音包报震级 + 体感；
     * 3) 系统 TTS 绝不用于地名（本机无普通话语音时会 fallback 到粤语）。
     */
    private fun announceNewQuakes(newOnes: List<Quake>) {
        if (newOnes.isEmpty()) return
        if (!prefs().getBoolean("voice_on", true)) return
        if (!prefs().getBoolean("voice_new_quake_on", true)) return
        // 达到报警阈值的交给 WarningService 的预警弹窗播报，这里不重复读；
        // 后台服务已通知过的（notifyNonAlert 写进 notified_ids）也跳过，避免重复播报
        val notified = prefs().getString("notified_ids", "")!!
            .split(",").filter { it.isNotEmpty() }.toSet()
        val eligible = newOnes.filter { q ->
            q.magnitude >= 3.0 && !wouldAlert(q) && q.eventId !in notified
        }
        if (eligible.isEmpty()) return
        val q = eligible.maxByOrNull { it.magnitude } ?: return
        val hasLoc = userLat != 0.0 || userLon != 0.0
        val dist = if (hasLoc) QuakeMath.distanceKm(userLat, userLon, q.latitude, q.longitude) else 0.0
        val local = if (hasLoc) QuakeMath.estimateIntensity(q.magnitude, dist) else null
        val feeling = local?.let { QuakeMath.feelingText(it) }
        // v1.6 Bug 2：已发生 ≥2 分钟的地震，句首加“X分钟前”（与 WarningService 一致）
        val ageMin = ((System.currentTimeMillis() - q.timeMillis) / 60000).toInt()
        val agePrefix = if (ageMin >= 2) "${ageMin}分钟前，" else ""
        val sentence = buildString {
            append("$agePrefix${q.location}发生${q.magnitude}级地震")
            if (hasLoc && local != null && feeling != null) {
                append("，距你约${dist.toInt()}公里，我所在地预计${local}度，$feeling")
            }
        }
        if (placeNameTts == null) placeNameTts = PlaceNameTts(this)
        // v1.6.1 播报记录：首页播报的地震也记一条（后台服务已通知过的在上面
        // 已被 notified_ids 过滤掉，不会到这里；upsert 保证不重复记）
        LocalStore.addAlertHistory(
            this, "real", q.location, q.magnitude, -1,
            eventId = q.eventId, source = q.source,
            reportNum = q.reportNum, kind = "notification",
            eventKey = QuakeMath.canonicalEventKey(q),
            originTime = q.timeMillis
        )
        placeNameTts?.speak(sentence) { ok ->
            if (!ok && feeling != null) {
                runOnUiThread { getHomeVoicePack()?.playMagnitudeAndFeeling(q.magnitude, feeling) }
            }
        }
    }

    /** 首页播报用的语音包播放器（按“倒计时语音”设置；选“系统语音”时返回 null）。 */
    private fun getHomeVoicePack(): VoicePackPlayer? {
        val pack = LocalStore.voicePack(this)
        if (pack == "system") return null
        if (voicePackPlayerHome == null) {
            voicePackPlayerHome = VoicePackPlayer(this, pack)
        }
        return voicePackPlayerHome
    }

    /** 按 WarningService.evaluate 同样的阈值判断：这场地震会不会触发预警弹窗。 */
    private fun wouldAlert(q: Quake): Boolean {
        if (userLat == 0.0 && userLon == 0.0) return false
        val dist = QuakeMath.distanceKm(userLat, userLon, q.latitude, q.longitude)
        val sArrival = QuakeMath.sArrivalMillis(q.timeMillis, dist)
        val leadSec = (sArrival - System.currentTimeMillis()) / 1000
        if (leadSec < prefs().getInt("min_lead_sec", 5)) return false
        if (q.magnitude < prefs().getFloat("min_mag", 0f).toDouble()) return false
        val intensity = q.intensity ?: QuakeMath.estimateIntensity(q.magnitude, dist)
        if (intensity < prefs().getInt("min_intensity", 0)) return false
        return true
    }

    private fun renderHomeFromCache() {
        quakes = LocalStore.recentFull(this)
        renderHome()
        renderTicker()
    }

    // ---------------- 播报条 ----------------

    // v1.6：跑马灯不再滚动地震信息，只滚动恶劣天气 / 海啸 / 地质灾害。
    // v1.6.2：灾害段放最前，预报垫底且只取 2 天，循环变短，灾害段不再“看不见”。
    // 天气来自 Open-Meteo 真实预报；海啸与地质灾害暂无已验证的公开数据源，
    // 绝不编造具体预警（不编地名、级别、时间），只显示诚实的中性提示。
    private fun renderTicker() {
        val items = mutableListOf<Pair<String, Int>>()
        // v1.6.2：灾害段放最前（恶劣天气灾害 → 海啸 → 地质灾害），预报垫底。
        val addItems: (List<Pair<String, Int>>) -> Unit = { list ->
            for ((text, level) in list) {
                val color = when (level) {
                    2 -> ContextCompat.getColor(this, R.color.mag_severe)
                    1 -> ContextCompat.getColor(this, R.color.mag_mid)
                    else -> 0xFF7FB3D5.toInt()
                }
                items.add(text to color)
            }
        }
        // 1. 恶劣天气灾害（真实预报数据；无灾害时为空）
        weather?.let { f -> addItems(WeatherHelper.tickerHazardItems(f)) }
        // 2. 海啸：无已验证公开数据源，不编造具体预警
        items.add("海啸预警 · 暂无海啸预警信息" to 0xFF7FB3D5.toInt())
        // 3. 地质灾害：无已验证公开数据源，不编造具体预警
        items.add("地质灾害预警 · 数据待接入" to 0xFF7FB3D5.toInt())
        // 4. 预报垫底（无灾害时只取 2 天）
        weather?.let { f -> addItems(WeatherHelper.tickerForecastItems(f)) }
        val sb = SpannableStringBuilder()
        for ((text, color) in items) {
            if (sb.isNotEmpty()) sb.append("      ")
            val start = sb.length
            sb.append("● ")
            sb.setSpan(
                ForegroundColorSpan(color), start, sb.length,
                SpannableStringBuilder.SPAN_EXCLUSIVE_EXCLUSIVE
            )
            sb.append(text)
        }
        val tv = findViewById<TextView>(R.id.tvTicker)
        tv.text = sb
        findViewById<TextView>(R.id.tvTickerDot)
            .setTextColor(items.first().second)
        startTickerScroll()
    }

    private fun startTickerScroll() {
        handler.removeCallbacks(tickerRunnable)
        if (LocalStore.reducedMotion(this)) {
            findViewById<TextView>(R.id.tvTickerState).text = "已暂停（已减少动态）"
            return
        }
        val sv = findViewById<HorizontalScrollView>(R.id.tickerScroll)
        val tv = findViewById<TextView>(R.id.tvTicker)
        sv.post {
            val total = tv.width - sv.width
            if (total > 0) {
                tickerMax = total
                tickerStep = total / (90f * 20f) // 约 90 秒一圈
                if (!tickerPaused) {
                    findViewById<TextView>(R.id.tvTickerState).text = "滚动中"
                    handler.post(tickerRunnable)
                }
            }
        }
    }

    private fun toggleTickerPause() {
        tickerPaused = !tickerPaused
        findViewById<TextView>(R.id.tvTickerState).text =
            if (tickerPaused) "已暂停" else "滚动中"
        if (!tickerPaused) handler.post(tickerRunnable)
        else handler.removeCallbacks(tickerRunnable)
    }

    // ---------------- 首页渲染（v1.4：世界地图 + 安全条 + 最新强震 + 折线图） ----------------

    private fun renderHome() {
        updateCityTop()
        refreshStatus() // 安全条 / 迷你状态 / 预警横幅
        renderHomeMap()
        renderStrongest()
        renderHomeLatest()
        renderWaveform()
        if (currentTab == "analysis") renderAnalysis()
    }

    private fun setupHomeMap() {
        val zoomIn = findViewById<TextView>(R.id.btnZoomIn)
        val zoomOut = findViewById<TextView>(R.id.btnZoomOut)
        zoomIn.setOnClickListener {
            homeMapZoom = minOf(2.5f, homeMapZoom + 0.5f)
            applyHomeMapZoom()
        }
        zoomOut.setOnClickListener {
            homeMapZoom = maxOf(1f, homeMapZoom - 0.5f)
            applyHomeMapZoom()
        }
        pressable(zoomIn)
        pressable(zoomOut)
        findViewById<TextView>(R.id.tvWaveMore).setOnClickListener {
            findViewById<BottomNavigationView>(R.id.bottomNav).selectedItemId = R.id.nav_analysis
        }
    }

    private fun applyHomeMapZoom() {
        val wrap = findViewById<FrameLayout>(R.id.mapZoomWrap)
        wrap.scaleX = homeMapZoom
        wrap.scaleY = homeMapZoom
        wrap.pivotX = 0.5f
        wrap.pivotY = 0.5f
        // 缩回 1.0 时复位平移，地图回到居中
        if (homeMapZoom <= 1f) {
            wrap.translationX = 0f
            wrap.translationY = 0f
        }
    }

    /** 点震中“飞过去”：地图平滑移动并放大到该点，动画结束后再弹详情。 */
    private fun flyToHomeMarker(xPct: Double, yPct: Double, q: Quake) {
        val wrap = findViewById<FrameLayout>(R.id.mapZoomWrap)
        val w = wrap.width
        val h = wrap.height
        if (w == 0 || h == 0) {
            showQuakeDetailDialog(q, "usgs")
            return
        }
        // 目标：放大到 1.8 倍，并把该点移到画面中心
        val targetScale = 1.8f
        val cx = (w * xPct).toFloat()
        val cy = (h * yPct).toFloat()
        val targetTx = -(cx - w / 2f) * targetScale
        val targetTy = -(cy - h / 2f) * targetScale
        wrap.pivotX = w / 2f
        wrap.pivotY = h / 2f
        val anims = AnimatorSet().apply {
            playTogether(
                ObjectAnimator.ofFloat(wrap, "scaleX", wrap.scaleX, targetScale),
                ObjectAnimator.ofFloat(wrap, "scaleY", wrap.scaleY, targetScale),
                ObjectAnimator.ofFloat(wrap, "translationX", wrap.translationX, targetTx),
                ObjectAnimator.ofFloat(wrap, "translationY", wrap.translationY, targetTy)
            )
            duration = 600
            interpolator = DecelerateInterpolator()
        }
        anims.start()
        homeMapZoom = targetScale
        homeMapFlown = true
        // 动画结束后再弹详情
        wrap.postDelayed({ showQuakeDetailDialog(q, "usgs") }, 620)
    }

    /** v1.6.2：详情弹窗关闭后，地图动画回到原始视图（1.0x + 平移归零），再点标记可重新飞过去。仅当上一次是“点标记飞过去”放大时才恢复；手动 +/- 缩放不受影响。 */
    private fun restoreHomeMapZoom() {
        if (!homeMapFlown) return
        homeMapFlown = false
        val wrap = findViewById<FrameLayout>(R.id.mapZoomWrap)
        val anims = AnimatorSet().apply {
            playTogether(
                ObjectAnimator.ofFloat(wrap, "scaleX", wrap.scaleX, 1f),
                ObjectAnimator.ofFloat(wrap, "scaleY", wrap.scaleY, 1f),
                ObjectAnimator.ofFloat(wrap, "translationX", wrap.translationX, 0f),
                ObjectAnimator.ofFloat(wrap, "translationY", wrap.translationY, 0f)
            )
            duration = 600
            interpolator = DecelerateInterpolator()
            addListener(object : AnimatorListenerAdapter() {
                override fun onAnimationEnd(animation: Animator) {
                    // 状态复位干净：缩放 1.0、平移归零、中心轴，下次点标记从原始状态重新飞
                    homeMapZoom = 1f
                    wrap.pivotX = wrap.width / 2f
                    wrap.pivotY = wrap.height / 2f
                    wrap.translationX = 0f
                    wrap.translationY = 0f
                }
            })
        }
        anims.start()
    }

    /** 世界地图震中标记（太平洋居中投影，x%=((lon-150+540)%360)/360，y%=(90-lat)/180）。 */
    private fun renderHomeMap() {
        val layer = findViewById<FrameLayout>(R.id.homeMarkerLayer)
        layer.post {
            val w = layer.width
            val h = layer.height
            if (w == 0 || h == 0) return@post
            for (a in homeMapPulseAnimators) a.cancel()
            homeMapPulseAnimators.clear()
            layer.removeAllViews()
            // 先算用户点的位置，供震中标签避让用
            var ux = -1
            var uy = -1
            if (userLat != 0.0 || userLon != 0.0) {
                ux = (w * (((userLon - 150 + 540) % 360) / 360.0)).toInt()
                uy = (h * ((90 - userLat) / 180.0)).toInt()
            }
            // 全球按震级取前 6 场
            for (q in usgsHome.sortedByDescending { it.magnitude }.take(6)) {
                addHomeMarker(layer, w, h, q, ux, uy)
            }
            if (ux >= 0 && uy >= 0) addUserMarker(layer, ux, uy)
            updateHomeMapChip()
        }
    }

    private fun homeMarkerColor(mag: Double): Int = when {
        mag >= 6.0 -> 0xFFFF3B30.toInt() // 红
        mag >= 5.0 -> 0xFFFF9500.toInt() // 橙
        else -> 0xFFF5C542.toInt() // 琥珀黄（M3–4）
    }

    private fun addHomeMarker(layer: FrameLayout, w: Int, h: Int, q: Quake, ux: Int, uy: Int) {
        val xPct = ((q.longitude - 150 + 540) % 360) / 360.0
        val yPct = (90 - q.latitude) / 180.0
        if (xPct < 0.0 || xPct > 1.0 || yPct < 0.0 || yPct > 1.0) return
        val cx = (w * xPct).toInt()
        val cy = (h * yPct).toInt()
        val color = homeMarkerColor(q.magnitude)
        val dotSize = when {
            q.magnitude >= 6.0 -> dp(20)
            q.magnitude >= 5.0 -> dp(18)
            else -> dp(16)
        }
        val haloSize = when {
            q.magnitude >= 6.0 -> dp(64)
            q.magnitude >= 5.0 -> dp(56)
            else -> dp(48)
        }
        val openDetail = View.OnClickListener { flyToHomeMarker(xPct, yPct, q) }
        // 脉冲光晕圈：不断向外扩散淡出（减少动态时静态）
        val halo = View(this).apply {
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.TRANSPARENT)
                setStroke(dp(2), Color.argb(180, Color.red(color), Color.green(color), Color.blue(color)))
            }
            setOnClickListener(openDetail)
        }
        placeInLayer(layer, halo, cx - haloSize / 2, cy - haloSize / 2, haloSize, haloSize)
        if (!LocalStore.reducedMotion(this)) {
            val pulse = ValueAnimator.ofFloat(0.45f, 1.35f).apply {
                duration = 2000
                repeatCount = ValueAnimator.INFINITE
                repeatMode = ValueAnimator.RESTART
                addUpdateListener { a ->
                    val f = a.animatedValue as Float
                    halo.scaleX = f
                    halo.scaleY = f
                    halo.alpha = (1.35f - f) / 0.9f
                }
            }
            pulse.start()
            homeMapPulseAnimators.add(pulse)
        }
        // 震中点
        val dot = View(this).apply {
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(color)
                setStroke(dp(2), Color.WHITE)
            }
            setOnClickListener(openDetail)
        }
        placeInLayer(layer, dot, cx - dotSize / 2, cy - dotSize / 2, dotSize, dotSize)
        // 标签：地点 + 震级；离用户点太近时放上方避让，否则放下方
        val nearUser = ux >= 0 && kotlin.math.abs(cx - ux) < dp(48) && kotlin.math.abs(cy - uy) < dp(48)
        val label = TextView(this).apply {
            text = "${cnPlace(q.location, short = true)} ${q.magnitude}"
            textSize = 11f
            setTypeface(null, Typeface.BOLD)
            setTextColor(Color.WHITE)
            background = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadius = dp(8).toFloat()
                setColor(0x99000000.toInt())
            }
            setPadding(dp(6), dp(3), dp(6), dp(3))
            setOnClickListener(openDetail)
        }
        label.measure(View.MeasureSpec.UNSPECIFIED, View.MeasureSpec.UNSPECIFIED)
        val lw = label.measuredWidth
        val lh = label.measuredHeight
        val lx = (cx - lw / 2).coerceIn(0, maxOf(0, w - lw))
        val ly = if (nearUser) (cy - dotSize / 2 - 4 - lh).coerceAtLeast(0)
        else cy + dotSize / 2 + 4
        placeInLayer(layer, label, lx, ly, lw, lh)
    }

    private fun addUserMarker(layer: FrameLayout, ux: Int, uy: Int) {
        val green = ContextCompat.getColor(this, R.color.neon_green)
        val dotSize = dp(16)
        val haloSize = dp(48)
        val halo = View(this).apply {
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.TRANSPARENT)
                setStroke(dp(2), Color.argb(180, Color.red(green), Color.green(green), Color.blue(green)))
            }
        }
        placeInLayer(layer, halo, ux - haloSize / 2, uy - haloSize / 2, haloSize, haloSize)
        val dot = View(this).apply {
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(green)
                setStroke(dp(2), Color.WHITE)
            }
        }
        placeInLayer(layer, dot, ux - dotSize / 2, uy - dotSize / 2, dotSize, dotSize)
        val city = prefs().getString("user_city", "") ?: ""
        val label = TextView(this).apply {
            text = if (city.isEmpty()) "你在这里" else "$city · 你在这里"
            textSize = 11f
            setTypeface(null, Typeface.BOLD)
            setTextColor(Color.WHITE)
            background = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadius = dp(8).toFloat()
                setColor(0x99000000.toInt())
            }
            setPadding(dp(6), dp(3), dp(6), dp(3))
        }
        label.measure(View.MeasureSpec.UNSPECIFIED, View.MeasureSpec.UNSPECIFIED)
        placeInLayer(layer, label, ux + dotSize / 2 + 6, uy - label.measuredHeight / 2,
            label.measuredWidth, label.measuredHeight)
    }

    private fun placeInLayer(layer: FrameLayout, v: View, left: Int, top: Int, w: Int, h: Int) {
        val lp = FrameLayout.LayoutParams(w, h)
        lp.leftMargin = left
        lp.topMargin = top
        v.layoutParams = lp
        layer.addView(v)
    }

    /** 地图左下角 chip：离用户最近的一场（CENC 目录）。 */
    private fun updateHomeMapChip() {
        val tv = findViewById<TextView>(R.id.tvHomeMapChip)
        if (userLat == 0.0 && userLon == 0.0) {
            tv.text = "设置位置后显示最近地震"
            return
        }
        val nearest = quakes.minByOrNull { QuakeMath.distanceKm(userLat, userLon, it.latitude, it.longitude) }
        if (nearest == null) {
            tv.text = "暂无地震数据"
            return
        }
        val dist = QuakeMath.distanceKm(userLat, userLon, nearest.latitude, nearest.longitude)
        val local = QuakeMath.estimateIntensity(nearest.magnitude, dist)
        tv.text = "最近一场距你 ${fmtDistKm(dist)} 公里 · ${QuakeMath.feelingText(local)}"
    }

    /** 距离格式化：≥1000km 时向下取整到百公里并加千分位（约 10,000km，不给假精度）。 */
    private fun fmtDistKm(dist: Double): String {
        val d = dist.toInt()
        return if (d >= 1000) "%,d".format((d / 100) * 100) else "$d"
    }

    /** 首页 USGS 全球 feed（2.5_day，公开接口），取震级最大的前几场。 */
    private fun fetchUsgsHome() {
        val url = "https://earthquake.usgs.gov/earthquakes/feed/v1.0/summary/2.5_day.geojson"
        client.newCall(Request.Builder().url(url).build()).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                // 首页已有 CENC 数据兜底，USGS 失败时静默（不弹错）
            }
            override fun onResponse(call: Call, response: Response) {
                val body = response.body?.string() ?: return
                val list = parseUsgsGeoJson(body).sortedByDescending { it.magnitude }
                runOnUiThread {
                    usgsHome = list
                    strongestGlobal = list.firstOrNull()
                    renderStrongest()
                    renderHomeLatest()
                    renderHomeMap()
                }
            }
        })
    }

    /** 左侧红色“最新强震”卡：USGS 过去 24 小时震级最大的一场。 */
    private fun renderStrongest() {
        val card = findViewById<LinearLayout>(R.id.strongCard)
        val q = strongestGlobal
        if (q == null) {
            findViewById<TextView>(R.id.tvStrongMag).text = "-"
            findViewById<TextView>(R.id.tvStrongPlace).text = "正在加载全球地震…"
            findViewById<TextView>(R.id.tvStrongMeta).text = ""
            findViewById<TextView>(R.id.tvStrongFeel).text = ""
            card.setOnClickListener(null)
            return
        }
        // v1.6.2：红卡用深红调毛玻璃（XML 已设）；不要再用震级色 tintedGlass 覆盖
        card.setBackgroundResource(R.drawable.glass_dark_red)
        findViewById<TextView>(R.id.tvStrongMag).text = "${q.magnitude}"
        findViewById<TextView>(R.id.tvStrongPlace).text = cnPlace(q.location, short = false)
        val timeText = SimpleDateFormat("MM-dd HH:mm", Locale.CHINA).apply { timeZone = beijing }
            .format(Date(q.timeMillis))
        val depthText = q.depthKm?.let { " · 深 ${it.toInt()}km" } ?: ""
        val distText = if (userLat != 0.0 || userLon != 0.0) {
            "\n距你约 ${fmtDistKm(QuakeMath.distanceKm(userLat, userLon, q.latitude, q.longitude))}km"
        } else ""
        findViewById<TextView>(R.id.tvStrongMeta).text = "$timeText$depthText$distText"
        val feelTv = findViewById<TextView>(R.id.tvStrongFeel)
        if (userLat != 0.0 || userLon != 0.0) {
            val local = QuakeMath.localIntensity(q, userLat, userLon)
            if (local != null) {
                feelTv.text = QuakeMath.feelingText(local)
                // v1.6.2：深玻璃上用实底 pill + 白字；无感深绿，其他体感用对应震感色实底
                feelTv.background = GradientDrawable().apply {
                    shape = GradientDrawable.RECTANGLE
                    cornerRadius = dp(10).toFloat()
                    setColor(feelPillColor(local))
                }
                feelTv.setTextColor(Color.WHITE)
            } else feelTv.text = ""
        } else feelTv.text = ""
        card.setOnClickListener { showQuakeDetailDialog(q, "usgs") }
    }

    /** 右侧“最新地震”：CENC + USGS 合并去重，按时间倒序取前 3 场，排除红卡已展示的那一场；支持搜索过滤。 */
    private fun renderHomeLatest() {
        val ll = findViewById<LinearLayout>(R.id.llHomeLatest)
        ll.removeAllViews()
        // v1.6 Bug 1：之前只用 usgsHome，CENC 的中国地震进不了列表。现合并两路目录去重
        // （eventId 相同判重；eventId 不同但地点相同且时间差 < 60 秒也算同一场，优先保留 CENC）。
        val merged = quakes + usgsHome
        val deduped = mutableListOf<Quake>()
        for (q in merged) {
            val isDup = deduped.any { e ->
                (q.eventId.isNotEmpty() && e.eventId.isNotEmpty() && e.eventId == q.eventId) ||
                    (e.location == q.location && kotlin.math.abs(e.timeMillis - q.timeMillis) < 60_000)
            }
            if (!isDup) deduped.add(q)
        }
        val list = deduped.sortedByDescending { it.timeMillis }
            .filter { it.eventId != strongestGlobal?.eventId }
            .take(3)
            .filter { q ->
                searchQuery.isEmpty() ||
                    cnPlace(q.location, short = false).contains(searchQuery) ||
                    q.location.contains(searchQuery, ignoreCase = true)
            }
        if (list.isEmpty()) {
            ll.addView(TextView(this).apply {
                text = if (quakes.isEmpty() && usgsHome.isEmpty()) "正在加载地震…" else "没有符合条件的地震"
                textSize = 13f
                setTextColor(tc2())
            })
            return
        }
        for (q in list) ll.addView(buildHomeLatestRow(q))
    }

    // v1.4.9：关键词搜索历史——在已加载的目录里找“最近一次”和“最大的一次”。
    // v1.6：全国地名搜索——关键词同时匹配内置城市列表（~57 个城市）；对匹配到的城市，
    // 另查 USGS 历史目录（1900 年至今，200km 内震级最大）显示“历史最大”，查不到则显示“暂无公开记录”。
    private fun renderSearchResult() {
        val box = findViewById<LinearLayout>(R.id.llSearchResult) ?: return
        box.removeAllViews()
        if (searchQuery.isEmpty()) {
            box.visibility = View.GONE
            return
        }
        val kw = searchQuery
        // 合并已加载的三个目录去重，按关键词匹配（中文地名或英文原名）
        val pool = LinkedHashMap<String, Pair<Quake, String>>()
        fun addAll(list: List<Quake>, src: String) {
            for (q in list) {
                val hit = cnPlace(q.location, short = false).contains(kw) ||
                    q.location.contains(kw, ignoreCase = true)
                if (hit) pool.putIfAbsent(q.eventId, q to src)
            }
        }
        addAll(catalogFull, "cenc")
        addAll(usgsHome, "usgs")
        addAll(mapQuakes, mapSource)
        val matches = pool.values.toList()
        // 内置城市列表：关键词是某个城市名（或包含城市名）时认作该地
        val city = CityData.cities.firstOrNull { it.name.contains(kw) || kw.contains(it.name) }
        box.visibility = View.VISIBLE
        if (matches.isEmpty() && city == null) {
            box.addView(TextView(this).apply {
                text = "“$kw”：当前已加载的目录里没有匹配的地震，换个关键词试试。"
                textSize = 13f
                setTextColor(tc2())
                setPadding(dp(4), dp(8), dp(4), dp(8))
            })
            return
        }
        box.addView(TextView(this).apply {
            text = "“$kw”的搜索结果（已加载目录内）"
            textSize = 14f
            setTypeface(null, android.graphics.Typeface.BOLD)
            setTextColor(tc1())
            setPadding(dp(4), dp(4), dp(4), dp(4))
        })
        val latest = matches.maxByOrNull { it.first.timeMillis }
        val largest = matches.maxByOrNull { it.first.magnitude }
        // 最近一次
        latest?.let { (q, src) ->
            box.addView(searchResultRow("最近一次", q, src))
        }
        // 最大的一次（与最近一次是同一场时只显示一次）
        largest?.let { (q, src) ->
            if (q.eventId != latest?.first?.eventId) {
                box.addView(searchResultRow("最大的一次", q, src))
            }
        }
        if (matches.isEmpty()) {
            box.addView(TextView(this).apply {
                text = "已加载目录里暂无“$kw”附近的地震。"
                textSize = 13f
                setTextColor(tc2())
                setPadding(dp(4), dp(8), dp(4), dp(8))
            })
        }
        // 历史最大：对匹配到的城市查 USGS 历史目录（1900 年至今，200km 内震级最大）
        if (city != null) {
            val histRow = TextView(this).apply {
                textSize = 13f
                setTextColor(tc2())
                setPadding(dp(4), dp(8), dp(4), dp(8))
            }
            if (searchHistCache.containsKey(kw)) {
                val hist = searchHistCache[kw]
                if (hist == null) {
                    histRow.text = "历史最大 · 暂无公开记录"
                } else {
                    histRow.text = histRowText(hist)
                    histRow.setOnClickListener { showQuakeDetailDialog(hist, "usgs") }
                }
            } else {
                histRow.text = "历史最大 · 正在查询 ${city.name} 附近 200 公里内的历史地震…"
                if (!searchHistInflight.contains(kw)) {
                    searchHistInflight.add(kw)
                    queryPlaceHistory(city, kw, histRow)
                }
            }
            box.addView(histRow)
        }
    }

    /** “历史最大”行文案：震级 · 地点 · 日期。 */
    private fun histRowText(hist: Quake): String {
        val date = SimpleDateFormat("yyyy-MM-dd", Locale.CHINA).apply { timeZone = beijing }
            .format(Date(hist.timeMillis))
        return "历史最大 · ${hist.magnitude}级 · ${cnPlace(hist.location, short = false)} · $date"
    }

    /** 查某城市 200km 内历史最大地震（USGS 1900 年至今，按震级排第一条）。只更新当前关键词对应的行；无记录也缓存。 */
    private fun queryPlaceHistory(city: City, keyword: String, row: TextView) {
        val today = SimpleDateFormat("yyyy-MM-dd", Locale.CHINA).apply { timeZone = beijing }
            .format(Date(System.currentTimeMillis()))
        val url = "https://earthquake.usgs.gov/fdsnws/event/1/query?format=geojson" +
            "&latitude=${city.lat}&longitude=${city.lon}" +
            "&maxradiuskm=200&starttime=1900-01-01&endtime=$today" +
            "&orderby=magnitude&limit=1"
        client.newCall(Request.Builder().url(url).build()).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                searchHistInflight.remove(keyword)
                runOnUiThread {
                    if (searchQuery == keyword) {
                        row.text = "历史最大 · 查询失败（网络异常），可稍后重试"
                    }
                }
            }

            override fun onResponse(call: Call, response: Response) {
                searchHistInflight.remove(keyword)
                val body = response.body?.string() ?: ""
                val hist = parseUsgsGeoJson(body).firstOrNull()
                // 缓存（无记录也缓存，避免每次按键都重查）
                if (searchHistCache.size > 20) searchHistCache.remove(searchHistCache.keys.first())
                searchHistCache[keyword] = hist
                runOnUiThread {
                    if (searchQuery != keyword) return@runOnUiThread
                    if (hist == null) {
                        row.text = "历史最大 · 暂无公开记录"
                        return@runOnUiThread
                    }
                    row.text = histRowText(hist)
                    row.setOnClickListener { showQuakeDetailDialog(hist, "usgs") }
                }
            }
        })
    }

    private fun searchResultRow(label: String, q: Quake, src: String): View {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            // v1.6.2：深色毛玻璃卡片（与“最新地震”行一致）
            setBackgroundResource(R.drawable.glass_dark)
            setPadding(dp(12), dp(10), dp(12), dp(10))
            elevation = dp(8).toFloat()
            val lp = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
            lp.topMargin = dp(8)
            layoutParams = lp
        }
        row.addView(TextView(this).apply {
            text = label
            textSize = 12f
            setTypeface(null, android.graphics.Typeface.BOLD)
            setTextColor(0xFF2E7A1E.toInt())
            val lp = LinearLayout.LayoutParams(dp(64), LinearLayout.LayoutParams.WRAP_CONTENT)
            layoutParams = lp
        })
        row.addView(TextView(this).apply {
            text = "${q.magnitude}"
            textSize = 15f
            setTypeface(null, android.graphics.Typeface.BOLD)
            setTextColor(magColor(q.magnitude))
            val lp = LinearLayout.LayoutParams(dp(44), LinearLayout.LayoutParams.WRAP_CONTENT)
            layoutParams = lp
        })
        val mid = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            val lp = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            layoutParams = lp
        }
        mid.addView(TextView(this).apply {
            text = q.location
            textSize = 14f
            setTextColor(0xFFFFFFFF.toInt())
        })
        mid.addView(TextView(this).apply {
            text = SimpleDateFormat("MM-dd HH:mm", Locale.CHINA).apply {
                timeZone = beijing
            }.format(Date(q.timeMillis)) +
                (q.depthKm?.let { " · 深度${it.toInt()}千米" } ?: "")
            textSize = 12f
            setTextColor(0xFFB9CBB4.toInt())
        })
        row.addView(mid)
        row.addView(TextView(this).apply {
            text = "›"
            textSize = 20f
            setTextColor(0xFFB9CBB4.toInt())
        })
        row.setOnClickListener { showQuakeDetailDialog(q, src) }
        pressable(row)
        return row
    }

    private fun buildHomeLatestRow(q: Quake): View {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            // v1.6.2：深色毛玻璃卡片
            setBackgroundResource(R.drawable.glass_dark)
            setPadding(dp(10), dp(10), dp(10), dp(10))
            elevation = dp(8).toFloat()
            val lp = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
            )
            lp.bottomMargin = dp(8)
            layoutParams = lp
        }
        row.addView(TextView(this).apply {
            text = "${q.magnitude}"
            textSize = 14f
            setTypeface(null, Typeface.BOLD)
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            val bg = ContextCompat.getDrawable(this@MainActivity, R.drawable.mag_circle)?.mutate() as? GradientDrawable
            bg?.setColor(magColor(q.magnitude))
            background = bg
            layoutParams = LinearLayout.LayoutParams(dp(44), dp(44))
        })
        val middle = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            val lp = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            lp.marginStart = dp(10)
            layoutParams = lp
        }
        middle.addView(TextView(this).apply {
            text = cnPlace(q.location, short = false)
            textSize = 14f
            setTypeface(null, Typeface.BOLD)
            setTextColor(0xFFFFFFFF.toInt())
            maxLines = 1
            ellipsize = android.text.TextUtils.TruncateAt.END
        })
        val timeText = SimpleDateFormat("MM-dd HH:mm", Locale.CHINA).apply { timeZone = beijing }
            .format(Date(q.timeMillis))
        val distText = if (userLat != 0.0 || userLon != 0.0) {
            " · 距你约${fmtDistKm(QuakeMath.distanceKm(userLat, userLon, q.latitude, q.longitude))}km"
        } else ""
        // v1.6.1：EEW 推送的地震在行里标出来源与第几报（如“四川地震局 第2报”）
        val srcText = if (q.reportNum > 0) {
            " · ${q.source} 第${q.reportNum}报"
        } else if (q.source == "四川地震局") {
            " · 四川地震局"
        } else ""
        middle.addView(TextView(this).apply {
            text = "$timeText$distText$srcText"
            textSize = 12f
            setTextColor(0xFFB9CBB4.toInt())
        })
        row.addView(middle)
        if (userLat != 0.0 || userLon != 0.0) {
            val local = QuakeMath.localIntensity(q, userLat, userLon)
            if (local != null) {
                // v1.6.2：深玻璃上用实底 pill + 白字；无感深绿
                val pill = TextView(this).apply {
                    text = QuakeMath.feelingText(local)
                    textSize = 12f
                    setTextColor(Color.WHITE)
                    setPadding(dp(8), dp(3), dp(8), dp(3))
                    background = GradientDrawable().apply {
                        shape = GradientDrawable.RECTANGLE
                        cornerRadius = dp(11).toFloat()
                        setColor(feelPillColor(local))
                    }
                }
                pill.layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT
                ).apply { marginEnd = dp(6) }
                row.addView(pill)
            }
        }
        row.setOnClickListener { showQuakeDetailDialog(q, "usgs") }
        return row
    }

    /** “地震活动”折线图：CENC 目录（最新 50 条）按天统计近 7 天每天的地震次数。 */
    private fun renderWaveform() {
        val source = if (catalogFull.isNotEmpty()) catalogFull else quakes
        val chart = findViewById<WaveformChartView>(R.id.waveChart)
        if (source.isEmpty()) {
            chart.setData(emptyList<WaveformChartView.DayPoint>())
            findViewById<TextView>(R.id.tvWaveCountVal).text = "-"
            findViewById<TextView>(R.id.tvWaveMax7Val).text = "-"
            findViewById<TextView>(R.id.tvWaveTotalVal).text = "-"
            return
        }
        val now = System.currentTimeMillis()
        val dayFmt = SimpleDateFormat("MM-dd", Locale.CHINA).apply { timeZone = beijing }
        // 目录最早一天：只画有数据覆盖的天数，避免把截断的天画成 0
        val earliestDay = source.minOfOrNull { it.timeMillis }?.let { dayStart(it) } ?: return
        val todayStart = dayStart(now)
        val firstDay = maxOf(earliestDay, todayStart - 6 * 24 * 3600_000L)
        val days = mutableListOf<WaveformChartView.DayPoint>()
        var d = firstDay
        while (d <= todayStart) {
            val c = source.count { it.timeMillis in d until d + 24 * 3600_000L }
            days.add(WaveformChartView.DayPoint(dayFmt.format(Date(d)), c))
            d += 24 * 3600_000L
        }
        chart.setData(days)
        val last24 = source.filter { it.timeMillis >= now - 24 * 3600_000L }
        val last7 = source.filter { it.timeMillis >= now - 7 * 24 * 3600_000L }
        findViewById<TextView>(R.id.tvWaveCountVal).text = last24.size.toString()
        findViewById<TextView>(R.id.tvWaveMax7Val).text =
            last7.maxByOrNull { it.magnitude }?.let { "${it.magnitude}级" } ?: "-"
        findViewById<TextView>(R.id.tvWaveTotalVal).text = "${last7.size}次"
    }

    private fun dayStart(timeMillis: Long): Long {
        val cal = Calendar.getInstance(beijing).apply {
            timeInMillis = timeMillis
            set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }
        return cal.timeInMillis
    }

    /** USGS 英文地名 → 中文（短名用于地图标记，长名用于列表/红卡）；匹配不到时返回原文。 */
    private fun cnPlace(place: String, short: Boolean): String {
        val p = place.lowercase(Locale.US)
        for ((key, s, f) in PLACE_CN) {
            if (p.contains(key)) return if (short) s else f
        }
        return place
    }

    private val PLACE_CN = listOf(
        Triple("fiji", "斐济", "斐济群岛地区"),
        Triple("tonga", "汤加", "汤加"),
        Triple("vanuatu", "瓦努阿图", "瓦努阿图"),
        Triple("samoa", "萨摩亚", "萨摩亚"),
        Triple("solomon", "所罗门", "所罗门群岛"),
        Triple("papua new guinea", "巴布亚", "巴布亚新几内亚"),
        Triple("new britain", "新不列颠", "新不列颠"),
        Triple("new zealand", "新西兰", "新西兰"),
        Triple("indonesia", "印尼", "印度尼西亚"),
        Triple("sumatra", "苏门答腊", "苏门答腊"),
        Triple("java", "爪哇", "爪哇"),
        Triple("sulawesi", "苏拉威西", "苏拉威西"),
        Triple("banda sea", "班达海", "班达海"),
        Triple("philippines", "菲律宾", "菲律宾"),
        Triple("mindanao", "棉兰老", "棉兰老"),
        Triple("luzon", "吕宋", "吕宋"),
        Triple("japan", "日本", "日本"),
        Triple("ryukyu", "琉球", "琉球群岛"),
        Triple("izu", "伊豆", "伊豆群岛"),
        Triple("taiwan", "台湾", "台湾"),
        Triple("kuril", "千岛", "千岛群岛"),
        Triple("kamchatka", "堪察加", "堪察加"),
        Triple("sea of okhotsk", "鄂霍次克海", "鄂霍次克海"),
        Triple("mariana", "马里亚纳", "马里亚纳群岛"),
        Triple("kermadec", "克马德克", "克马德克群岛"),
        Triple("myanmar", "缅甸", "缅甸"),
        Triple("india", "印度", "印度"),
        Triple("nepal", "尼泊尔", "尼泊尔"),
        Triple("pakistan", "巴基斯坦", "巴基斯坦"),
        Triple("iran", "伊朗", "伊朗"),
        Triple("turkey", "土耳其", "土耳其"),
        Triple("greece", "希腊", "希腊"),
        Triple("italy", "意大利", "意大利"),
        Triple("iceland", "冰岛", "冰岛"),
        Triple("turpan", "托克逊", "新疆吐鲁番市托克逊县"),
        Triple("xinjiang", "新疆", "新疆"),
        Triple("tibet", "西藏", "西藏"),
        Triple("yushu", "玉树", "青海玉树州杂多县"),
        Triple("yibin", "宜宾", "四川宜宾市高县"),
        Triple("sichuan", "四川", "四川"),
        Triple("chile", "智利", "智利"),
        Triple("peru", "秘鲁", "秘鲁"),
        Triple("ecuador", "厄瓜多尔", "厄瓜多尔"),
        Triple("colombia", "哥伦比亚", "哥伦比亚"),
        Triple("argentina", "阿根廷", "阿根廷"),
        Triple("mexico", "墨西哥", "墨西哥"),
        Triple("costa rica", "哥斯达黎加", "哥斯达黎加"),
        Triple("panama", "巴拿马", "巴拿马"),
        Triple("guatemala", "危地马拉", "危地马拉"),
        Triple("haiti", "海地", "海地"),
        Triple("cuba", "古巴", "古巴"),
        Triple("puerto rico", "波多黎各", "波多黎各"),
        Triple("dominican", "多米尼加", "多米尼加"),
        Triple("venezuela", "委内瑞拉", "委内瑞拉"),
        Triple("california", "加州", "美国加州"),
        Triple("alaska", "阿拉斯加", "美国阿拉斯加"),
        Triple("hawaii", "夏威夷", "美国夏威夷"),
        Triple("nevada", "内华达", "美国内华达"),
        Triple("utah", "犹他", "美国犹他"),
        Triple("oregon", "俄勒冈", "美国俄勒冈"),
        Triple("washington", "华盛顿", "美国华盛顿"),
        Triple("idaho", "爱达荷", "美国爱达荷"),
        Triple("montana", "蒙大拿", "美国蒙大拿"),
        Triple("wyoming", "怀俄明", "美国怀俄明"),
        Triple("arizona", "亚利桑那", "美国亚利桑那"),
        Triple("new mexico", "新墨西哥", "美国新墨西哥"),
        Triple("texas", "得克萨斯", "美国得克萨斯"),
        Triple("oklahoma", "俄克拉何马", "美国俄克拉何马"),
        Triple("tanzania", "坦桑尼亚", "坦桑尼亚"),
        Triple("kenya", "肯尼亚", "肯尼亚"),
        Triple("morocco", "摩洛哥", "摩洛哥"),
        Triple("algeria", "阿尔及利亚", "阿尔及利亚"),
        Triple("egypt", "埃及", "埃及"),
        Triple("south africa", "南非", "南非"),
        Triple("madagascar", "马达加斯加", "马达加斯加"),
        Triple("australia", "澳大利亚", "澳大利亚"),
        Triple("new caledonia", "新喀里多尼亚", "新喀里多尼亚"),
        Triple("reunion", "留尼汪", "留尼汪"),
        Triple("mauritius", "毛里求斯", "毛里求斯"),
        Triple("azores", "亚速尔", "亚速尔群岛"),
        Triple("canary", "加那利", "加那利群岛"),
        Triple("cyprus", "塞浦路斯", "塞浦路斯"),
        Triple("crete", "克里特", "克里特"),
        Triple("romania", "罗马尼亚", "罗马尼亚"),
        Triple("bulgaria", "保加利亚", "保加利亚"),
        Triple("croatia", "克罗地亚", "克罗地亚"),
        Triple("albania", "阿尔巴尼亚", "阿尔巴尼亚"),
        Triple("serbia", "塞尔维亚", "塞尔维亚"),
        Triple("georgia", "格鲁吉亚", "格鲁吉亚"),
        Triple("armenia", "亚美尼亚", "亚美尼亚"),
        Triple("azerbaijan", "阿塞拜疆", "阿塞拜疆"),
        Triple("kazakhstan", "哈萨克斯坦", "哈萨克斯坦"),
        Triple("uzbekistan", "乌兹别克斯坦", "乌兹别克斯坦"),
        Triple("kyrgyzstan", "吉尔吉斯斯坦", "吉尔吉斯斯坦"),
        Triple("tajikistan", "塔吉克斯坦", "塔吉克斯坦"),
        Triple("mongolia", "蒙古", "蒙古"),
        Triple("bhutan", "不丹", "不丹"),
        Triple("bangladesh", "孟加拉国", "孟加拉国"),
        Triple("sri lanka", "斯里兰卡", "斯里兰卡"),
        Triple("thailand", "泰国", "泰国"),
        Triple("vietnam", "越南", "越南"),
        Triple("laos", "老挝", "老挝"),
        Triple("cambodia", "柬埔寨", "柬埔寨"),
        Triple("malaysia", "马来西亚", "马来西亚"),
        Triple("singapore", "新加坡", "新加坡"),
    )

    // ---------------- 毛玻璃详情弹窗（速报 / 地图 / AI 分析 / 震感记录） ----------------

    /**
     * 点列表/海报卡/离我最近/聚光卡/地图标记后打开。
     * source: "cenc" 中国地震台网速报 / "usgs" / "emsc" 全球地震。
     * 弹窗内容可滚动，文字多时自动滚动查看，不撑破弹窗。
     */
    private fun showQuakeDetailDialog(q: Quake, source: String) {
        // v1.4.9 小巧高级卡片：实色卡片（不用毛玻璃）、窄框、内容折叠，默认只露关键信息。
        val dialog = Dialog(this)
        val scroll = ScrollView(this)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundResource(if (dark) R.drawable.dialog_card else R.drawable.dialog_card_light)
            setPadding(dp(16), dp(16), dp(16), dp(16))
        }
        scroll.addView(root)

        // 标题行：震级圆 + 地点/时间 + 右上角 X 关闭
        val titleRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        titleRow.addView(TextView(this).apply {
            text = "${q.magnitude}"
            textSize = 17f
            setTypeface(null, android.graphics.Typeface.BOLD)
            setTextColor(0xFFFFFFFF.toInt())
            gravity = Gravity.CENTER
            val bg = ContextCompat.getDrawable(
                this@MainActivity, R.drawable.mag_circle
            )?.mutate() as? GradientDrawable
            bg?.setColor(magColor(q.magnitude))
            background = bg
            val lp = LinearLayout.LayoutParams(dp(48), dp(48))
            layoutParams = lp
        })
        val titleMid = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            val lp = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            lp.marginStart = dp(10)
            layoutParams = lp
        }
        titleMid.addView(TextView(this).apply {
            text = q.location
            textSize = 17f
            setTypeface(null, android.graphics.Typeface.BOLD)
            setTextColor(tc1())
        })
        titleMid.addView(TextView(this).apply {
            text = SimpleDateFormat("yyyy年MM月dd日 HH:mm", Locale.CHINA).apply {
                timeZone = beijing
            }.format(Date(q.timeMillis)) +
                (q.depthKm?.let { " · 深度${it.toInt()}千米" } ?: "")
            textSize = 12f
            setTextColor(tc2())
        })
        // v1.6.1：数据来源与第几报（EEW 推送的地震才有第几报）
        if (q.reportNum > 0 || q.source == "四川地震局") {
            titleMid.addView(TextView(this).apply {
                text = "来源：${q.source}" +
                    (if (q.reportNum > 0) " · 第${q.reportNum}报" else "")
                textSize = 12f
                setTextColor(tc2())
            })
        }
        titleRow.addView(titleMid)
        titleRow.addView(TextView(this).apply {
            text = "✕"
            textSize = 18f
            setTextColor(tc2())
            gravity = Gravity.CENTER
            val lp = LinearLayout.LayoutParams(dp(32), dp(32))
            layoutParams = lp
            setOnClickListener { dialog.dismiss() }
        })
        root.addView(titleRow)

        // 双烈度芯片：震中烈度 / 我所在地预计烈度
        val chips = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            val lp = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
            lp.topMargin = dp(10)
            layoutParams = lp
        }
        val epiText = q.intensity?.let { "震中烈度 ${it}度" } ?: "震中烈度 未公布"
        val chipEpi = makeChip(epiText, ContextCompat.getColor(this, R.color.mag_severe))
        chipEpi.layoutParams = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.WRAP_CONTENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply { marginEnd = dp(8) }
        chips.addView(chipEpi)
        val local = QuakeMath.localIntensity(q, userLat, userLon)
        if (local != null) {
            val dist = QuakeMath.distanceKm(userLat, userLon, q.latitude, q.longitude)
            chips.addView(
                makeChip(
                    "我所在地 ${local}度 · ${QuakeMath.feelingText(local)}（约${dist.toInt()}公里）",
                    feelColor(local)
                )
            )
        }
        root.addView(chips)

        // 速报文案（精简）
        root.addView(TextView(this).apply {
            text = if (source == "cenc") flashReportText(q) else flashReportTextGlobal(q, source)
            textSize = 13f
            setTextColor(tc1())
            val lp = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
            lp.topMargin = dp(10)
            layoutParams = lp
        })

        // 操作行：关闭（幽灵）+ 查看震中（荧光绿主按钮）
        val btnRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            val lp = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
            lp.topMargin = dp(14)
            layoutParams = lp
        }
        val btnClose = Button(this).apply {
            text = "关闭"
            textSize = 14f
            setTextColor(tc1())
            setBackgroundResource(R.drawable.btn_glass_gray)
            val lp = LinearLayout.LayoutParams(0, dp(42), 1f)
            lp.marginEnd = dp(8)
            layoutParams = lp
            setOnClickListener { dialog.dismiss() }
        }
        val btnMap = Button(this).apply {
            text = "在地图中查看震中"
            textSize = 14f
            setTypeface(null, android.graphics.Typeface.BOLD)
            // v1.6.2：主按钮也用深色毛玻璃（白字加粗），与弹窗内其他按钮统一
            setTextColor(Color.WHITE)
            setBackgroundResource(R.drawable.btn_glass_gray)
            val lp = LinearLayout.LayoutParams(0, dp(42), 1.6f)
            layoutParams = lp
            setOnClickListener {
                val url = "https://uri.amap.com/marker?position=${q.longitude},${q.latitude}" +
                    "&name=" + URLEncoder.encode(q.location, "UTF-8") +
                    "&coordinate=gaode"
                startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
            }
        }
        btnRow.addView(btnClose)
        btnRow.addView(btnMap)
        root.addView(btnRow)
        pressable(btnClose)
        pressable(btnMap)

        // AI 分析区：默认折叠，点标题展开（弹窗默认小巧，内容再多也不撑大）
        val aiBody = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            visibility = View.GONE
        }
        val tvAiToggle = TextView(this).apply {
            text = "展开 ▼"
            textSize = 13f
            setTextColor(0xFF93E62A.toInt())
        }
        val aiHead = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            val lp = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
            lp.topMargin = dp(14)
            layoutParams = lp
            setOnClickListener {
                val show = aiBody.visibility != View.VISIBLE
                aiBody.visibility = if (show) View.VISIBLE else View.GONE
                tvAiToggle.text = if (show) "收起 ▲" else "展开 ▼"
            }
        }
        aiHead.addView(TextView(this).apply {
            text = "AI 分析"
            textSize = 15f
            setTypeface(null, android.graphics.Typeface.BOLD)
            setTextColor(tc1())
            val lp = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            layoutParams = lp
        })
        aiHead.addView(tvAiToggle)
        root.addView(aiHead)
        val tvAiLocal = TextView(this).apply {
            text = ""
            textSize = 13f
            setTextColor(tc2())
            aiBody.addView(this)
        }
        val tvAiHistory = TextView(this).apply {
            text = "正在查询历史地震…"
            textSize = 13f
            setTextColor(tc2())
            val lp = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
            lp.topMargin = dp(8)
            layoutParams = lp
            aiBody.addView(this)
        }
        val tvAiCasualty = TextView(this).apply {
            text = "正在查询伤亡数据…"
            textSize = 13f
            setTextColor(tc2())
            val lp = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
            lp.topMargin = dp(8)
            layoutParams = lp
            aiBody.addView(this)
        }
        root.addView(aiBody)

        // 震感记录（仅中国速报）
        if (source == "cenc") {
            val feltRow = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                val lp = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                )
                lp.topMargin = dp(12)
                layoutParams = lp
            }
            feltRow.addView(TextView(this).apply {
                text = "你感受到震动了吗？"
                textSize = 13f
                setTextColor(tc1())
                val lp = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                layoutParams = lp
            })
            val tvFeltStatus = TextView(this).apply {
                textSize = 12f
                setTextColor(tc2())
                feltRow.addView(this)
            }
            val updateFelt = {
                val level = LocalStore.feltLevel(this, q.eventId)
                tvFeltStatus.text = when (level) {
                    0 -> "已记录：无感"
                    1 -> "已记录：轻微震感"
                    2 -> "已记录：强烈震感"
                    else -> ""
                }
            }
            updateFelt()
            // v1.6.2：震感按钮改用深色毛玻璃（白字），点击行为不变
            for ((label, level) in listOf("无感" to 0, "轻微" to 1, "强烈" to 2)) {
                feltRow.addView(Button(this).apply {
                    text = label
                    textSize = 13f
                    setTextColor(Color.WHITE)
                    setBackgroundResource(R.drawable.btn_glass_gray)
                    val d = resources.displayMetrics.density
                    setPadding((14 * d).toInt(), (6 * d).toInt(), (14 * d).toInt(), (6 * d).toInt())
                    minHeight = (36 * d).toInt()
                    layoutParams = LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.WRAP_CONTENT,
                        LinearLayout.LayoutParams.WRAP_CONTENT
                    ).apply { marginEnd = (6 * d).toInt() }
                    setOnClickListener {
                        LocalStore.saveFelt(this@MainActivity, q.eventId, level, q.location, q.magnitude)
                        updateFelt()
                        Toast.makeText(this@MainActivity, "震感已记录", Toast.LENGTH_SHORT).show()
                    }
                })
            }
            root.addView(feltRow)
        }

        dialog.setContentView(scroll)
        dialog.window?.setBackgroundDrawableResource(android.R.color.transparent)
        val dm = resources.displayMetrics
        // v1.4.9：窄框 + 高度自适应（不再定 80% 屏高），默认小巧。
        dialog.window?.setLayout(dm.widthPixels - dp(56), WindowManager.LayoutParams.WRAP_CONTENT)
        dialog.show()
        // v1.6.2：弹窗关闭后地图飞回原始视图（仅当刚才是由“点标记飞过去”放大的；其他入口打开时不做任何事）
        dialog.setOnDismissListener { restoreHomeMapZoom() }
        loadAi(q, tvAiLocal, tvAiHistory, tvAiCasualty)
    }

    /** 台网速报标准格式文案（由目录真实字段拼成，行内展示，不跳微博）。 */
    private fun flashReportText(q: Quake): String {
        val timeText = SimpleDateFormat("MM月dd日HH时mm分", Locale.CHINA).apply {
            timeZone = beijing
        }.format(Date(q.timeMillis))
        val depthText = q.depthKm?.let { "，震源深度${it.toInt()}千米" } ?: ""
        // v1.6.1：四川局来源的地震，速报文案写四川局，不写中国地震台网
        val org = if (q.source == "四川地震局") "四川地震局" else "中国地震台网"
        val suffix = if (q.source == "四川地震局") "" else "（@中国地震台网速报）"
        return "$org 正式测定：$timeText，${q.location}发生${q.magnitude}级地震$depthText。$suffix"
    }

    /** 全球地震速报文案（USGS / EMSC 真实字段拼成）。 */
    private fun flashReportTextGlobal(q: Quake, source: String): String {
        val timeText = SimpleDateFormat("MM月dd日HH时mm分", Locale.CHINA).apply {
            timeZone = beijing
        }.format(Date(q.timeMillis))
        val depthText = q.depthKm?.let { "，震源深度${it.toInt()}千米" } ?: ""
        val org = if (source == "emsc") "欧洲地中海地震中心（EMSC）" else "美国地质调查局（USGS）"
        return "$org 测定：$timeText，${q.location}发生${q.magnitude}级地震$depthText。"
    }

    private fun loadAi(
        q: Quake,
        tvLocal: TextView,
        tvHistory: TextView,
        tvCasualty: TextView
    ) {
        tvLocal.text = AiAnalysis.buildLocalAnalysis(q, userLat, userLon)
        AiAnalysis.load(this, q, userLat, userLon) { result ->
            runOnUiThread {
                // 在线模型返回后，分析文字会从本地规则版换成在线版
                tvLocal.text = result.localAnalysis
                tvHistory.text = when (result.historyState) {
                    AiAnalysis.STATE_OK -> result.historyText
                    AiAnalysis.STATE_NONE -> "历史最大地震：该区域公开目录内暂无记录"
                    AiAnalysis.STATE_FAILED -> result.historyText ?: "历史地震查询失败"
                    else -> "正在查询历史地震…"
                }
                tvCasualty.text = when (result.casualtyState) {
                    AiAnalysis.STATE_OK -> result.casualtyText
                    AiAnalysis.STATE_NONE -> "当时伤亡情况：暂无公开伤亡数据"
                    AiAnalysis.STATE_FAILED -> result.casualtyText ?: "伤亡数据查询失败"
                    else -> "正在查询伤亡数据…"
                }
            }
        }
    }

    // ---------------- 地震地图（全球，仅供查看，绝不触发预警） ----------------

    private fun setupMapPage() {
        findViewById<Button>(R.id.btnMapUsgs).setOnClickListener {
            if (mapSource != "usgs") {
                mapSource = "usgs"
                updateMapButtons()
                fetchMapData()
            }
        }
        findViewById<Button>(R.id.btnMapEmsc).setOnClickListener {
            if (mapSource != "emsc") {
                mapSource = "emsc"
                updateMapButtons()
                fetchMapData()
            }
        }
        findViewById<Button>(R.id.btnMapDay).setOnClickListener {
            if (mapRange != "day") {
                mapRange = "day"
                updateMapButtons()
                fetchMapData()
            }
        }
        findViewById<Button>(R.id.btnMapWeek).setOnClickListener {
            if (mapRange != "week") {
                mapRange = "week"
                updateMapButtons()
                fetchMapData()
            }
        }
        findViewById<Button>(R.id.btnMapDetailAi).setOnClickListener {
            selectedMapQuake?.let { showQuakeDetailDialog(it, selectedMapQuakeSource) }
        }
    }

    private fun updateMapButtons() {
        findViewById<Button>(R.id.btnMapUsgs).apply {
            setBackgroundResource(if (mapSource == "usgs") R.drawable.btn_green else cardBg())
            setTextColor(if (mapSource == "usgs") 0xFF0B0F0B.toInt() else tc1())
        }
        findViewById<Button>(R.id.btnMapEmsc).apply {
            setBackgroundResource(if (mapSource == "emsc") R.drawable.btn_green else cardBg())
            setTextColor(if (mapSource == "emsc") 0xFF0B0F0B.toInt() else tc1())
        }
        findViewById<Button>(R.id.btnMapDay).apply {
            setBackgroundResource(if (mapRange == "day") R.drawable.btn_green else cardBg())
            setTextColor(if (mapRange == "day") 0xFF0B0F0B.toInt() else tc1())
        }
        findViewById<Button>(R.id.btnMapWeek).apply {
            setBackgroundResource(if (mapRange == "week") R.drawable.btn_green else cardBg())
            setTextColor(if (mapRange == "week") 0xFF0B0F0B.toInt() else tc1())
        }
    }

    private fun fetchMapData() {
        val url = when (mapSource) {
            "emsc" -> "https://www.seismicportal.eu/fdsnws/event/1/query" +
                "?format=json&limit=100&minmag=4.0"
            else -> if (mapRange == "week") {
                "https://earthquake.usgs.gov/earthquakes/feed/v1.0/summary/4.5_week.geojson"
            } else {
                "https://earthquake.usgs.gov/earthquakes/feed/v1.0/summary/2.5_day.geojson"
            }
        }
        findViewById<TextView>(R.id.tvMapStatus).text = "正在加载全球地震…"
        client.newCall(Request.Builder().url(url).build()).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                runOnUiThread {
                    findViewById<TextView>(R.id.tvMapStatus).text =
                        "全球地震加载失败（${e.message}），请检查网络后重试"
                    Toast.makeText(this@MainActivity, "全球地震加载失败", Toast.LENGTH_SHORT).show()
                }
            }

            override fun onResponse(call: Call, response: Response) {
                val body = response.body?.string() ?: ""
                val list = if (mapSource == "emsc") parseEmscJson(body) else parseUsgsGeoJson(body)
                runOnUiThread {
                    mapQuakes = list.sortedByDescending { it.timeMillis }
                    mapLoadedAt = System.currentTimeMillis()
                    val srcName = if (mapSource == "emsc") "EMSC 欧洲地中海地震中心" else "USGS 美国地质调查局"
                    findViewById<TextView>(R.id.tvMapStatus).text =
                        "数据来源：$srcName · 共 ${mapQuakes.size} 场 · " +
                            SimpleDateFormat("HH:mm:ss", Locale.CHINA).apply {
                                timeZone = beijing
                            }.format(Date(mapLoadedAt))
                    findViewById<LinearLayout>(R.id.llMapDetail).visibility = View.GONE
                    selectedMapQuake = null
                    renderMapMarkers()
                    renderMapRecentList()
                }
            }
        })
    }

    /** USGS GeoJSON：features[].properties.mag/place/time，geometry.coordinates=[lon, lat, depth]。 */
    private fun parseUsgsGeoJson(body: String): List<Quake> {
        val out = mutableListOf<Quake>()
        try {
            val features = JSONObject(body).optJSONArray("features") ?: return out
            for (i in 0 until features.length()) {
                val f = features.optJSONObject(i) ?: continue
                val props = f.optJSONObject("properties") ?: continue
                val coords = f.optJSONObject("geometry")?.optJSONArray("coordinates") ?: continue
                val mag = props.optDouble("mag", Double.NaN)
                if (mag.isNaN()) continue
                val depth = coords.optDouble(2, Double.NaN).takeIf { !it.isNaN() }
                val id = "usgs-" + f.optString("id", "${props.optLong("time", 0)}")
                out.add(
                    Quake(
                        id, props.optLong("time", 0L),
                        props.optString("place", "未知地点"),
                        mag, depth,
                        coords.optDouble(1, 0.0), coords.optDouble(0, 0.0), null,
                        source = "USGS"
                    )
                )
            }
        } catch (_: Exception) {
        }
        return out
    }

    /** EMSC FDSNWS JSON：features[].properties.mag/time/lat/lon/depth/flynn_region。 */
    private fun parseEmscJson(body: String): List<Quake> {
        val out = mutableListOf<Quake>()
        try {
            val features = JSONObject(body).optJSONArray("features") ?: return out
            val timeFmt = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss", Locale.US).apply {
                timeZone = TimeZone.getTimeZone("UTC")
            }
            for (i in 0 until features.length()) {
                val f = features.optJSONObject(i) ?: continue
                val props = f.optJSONObject("properties") ?: continue
                val mag = props.optDouble("mag", Double.NaN)
                if (mag.isNaN()) continue
                val timeStr = props.optString("time", "").substringBefore('.')
                val time = try {
                    timeFmt.parse(timeStr)?.time ?: 0L
                } catch (_: Exception) {
                    0L
                }
                val lat = props.optDouble("lat", Double.NaN)
                val lon = props.optDouble("lon", Double.NaN)
                if (lat.isNaN() || lon.isNaN()) continue
                val depth = props.optDouble("depth", Double.NaN).takeIf { !it.isNaN() }
                val place = props.optString("flynn_region", "")
                    .ifEmpty { props.optString("place", "未知地点") }
                out.add(Quake("emsc-$time-$lat-$lon", time, place, mag, depth, lat, lon, null, source = "EMSC"))
            }
        } catch (_: Exception) {
        }
        return out
    }

    /** 世界地图按真实经纬度打点（等距圆柱投影：x%=(lon+180)/360，y%=(90-lat)/180）。 */
    private fun renderMapMarkers() {
        val layer = findViewById<FrameLayout>(R.id.worldMarkerLayer)
        layer.post {
            layer.removeAllViews()
            val w = layer.width
            val h = layer.height
            if (w == 0 || h == 0) return@post
            val shown = mapQuakes.sortedByDescending { it.magnitude }.take(80)
            for (q in shown) {
                val xPct = (q.longitude + 180) / 360.0
                val yPct = (90 - q.latitude) / 180.0
                if (xPct < 0 || xPct > 1 || yPct < 0 || yPct > 1) continue
                val size = (dp(10) + (q.magnitude * 1.2).toInt()).coerceAtMost(dp(22))
                val dot = View(this).apply {
                    background = GradientDrawable().apply {
                        shape = GradientDrawable.OVAL
                        setColor(magColor(q.magnitude))
                        setStroke(dp(1), 0xFFFFFFFF.toInt())
                    }
                    layoutParams = FrameLayout.LayoutParams(size, size).apply {
                        leftMargin = (w * xPct).toInt() - size / 2
                        topMargin = (h * yPct).toInt() - size / 2
                    }
                    setOnClickListener { selectMapQuake(q) }
                }
                layer.addView(dot)
            }
        }
    }

    // v1.4.9：地图下方“最近地震”列表（按时间取最近 6 场，点一行选中并看详情）。
    private fun renderMapRecentList() {
        val list = findViewById<LinearLayout>(R.id.llMapRecentList) ?: return
        list.removeAllViews()
        val recent = mapQuakes.sortedByDescending { it.timeMillis }.take(6)
        if (recent.isEmpty()) {
            list.addView(TextView(this).apply {
                text = "暂无数据，先切到首页看看，或点右上角刷新。"
                textSize = 13f
                setTextColor(tc2())
                setPadding(dp(4), dp(8), dp(4), dp(8))
            })
            return
        }
        for (q in recent) {
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setBackgroundResource(cardBg())
                setPadding(dp(12), dp(10), dp(12), dp(10))
                elevation = dp(8).toFloat()
                val lp = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                )
                lp.topMargin = dp(8)
                layoutParams = lp
            }
            row.addView(TextView(this).apply {
                text = "${q.magnitude}"
                textSize = 15f
                setTypeface(null, android.graphics.Typeface.BOLD)
                setTextColor(magColor(q.magnitude))
                val lp = LinearLayout.LayoutParams(dp(44), LinearLayout.LayoutParams.WRAP_CONTENT)
                layoutParams = lp
            })
            val mid = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                val lp = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                layoutParams = lp
            }
            mid.addView(TextView(this).apply {
                text = q.location
                textSize = 14f
                setTextColor(tc1())
            })
            mid.addView(TextView(this).apply {
                text = SimpleDateFormat("MM-dd HH:mm", Locale.CHINA).apply {
                    timeZone = beijing
                }.format(Date(q.timeMillis)) +
                    (q.depthKm?.let { " · 深度${it.toInt()}千米" } ?: "")
                textSize = 12f
                setTextColor(tc2())
            })
            row.addView(mid)
            row.addView(TextView(this).apply {
                text = "›"
                textSize = 20f
                setTextColor(tc2())
            })
            row.setOnClickListener {
                selectMapQuake(q)
                showQuakeDetailDialog(q, mapSource)
            }
            pressable(row)
            list.addView(row)
        }
    }

    private fun selectMapQuake(q: Quake) {
        selectedMapQuake = q
        selectedMapQuakeSource = mapSource
        findViewById<LinearLayout>(R.id.llMapDetail).visibility = View.VISIBLE
        findViewById<TextView>(R.id.tvMapDetailTitle).text = "${q.magnitude}级 · ${q.location}"
        val timeText = SimpleDateFormat("MM-dd HH:mm", Locale.CHINA).apply {
            timeZone = beijing
        }.format(Date(q.timeMillis))
        val depthText = q.depthKm?.let { " · 深度${it.toInt()}千米" } ?: ""
        val distText = if (userLat != 0.0 || userLon != 0.0) {
            " · 距你约${QuakeMath.distanceKm(userLat, userLon, q.latitude, q.longitude).toInt()}公里"
        } else ""
        findViewById<TextView>(R.id.tvMapDetailMeta).text = "$timeText$depthText$distText"
    }

    // ---------------- 数据分析（近 7 天 CENC 目录统计 + AI 总分析） ----------------

    private fun setupAnalysisPage() {
        findViewById<Button>(R.id.btnAnalysisAiRefresh).setOnClickListener {
            // 强制重新分析：清除当天缓存后重算
            analysisAiDay = ""
            renderAnalysis()
        }
    }

    /** 地区归一：取地名中第一个“市/县/州”之前（含）部分，如“四川宜宾市”。 */
    private fun regionKey(location: String): String {
        val idx = listOf(location.indexOf("市"), location.indexOf("县"), location.indexOf("州"))
            .filter { it > 0 }.minOrNull()
        return if (idx != null) location.substring(0, idx + 1) else location.take(8)
    }

    private fun renderAnalysis() {
        val now = System.currentTimeMillis()
        val last7 = quakes.filter { it.timeMillis >= now - 7 * 24 * 3600_000L }

        val stats = findViewById<LinearLayout>(R.id.llAnalysisStats)
        stats.removeAllViews()
        val max7 = last7.maxByOrNull { it.magnitude }
        val regions = last7.groupBy { regionKey(it.location) }
            .mapValues { it.value.size }
            .entries.sortedByDescending { it.value }
        val topRegion = regions.firstOrNull()
        stats.addView(buildStatRow("近7天地震数", "${last7.size} 场"))
        stats.addView(
            buildStatRow(
                "近7天最大震级",
                max7?.let { "${it.magnitude}级 · ${it.location}" } ?: "-"
            )
        )
        stats.addView(
            buildStatRow(
                "最活跃地区",
                topRegion?.let { "${it.key} · ${it.value} 场" } ?: "-"
            )
        )

        // 每日地震数
        val daily = findViewById<LinearLayout>(R.id.llDailyBars)
        daily.removeAllViews()
        val dayFmt = SimpleDateFormat("MM-dd", Locale.CHINA).apply { timeZone = beijing }
        val counts = (6 downTo 0).map { d ->
            val cal = Calendar.getInstance(beijing).apply {
                add(Calendar.DAY_OF_YEAR, -d)
                set(Calendar.HOUR_OF_DAY, 0)
                set(Calendar.MINUTE, 0)
                set(Calendar.SECOND, 0)
                set(Calendar.MILLISECOND, 0)
            }
            val start = cal.timeInMillis
            val end = start + 24 * 3600_000L
            val label = dayFmt.format(Date(start))
            val c = last7.count { it.timeMillis in start until end }
            label to c
        }
        // v1.6.2：每日地震数改用平滑曲线图（同款数据：折线 + 圆点 + 数值 + 面积渐变）
        daily.addView(buildChartCard(counts, ContextCompat.getColor(this, R.color.neon_green)))

        // 震级分布
        val mag = findViewById<LinearLayout>(R.id.llMagBars)
        mag.removeAllViews()
        val magCounts = listOf(
            "<3级" to last7.count { it.magnitude < 3.0 },
            "3–4级" to last7.count { it.magnitude >= 3.0 && it.magnitude < 4.0 },
            "4–5级" to last7.count { it.magnitude >= 4.0 && it.magnitude < 5.0 },
            "5–6级" to last7.count { it.magnitude >= 5.0 && it.magnitude < 6.0 },
            "6级以上" to last7.count { it.magnitude >= 6.0 }
        )
        // v1.6.2：震级分布改用平滑分布曲线（同款数据，橙色线）
        mag.addView(buildChartCard(magCounts, ContextCompat.getColor(this, R.color.mag_mid)))

        // 最活跃地区
        val reg = findViewById<LinearLayout>(R.id.llRegionBars)
        reg.removeAllViews()
        val topRegions = regions.take(5)
        if (topRegions.isEmpty()) {
            reg.addView(TextView(this).apply {
                text = "暂无数据"
                textSize = 13f
                setTextColor(tc2())
            })
        } else {
            // v1.6.2：最活跃地区改用干净的排名文本列表（无条形），放在深色毛玻璃卡片里
            val card = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setBackgroundResource(R.drawable.glass_dark)
                elevation = dp(8).toFloat()
                setPadding(dp(16), dp(8), dp(16), dp(8))
                val lp = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                )
                layoutParams = lp
            }
            for ((i, entry) in topRegions.withIndex()) {
                card.addView(buildRegionRankRow(i + 1, entry.key, entry.value))
            }
            reg.addView(card)
        }

        renderAnalysisAi(last7, counts, magCounts, topRegions)
    }

    /** 7 天 AI 总分析：本地规则汇总先行，在线模型成功后替换并按天缓存。 */
    private fun renderAnalysisAi(
        last7: List<Quake>,
        counts: List<Pair<String, Int>>,
        magCounts: List<Pair<String, Int>>,
        topRegions: List<Map.Entry<String, Int>>
    ) {
        val tv = findViewById<TextView>(R.id.tvAnalysisAi)
        val now = System.currentTimeMillis()
        val max7 = last7.maxByOrNull { it.magnitude }
        val dayKey = SimpleDateFormat("yyyy-MM-dd", Locale.CHINA).apply {
            timeZone = beijing
        }.format(Date(now))
        val statsText = buildString {
            append("近7天中国地震共 ${last7.size} 场；")
            if (max7 != null) {
                append(
                    "最大 ${max7.magnitude}级（${max7.location}，" +
                        SimpleDateFormat("MM月dd日", Locale.CHINA).apply {
                            timeZone = beijing
                        }.format(Date(max7.timeMillis)) + "）；"
                )
            }
            append("每日数量：${counts.joinToString("、") { "${it.first}${it.second}场" }}；")
            append("震级分布：${magCounts.joinToString("、") { "${it.first}${it.second}场" }}；")
            if (topRegions.isNotEmpty()) {
                append("最活跃地区：${topRegions.joinToString("、") { "${it.key}${it.value}场" }}。")
            }
        }
        val localText = "智能分析（本地规则汇总）\n$statsText\n" +
            if (last7.isEmpty()) {
                "近7天目录内暂无地震记录。"
            } else if ((max7?.magnitude ?: 0.0) >= 6.0) {
                "近7天出现 6 级以上强震，请关注官方后续速报，做好防范。"
            } else {
                "近7天以中小地震为主，未出现 6 级以上强震，整体活动平稳。"
            } +
            "\n（以上为按本次统计的本地规则汇总，仅供参考，不构成预报。）"
        // 当天缓存的在线分析优先
        val cacheKey = "agg-7d-$dayKey"
        val cached = LocalStore.aiCache(this, cacheKey)
        if (!cached.isNullOrEmpty()) {
            try {
                val online = JSONObject(cached).optString("onlineText")
                if (online.isNotEmpty()) {
                    tv.text = "智能分析（在线模型生成）\n$online"
                    return
                }
            } catch (_: Exception) {
            }
        }
        tv.text = localText
        if (analysisAiLoading || analysisAiDay == dayKey) return
        analysisAiLoading = true
        analysisAiDay = dayKey
        OnlineAi.analyzeAggregate(statsText) { text ->
            analysisAiLoading = false
            if (text == null) return@analyzeAggregate
            try {
                LocalStore.saveAiCache(
                    this, cacheKey,
                    JSONObject().apply { put("onlineText", text) }.toString()
                )
            } catch (_: Exception) {
            }
            runOnUiThread { tv.text = "智能分析（在线模型生成）\n$text" }
        }
    }

    // ---------------- 预警页 ----------------

    private fun setupAlertPage() {
        findViewById<Switch>(R.id.switchVoice).setOnCheckedChangeListener { _, on ->
            prefs().edit().putBoolean("voice_on", on).apply()
        }
        findViewById<Switch>(R.id.switchNewQuakeVoice).setOnCheckedChangeListener { _, on ->
            prefs().edit().putBoolean("voice_new_quake_on", on).apply()
        }
        findViewById<Switch>(R.id.switchSound).setOnCheckedChangeListener { _, on ->
            LocalStore.setSoundOn(this, on)
        }
        findViewById<Switch>(R.id.switchVibrate).setOnCheckedChangeListener { _, on ->
            LocalStore.setVibrateOn(this, on)
        }
        findViewById<Button>(R.id.btnAlertSettings).setOnClickListener { openMyPage("settings") }
        findViewById<Button>(R.id.btnTestAlert).setOnClickListener {
            startActivity(Intent(this, AlertActivity::class.java).apply {
                putExtra("test", true)
                putExtra("voice", prefs().getBoolean("voice_on", true))
            })
        }
        findViewById<Button>(R.id.btnClearHistory).setOnClickListener {
            LocalStore.clearAlertHistory(this)
            renderAlertPage()
            Toast.makeText(this, "已清空", Toast.LENGTH_SHORT).show()
        }
    }

    private fun renderAlertPage() {
        val status = prefs().getString("service_status", "stopped") ?: "stopped"
        findViewById<TextView>(R.id.tvAlertStatus).text = when (status) {
            "ws_connected" -> "守护中 · 推送已连接"
            "polling" -> "推送断开 · 轮询兜底中"
            "connecting" -> "正在连接…"
            else -> "服务未运行"
        }
        val magLabel = prefs().getString("mag_label", "不限") ?: "不限"
        val intLabel = prefs().getString("intensity_label", "不限") ?: "不限"
        val leadLabel = prefs().getString("lead_label", "5秒") ?: "5秒"
        findViewById<TextView>(R.id.tvAlertThresholds).text =
            "报警阈值：震级≥$magLabel · 烈度≥$intLabel · 提前$leadLabel"
        findViewById<Switch>(R.id.switchVoice).isChecked = prefs().getBoolean("voice_on", true)
        findViewById<Switch>(R.id.switchNewQuakeVoice).isChecked =
            prefs().getBoolean("voice_new_quake_on", true)
        findViewById<Switch>(R.id.switchSound).isChecked = LocalStore.soundOn(this)
        findViewById<Switch>(R.id.switchVibrate).isChecked = LocalStore.vibrateOn(this)

        val ll = findViewById<LinearLayout>(R.id.llAlertHistory)
        ll.removeAllViews()
        val arr = LocalStore.alertHistory(this)
        if (arr.length() == 0) {
            ll.addView(TextView(this).apply {
                text = "暂无预警记录"
                textSize = 14f
                setTextColor(tc2())
            })
            return
        }
        val fmt = SimpleDateFormat("MM-dd HH:mm", Locale.CHINA)
        for (i in arr.length() - 1 downTo 0) {
            val o = arr.optJSONObject(i) ?: continue
            // v1.6.1：播报记录分三种——真实预警 / 地震通知（未达预警）/ 测试预览，
            // 并显示数据来源与第几报；老记录没有 kind/source 字段，按原样显示
            val kind = o.optString("kind").ifEmpty {
                if (o.optString("type") == "test") "test" else "warning"
            }
            val label = when (kind) {
                "test" -> "测试预览"
                "notification" -> "地震通知"
                else -> "真实预警"
            }
            val sourceSuffix = buildString {
                val src = o.optString("source")
                if (src.isNotEmpty()) append(" · $src")
                val rn = o.optInt("reportNum", 0)
                if (rn > 0) append(" 第${rn}报")
            }
            val lead = o.optInt("leadSec", -1)
            val sub = if (kind == "notification") {
                fmt.format(Date(o.optLong("time"))) + " · 未达预警阈值$sourceSuffix"
            } else if (lead >= 0) {
                fmt.format(Date(o.optLong("time"))) + " · 提前 ${lead} 秒报警$sourceSuffix"
            } else {
                fmt.format(Date(o.optLong("time"))) + sourceSuffix
            }
            ll.addView(
                buildStatRow(
                    "$label · ${o.optString("location")} ${o.optDouble("magnitude")}级",
                    sub
                )
            )
        }
    }

    // ---------------- 我的 ----------------

    private fun renderMy() {
        val city = prefs().getString("user_city", "") ?: ""
        findViewById<TextView>(R.id.tvMyCity).text =
            if (city.isNotEmpty()) city else "未设置监测城市"
        val status = prefs().getString("service_status", "stopped") ?: "stopped"
        findViewById<TextView>(R.id.tvMyStatus).text = when (status) {
            "ws_connected" -> "守护中 · 推送已连接"
            "polling" -> "推送断开 · 轮询兜底中"
            "connecting" -> "正在连接…"
            else -> "服务未运行"
        }
        val magLabel = prefs().getString("mag_label", "不限") ?: "不限"
        val intLabel = prefs().getString("intensity_label", "不限") ?: "不限"
        val leadLabel = prefs().getString("lead_label", "5秒") ?: "5秒"
        findViewById<TextView>(R.id.tvMyThresholds).text =
            "震级≥$magLabel · 烈度≥$intLabel · 提前$leadLabel"
        val statusText = prefs().getString("service_status", "stopped") ?: "stopped"
        val last = prefs().getLong("last_update", 0L)
        findViewById<TextView>(R.id.tvMyDataStatus).text =
            "推送：$statusText · " +
                if (last > 0) {
                    "上次刷新 " + SimpleDateFormat("HH:mm:ss", Locale.CHINA).apply {
                        timeZone = beijing
                    }.format(Date(last))
                } else {
                    "尚未刷新"
                } + " · 数据来源：中国地震台网（Wolfx 接口）· 天气：Open-Meteo"

        val voiceText = if (prefs().getBoolean("voice_on", true)) "开" else "关"
        val appearanceText = if (LocalStore.isDark(this)) "深色" else "浅色"
        val rows = listOf(
            Triple("预警设置", "震级≥$magLabel · 烈度≥$intLabel · 提前$leadLabel", "settings"),
            Triple("提醒方式", "$appearanceText · 语音播报$voiceText", "remind"),
            Triple("播报预览", "", "preview"),
            Triple("预警记录", "${LocalStore.alertHistory(this).length()} 条", "history"),
            Triple("震感记录", "${LocalStore.feltReports(this).length()} 条", "felt"),
            Triple("避难场所", "", "shelter"),
            Triple("家庭联系人", "${LocalStore.contacts(this).length()} 人", "contacts"),
            Triple(
                "家庭安全自查",
                "已完成 ${LocalStore.safetyProgress(this)}/${LocalStore.SAFETY_ITEMS.size} 项",
                "safety"
            ),
            Triple("帮助与支持", "", "help"),
            Triple("应急指南", "", "guide"),
            Triple("关于", "版本 1.4", "about")
        )
        val ll = findViewById<LinearLayout>(R.id.llMyRows)
        ll.removeAllViews()
        for ((title, value, page) in rows) {
            ll.addView(buildMyRow(title, value, page))
        }
    }

    private fun buildMyRow(title: String, value: String, page: String): View {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setBackgroundResource(cardBg())
            setPadding(dp(16), dp(14), dp(16), dp(14))
            val lp = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
            lp.bottomMargin = dp(8)
            layoutParams = lp
        }
        row.addView(TextView(this).apply {
            text = title
            textSize = 16f
            setTextColor(tc1())
            val lp = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            layoutParams = lp
        })
        if (value.isNotEmpty()) {
            row.addView(TextView(this).apply {
                text = value
                textSize = 13f
                setTextColor(tc2())
                val lp = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                )
                lp.marginEnd = dp(8)
                layoutParams = lp
            })
        }
        row.addView(TextView(this).apply {
            text = "›"
            textSize = 18f
            setTypeface(null, android.graphics.Typeface.BOLD)
            setTextColor(0xFF0B0F0B.toInt())
            gravity = Gravity.CENTER
            background = ContextCompat.getDrawable(this@MainActivity, R.drawable.arrow_circle)
            val lp = LinearLayout.LayoutParams(dp(28), dp(28))
            layoutParams = lp
        })
        row.setOnClickListener { openMyPage(page) }
        return row
    }
}
