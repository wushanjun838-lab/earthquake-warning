package com.quake.warning

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.util.Log
import androidx.core.app.NotificationCompat
import okhttp3.Call
import okhttp3.Callback
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import java.io.IOException
import java.util.concurrent.TimeUnit

/**
 * 常驻前台服务：实时预警的核心。
 *
 * 数据通道（按优先级）：
 * 1. WebSocket 直连中国地震台网预警推送 wss://ws-api.wolfx.jp/cenc_eew
 *    （服务端收到 EEW 即推送；心跳每分钟一次；客户端发 "ping" 保活）。
 * 1b. v1.6.1：第二路 WebSocket 直连四川省地震局预警推送
 *    wss://ws-api.wolfx.jp/sc_eew（订阅 "query_sceew"，2026-11-06 实测验证：
 *    连上即收到 heartbeat 与 sc_eew 事件报文）。同一场地震两路都会推，
 *    靠 QuakeMath.sameEvent 去重，只报一次，新的报告只更新记录。
 * 2. v1.6.1：第三路 WebSocket 直连 CENC 速报目录 wss://ws-api.wolfx.jp/cenc_eqlist
 *    （订阅 "query_cenceqlist"，实测验证：连上即收到 heartbeat 与最新 50 条列表），
 *    目录一更新就推过来；HTTP 轮询改为 120 秒一次，只做兜底。
 * 3. 兜底轮询中国地震台网速报目录 https://api.wolfx.jp/cenc_eqlist.json（120 秒一次）。
 * 推送或轮询拿到新地震后，按用户的位置、震级阈值、烈度阈值、提前时间计算
 * S 波到达时刻，满足条件即拉起全屏报警。
 */
class WarningService : Service() {

    companion object {
        const val TAG = "WarningService"
        const val CHANNEL_ID = "warning_running"
        const val NOTIF_ID = 1
        const val NOTIFY_CHANNEL_ID = "quake_notify"
        const val NOTIFY_ID = 2
        /** v1.6.2 锁屏全屏兜底渠道：高优先级全屏通知（独立渠道，不复用 LOW 的前台服务渠道）。 */
        const val FULLSCREEN_CHANNEL_ID = "quake_alert_fullscreen"
        const val ALERT_NOTIF_ID = 3
        const val ALERT_REQUEST_CODE = 100
        const val WS_URL = "wss://ws-api.wolfx.jp/cenc_eew"
        const val SC_WS_URL = "wss://ws-api.wolfx.jp/sc_eew"
        const val EQLIST_WS_URL = "wss://ws-api.wolfx.jp/cenc_eqlist"
        const val CATALOG_URL = "https://api.wolfx.jp/cenc_eqlist.json"
        /** 修订广播：某场已报警的地震来了更新的报告，通知弹窗/首页刷新显示。 */
        const val ACTION_EEW_REVISION = "com.quake.warning.EEW_REVISION"
    }

    /** 一路推送通道：url + 订阅指令 + 各自的重连退避。 */
    private class Feed(
        val key: String,
        val url: String,
        val subscribe: String,
        var ws: WebSocket? = null,
        var reconnectDelay: Long = 5000L,
        var connected: Boolean = false,
        /** 重连任务只建一次（同一个实例才能 removeCallbacks 取消）。 */
        var reconnectTask: Runnable? = null
    )

    private lateinit var prefs: SharedPreferences
    private val handler = Handler(Looper.getMainLooper())
    private var wsClient: OkHttpClient? = null
    private var httpClient: OkHttpClient? = null
    /** v1.6.1：三路推送并存（CENC 预警 / 四川局预警 / CENC 目录）。 */
    private val feeds = listOf(
        Feed("cenc_eew", WS_URL, "query_cenceew"),
        Feed("sc_eew", SC_WS_URL, "query_sceew"),
        Feed("cenc_eqlist", EQLIST_WS_URL, "query_cenceqlist")
    )
    private var wakeLock: PowerManager.WakeLock? = null
    private val alertedIds = mutableSetOf<String>()
    /** v1.5：已通知（未达预警）的地震 eventId，避免同一场地震反复通知/播报。 */
    private val notifiedIds = mutableSetOf<String>()
    /**
     * v1.6.1：已处理过的地震（报警或通知过的最新记录）。同一场地震从 CENC 与
     * 四川局两路先后报来时，EventID 格式不同（"202611060056.0001" vs
     * "202611060056.0001_2"），只比 eventId 全等一定漏判，这里按
     * QuakeMath.sameEvent（归一化 ID 或地点+时间）判重。
     */
    private val knownEvents = mutableListOf<Quake>()
    /** v1.6.1：已知事件的稳定键（持久化，服务重启后仍能挡住重复报警）。 */
    private val knownKeys = mutableSetOf<String>()
    private var serviceVoicePack: VoicePackPlayer? = null
    private var placeNameTts: PlaceNameTts? = null

    private val pingRunnable = object : Runnable {
        override fun run() {
            try {
                for (feed in feeds) feed.ws?.send("ping")
            } catch (_: Exception) {
            }
            handler.postDelayed(this, 50_000)
        }
    }

    private val pollRunnable = object : Runnable {
        override fun run() {
            pollCatalog()
            handler.postDelayed(this, 120_000)
        }
    }

    override fun onCreate() {
        super.onCreate()
        prefs = getSharedPreferences("prefs", Context.MODE_PRIVATE)
        alertedIds.addAll(
            prefs.getString("alerted_ids", "")!!.split(",").filter { it.isNotEmpty() }
        )
        notifiedIds.addAll(
            prefs.getString("notified_ids", "")!!.split(",").filter { it.isNotEmpty() }
        )
        knownKeys.addAll(
            prefs.getString("known_keys", "")!!.split(",").filter { it.isNotEmpty() }
        )
        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "quake:warning").apply {
            try {
                acquire()
            } catch (_: Exception) {
            }
        }
        createChannel()
        startForegroundCompat(buildNotification("正在连接台网推送通道…"))
        setStatus("connecting")
        wsClient = OkHttpClient.Builder()
            .readTimeout(0, TimeUnit.MILLISECONDS)
            .build()
        httpClient = OkHttpClient.Builder()
            .connectTimeout(15, TimeUnit.SECONDS)
            .readTimeout(15, TimeUnit.SECONDS)
            .build()
        connectAllFeeds()
        handler.post(pollRunnable)
        handler.post(pingRunnable)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        prefs.edit().putBoolean("service_wanted", true).apply()
        return START_STICKY
    }

    override fun onDestroy() {
        handler.removeCallbacks(pollRunnable)
        handler.removeCallbacks(pingRunnable)
        for (feed in feeds) {
            feed.reconnectTask?.let { handler.removeCallbacks(it) }
            try {
                feed.ws?.close(1000, "service stopped")
            } catch (_: Exception) {
            }
            feed.ws = null
        }
        try {
            wsClient?.dispatcher?.executorService?.shutdown()
        } catch (_: Exception) {
        }
        try {
            if (wakeLock?.isHeld == true) wakeLock?.release()
        } catch (_: Exception) {
        }
        setStatus("stopped")
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    // ---------------- WebSocket（三路推送） ----------------

    private fun connectAllFeeds() {
        for (feed in feeds) connectFeed(feed)
    }

    /** 每路通道一个重连任务（按 feed 区分，避免互相取消）。 */
    private fun feedReconnectTask(feed: Feed): Runnable {
        if (feed.reconnectTask == null) {
            feed.reconnectTask = Runnable { connectFeed(feed) }
        }
        return feed.reconnectTask!!
    }

    private fun connectFeed(feed: Feed) {
        val client = wsClient ?: return
        if (feed.ws != null) return
        feed.reconnectTask?.let { handler.removeCallbacks(it) }
        val request = Request.Builder().url(feed.url).build()
        feed.ws = client.newWebSocket(request, object : WebSocketListener() {
            override fun onOpen(webSocket: WebSocket, response: Response) {
                feed.connected = true
                feed.reconnectDelay = 5000L
                try {
                    webSocket.send(feed.subscribe)
                } catch (_: Exception) {
                }
                updateFeedStatus()
                Log.i(TAG, "feed connected: ${feed.key}")
            }

            override fun onMessage(webSocket: WebSocket, text: String) {
                // v1.5：任何消息（含 heartbeat/pong）都证明通道还活着，刷新活动时间，
                // 否则 last_update 只在状态变化时写，UI 会一直显示“21 分钟前更新”。
                touchActivity()
                if (text.contains("heartbeat") || text.contains("\"pong\"")) return
                if (feed.key == "cenc_eqlist") {
                    // 目录推送：整份最新 50 条列表，与轮询同一套处理
                    val quakes = EewParser.parseCatalog(text)
                    if (quakes.isNotEmpty()) handleCatalogUpdate(quakes)
                } else {
                    val quake = EewParser.parseEew(text)
                    if (quake != null) {
                        evaluate(quake)
                    } else {
                        Log.i(TAG, "unparsed EEW payload (${feed.key}): ${text.take(300)}")
                    }
                }
            }

            override fun onClosed(webSocket: WebSocket, code: Int, reason: String) {
                onFeedLost(feed)
            }

            override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                Log.w(TAG, "feed failure (${feed.key}): ${t.message}")
                onFeedLost(feed)
            }
        })
    }

    private fun onFeedLost(feed: Feed) {
        if (feed.ws == null) return
        feed.ws = null
        feed.connected = false
        updateFeedStatus()
        handler.postDelayed(feedReconnectTask(feed), feed.reconnectDelay)
        feed.reconnectDelay = (feed.reconnectDelay * 2).coerceAtMost(60_000)
    }

    /**
     * 三路通道的合并状态：CENC 预警通道在即为“已连接”（主通道决定状态）；
     * 主通道断了才显示轮询兜底。四川局/目录通道各自断线重连，不单独改状态，
     * 只记日志（它们的断线不影响主预警，轮询兜底仍在）。
     */
    private fun updateFeedStatus() {
        val main = feeds.first { it.key == "cenc_eew" }
        if (main.connected) {
            val scOk = feeds.first { it.key == "sc_eew" }.connected
            val listOk = feeds.first { it.key == "cenc_eqlist" }.connected
            setStatus("ws_connected")
            updateNotification(
                if (scOk && listOk) "台网推送已连接 · 实时预警中"
                else "台网推送已连接 · 实时预警中（部分通道重连中）"
            )
        } else {
            setStatus("polling")
            updateNotification("推送通道断开 · 轮询兜底中（120 秒一次）")
        }
    }

    // ---------------- 轮询兜底（120 秒一次，目录推送断了才靠它） ----------------

    private fun pollCatalog() {
        val client = httpClient ?: return
        val request = Request.Builder().url(CATALOG_URL).build()
        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                Log.w(TAG, "catalog poll failed: ${e.message}")
            }

            override fun onResponse(call: Call, response: Response) {
                val body = response.body?.string() ?: return
                val quakes = EewParser.parseCatalog(body)
                if (quakes.isNotEmpty()) handleCatalogUpdate(quakes)
            }
        })
    }

    /**
     * 目录更新的统一处理（HTTP 轮询与 cenc_eqlist 推送共用同一套）：
     * 存最近地震、逐条判定（报警 / 未达预警通知）。
     */
    private fun handleCatalogUpdate(quakes: List<Quake>) {
        if (quakes.isEmpty()) return
        touchActivity()
        saveRecent(quakes.take(5))
        for (q in quakes) evaluate(q)
    }

    /** 最近地震存完整字段（震级/深度/经纬度/烈度/EventID），供列表、详情、AI 分析用。 */
    private fun saveRecent(quakes: List<Quake>) {
        LocalStore.saveRecentFull(this, quakes.take(20))
    }

    // ---------------- 判定与报警 ----------------

    /**
     * v1.6.1 多数据源去重（核心规则，见 QuakeMath.sameEvent）：
     * 同一场地震从 CENC 与四川局两路先后报来时，只处理一次。
     * 已处理过的事件再收到更新的报告（ReportTime 更晚）时，不再重复报警/
     * 通知/播报，只把记录更新为最新报告，并刷新已显示的地方（弹窗、列表、
     * 播报记录）。服务重启后内存记录丢失时，靠持久化的 knownKeys 挡住重复报警。
     */
    private fun findKnown(quake: Quake): Quake? =
        knownEvents.firstOrNull { QuakeMath.sameEvent(it, quake) }

    /** 新报告比已存记录新吗（ReportTime 更晚为准；都没有 ReportTime 时看第几报）。 */
    private fun isNewerRevision(incoming: Quake, known: Quake): Boolean {
        if (incoming.reportTimeMillis > 0 && known.reportTimeMillis > 0) {
            return incoming.reportTimeMillis > known.reportTimeMillis
        }
        if (incoming.reportTimeMillis > 0 && known.reportTimeMillis == 0L) return true
        if (incoming.reportNum > 0 && known.reportNum > 0 &&
            incoming.source == known.source
        ) {
            return incoming.reportNum > known.reportNum
        }
        return false
    }

    /** 记下已处理过的事件（内存 + 持久化键），最多保留 200 场。 */
    private fun rememberEvent(quake: Quake) {
        val idx = knownEvents.indexOfFirst { QuakeMath.sameEvent(it, quake) }
        if (idx >= 0) knownEvents[idx] = quake else knownEvents.add(quake)
        if (knownEvents.size > 200) knownEvents.removeAt(0)
        val key = QuakeMath.canonicalEventKey(quake)
        if (knownKeys.add(key)) {
            if (knownKeys.size > 200) knownKeys.remove(knownKeys.first())
            prefs.edit().putString("known_keys", knownKeys.joinToString(",")).apply()
        }
    }

    /** 已处理事件来了更新的报告：刷新记录与各处显示，不再重复报警/通知/播报。 */
    private fun updateKnown(incoming: Quake, known: Quake) {
        rememberEvent(incoming)
        // 播报记录里更新为最新报告（震级/地点/来源/第几报）
        LocalStore.addAlertHistory(
            this, "real", incoming.location, incoming.magnitude, -1,
            eventId = incoming.eventId, source = incoming.source,
            reportNum = incoming.reportNum,
            kind = if (alertedIds.contains(known.eventId)) "warning" else "notification",
            eventKey = QuakeMath.canonicalEventKey(incoming),
            originTime = incoming.timeMillis
        )
        // 本地最近列表也更新，首页列表/详情打开即是最新数据
        LocalStore.updateRecentQuake(this, incoming)
        // 已在全屏报警的地震：通知弹窗刷新显示（震级/地点/来源/第几报）
        if (alertedIds.contains(known.eventId)) {
            sendRevisionBroadcast(incoming)
        }
    }

    /** 通知预警弹窗：某场地震的报告更新了（震级/地点/来源/第几报）。 */
    private fun sendRevisionBroadcast(quake: Quake) {
        val intent = Intent(ACTION_EEW_REVISION).apply {
            putExtra("event_key", QuakeMath.canonicalEventKey(quake))
            putExtra("location", quake.location)
            putExtra("magnitude", quake.magnitude)
            putExtra("source", quake.source)
            putExtra("report_num", quake.reportNum)
            putExtra("intensity", quake.intensity ?: -1)
            putExtra("depth", quake.depthKm ?: -1.0)
            putExtra("time", quake.timeMillis)
            putExtra("latitude", quake.latitude)
            putExtra("longitude", quake.longitude)
        }
        sendBroadcast(intent)
    }

    /**
     * 提前时间语义：只有当 S 波到达还剩至少 minLeadSec 秒时才报警
     * （避免“已经到了才报”的无效报警；设 5 秒≈几乎都报）。
     */
    private fun evaluate(quake: Quake) {
        // v1.6.1：先判重——已处理过的事件不再走第二遍判定
        val known = findKnown(quake)
        if (known != null) {
            if (isNewerRevision(quake, known)) updateKnown(quake, known)
            return
        }
        if (knownKeys.contains(QuakeMath.canonicalEventKey(quake))) return
        if (alertedIds.contains(quake.eventId)) return
        if (notifiedIds.contains(quake.eventId)) return
        val userLat = prefs.getFloat("user_lat", 0f).toDouble()
        val userLon = prefs.getFloat("user_lon", 0f).toDouble()
        val hasLoc = userLat != 0.0 || userLon != 0.0
        val dist = if (hasLoc) QuakeMath.distanceKm(userLat, userLon, quake.latitude, quake.longitude) else 0.0
        val intensity = if (hasLoc) {
            quake.intensity ?: QuakeMath.estimateIntensity(quake.magnitude, dist)
        } else {
            quake.intensity
        }
        // v1.5：达不到报警阈值的地震，走“未达预警通知”（通知栏提醒 + 语音播报，可开关）。
        // 注意：这里不要求提前时间——波已经到了的地震也要通知，只是形式不是全屏弹窗。
        if (!hasLoc) {
            // 无定位时仍可通知（只报震中+震级，不含距离/体感）
            notifyNonAlert(quake, null, null)
            return
        }
        val sArrival = QuakeMath.sArrivalMillis(quake.timeMillis, dist)
        val leadSec = (sArrival - System.currentTimeMillis()) / 1000
        val minLead = prefs.getInt("min_lead_sec", 5)
        if (leadSec < minLead) {
            notifyNonAlert(quake, dist, intensity)
            return
        }
        val minMag = prefs.getFloat("min_mag", 0f).toDouble()
        if (quake.magnitude < minMag) {
            notifyNonAlert(quake, dist, intensity)
            return
        }
        val minIntensity = prefs.getInt("min_intensity", 0)
        if (intensity != null && intensity < minIntensity) {
            notifyNonAlert(quake, dist, intensity)
            return
        }

        alertedIds.add(quake.eventId)
        if (alertedIds.size > 200) alertedIds.remove(alertedIds.first())
        prefs.edit().putString("alerted_ids", alertedIds.joinToString(",")).apply()
        rememberEvent(quake)
        LocalStore.addAlertHistory(
            this, "real", quake.location, quake.magnitude, leadSec.toInt(),
            eventId = quake.eventId, source = quake.source,
            reportNum = quake.reportNum, kind = "warning",
            eventKey = QuakeMath.canonicalEventKey(quake),
            originTime = quake.timeMillis
        )

        val intent = Intent(this, AlertActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
            putExtra("location", quake.location)
            putExtra("magnitude", quake.magnitude)
            putExtra("depth", quake.depthKm ?: -1.0)
            putExtra("intensity", intensity ?: 0)
            // 我所在地预计烈度（震级+距离衰减估算，AlertActivity 大红板显示用，
            // 与台网的震中烈度 intensity 分开，避免把震中烈度当成本地烈度）
            putExtra("local_intensity", QuakeMath.estimateIntensity(quake.magnitude, dist))
            putExtra("latitude", quake.latitude)
            putExtra("longitude", quake.longitude)
            putExtra("time", quake.timeMillis)
            putExtra("s_arrival", sArrival)
            putExtra("voice", prefs.getBoolean("voice_on", true))
            // v1.6.1：数据来源与第几报（弹窗显示用；修订广播按 event_key 匹配）
            putExtra("source", quake.source)
            putExtra("report_num", quake.reportNum)
            putExtra("event_key", QuakeMath.canonicalEventKey(quake))
        }
        startActivity(intent)
        // v1.6.2 锁屏全屏兜底：直接弹屏可能被系统拦截（锁屏/久置后尤其如此），
        // 再发一条高优先级全屏通知——系统在锁屏时直接全屏展开同一 AlertActivity；
        // 若直接弹屏成功，singleTop 去重，不会出两个弹窗。
        postFullScreenAlert(intent, quake)
    }

    /**
     * v1.6.2 锁屏全屏兜底：高优先级通知 + setFullScreenIntent，指向与直接弹屏
     * 同一款 AlertActivity（同款 extras：地点/震级/深度/烈度/本地烈度/经纬度/
     * 时间/到达时刻/语音开关/来源/第几报/event_key）。
     * 用独立的 IMPORTANCE_HIGH 渠道“地震预警全屏”，绝不复用 LOW 的前台服务渠道。
     * 窗口 flags（AlertActivity 的 SHOW_WHEN_LOCKED 等）与唤醒锁保持不变。
     */
    private fun postFullScreenAlert(intent: Intent, quake: Quake) {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                FULLSCREEN_CHANNEL_ID, "地震预警全屏",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "地震预警全屏弹窗（锁屏时也能自动展开）"
            }
            nm.createNotificationChannel(channel)
        }
        val fullScreenPending = PendingIntent.getActivity(
            this, ALERT_REQUEST_CODE, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val notification = NotificationCompat.Builder(this, FULLSCREEN_CHANNEL_ID)
            .setContentTitle("地震预警 · ${quake.magnitude}级")
            .setContentText("${quake.location}发生${quake.magnitude}级地震，S波即将到达，请立即避险")
            .setSmallIcon(R.drawable.ic_bell)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setFullScreenIntent(fullScreenPending, true)
            .setAutoCancel(true)
            .build()
        nm.notify(ALERT_NOTIF_ID, notification)
    }

    // ---------------- 未达预警通知（v1.5） ----------------

    /**
     * 未达预警通知：3.0 级以上、但没达到全屏报警阈值的地震，
     * 发一条状态栏通知 +（可选）语音播报。开关在 我的 > 提醒方式。
     * 注意：这里不要求提前时间——波已经到了的地震也要通知，
     * 只是形式不是全屏弹窗。
     */
    private fun notifyNonAlert(quake: Quake, dist: Double?, intensity: Int?) {
        if (quake.magnitude < 3.0) return
        val notifyOn = prefs.getBoolean("notify_non_alert_on", true)
        val voiceOn = prefs.getBoolean("voice_on", true) &&
            prefs.getBoolean("voice_new_quake_on", true)
        if (!notifyOn && !voiceOn) return
        notifiedIds.add(quake.eventId)
        if (notifiedIds.size > 200) notifiedIds.remove(notifiedIds.first())
        prefs.edit().putString("notified_ids", notifiedIds.joinToString(",")).apply()
        rememberEvent(quake)
        // v1.6.1 播报记录：未达预警的通知/语音也记一条（kind="notification"，
        // leadSec=-1 表示不是全屏报警）；多数据源同一场地震只更新不重复记
        LocalStore.addAlertHistory(
            this, "real", quake.location, quake.magnitude, -1,
            eventId = quake.eventId, source = quake.source,
            reportNum = quake.reportNum, kind = "notification",
            eventKey = QuakeMath.canonicalEventKey(quake),
            originTime = quake.timeMillis
        )
        if (notifyOn) postQuakeNotification(quake, dist, intensity)
        if (voiceOn) speakNonAlert(quake, dist, intensity)
    }

    private fun postQuakeNotification(quake: Quake, dist: Double?, intensity: Int?) {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                NOTIFY_CHANNEL_ID, "地震速报",
                NotificationManager.IMPORTANCE_DEFAULT
            )
            nm.createNotificationChannel(channel)
        }
        // v1.6 Bug 2：目录推送本身就晚几分钟，地震被看到时可能已是几分钟前。
        // 若已发生 ≥2 分钟，句首加“X分钟前”，避免听起来像刚发生的紧急事件。
        val ageMin = ((System.currentTimeMillis() - quake.timeMillis) / 60000).toInt()
        val agePrefix = if (ageMin >= 2) "${ageMin}分钟前，" else ""
        val text = buildString {
            append("$agePrefix${quake.location}发生${quake.magnitude}级地震")
            if (dist != null && intensity != null) {
                append("，距你约${dist.toInt()}公里，我所在地预计${intensity}度")
            }
            append("（未达预警阈值）")
        }
        val intent = Intent(this, MainActivity::class.java)
        val pending = PendingIntent.getActivity(
            this, 0, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val notification = NotificationCompat.Builder(this, NOTIFY_CHANNEL_ID)
            .setContentTitle("地震速报 · ${quake.magnitude}级")
            .setContentText(text)
            .setSmallIcon(R.drawable.ic_bell)
            .setContentIntent(pending)
            .setAutoCancel(true)
            .build()
        nm.notify(NOTIFY_ID, notification)
    }

    /** 未达预警地震的语音播报：在线普通话读全句，失败时用预录语音包报震级+体感。 */
    private fun speakNonAlert(quake: Quake, dist: Double?, intensity: Int?) {
        val feeling = intensity?.let { QuakeMath.feelingText(it) }
        // v1.6 Bug 2：已发生 ≥2 分钟的地震，句首加“X分钟前”（与通知栏一致）
        val ageMin = ((System.currentTimeMillis() - quake.timeMillis) / 60000).toInt()
        val agePrefix = if (ageMin >= 2) "${ageMin}分钟前，" else ""
        val sentence = buildString {
            append("$agePrefix${quake.location}发生${quake.magnitude}级地震")
            if (dist != null && intensity != null && feeling != null) {
                append("，距你约${dist.toInt()}公里，我所在地预计${intensity}度，$feeling")
            }
        }
        if (placeNameTts == null) placeNameTts = PlaceNameTts(this)
        placeNameTts?.speak(sentence) { ok ->
            if (!ok && feeling != null) {
                val pack = LocalStore.voicePack(this)
                if (pack != "system") {
                    serviceVoicePack?.release()
                    serviceVoicePack = VoicePackPlayer(this, pack)
                    serviceVoicePack?.playMagnitudeAndFeeling(quake.magnitude, feeling)
                    handler.postDelayed({ serviceVoicePack?.release() }, 5000)
                }
            }
        }
    }

    // ---------------- 通知与状态 ----------------

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID, "地震预警运行状态",
                NotificationManager.IMPORTANCE_LOW
            )
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            nm.createNotificationChannel(channel)
        }
    }

    private fun buildNotification(text: String): Notification {
        val intent = Intent(this, MainActivity::class.java)
        val pending = PendingIntent.getActivity(
            this, 0, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("中国地震预警运行中")
            .setContentText(text)
            .setSmallIcon(R.drawable.ic_bell)
            .setContentIntent(pending)
            .setOngoing(true)
            .build()
    }

    private fun updateNotification(text: String) {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.notify(NOTIF_ID, buildNotification(text))
    }

    private fun startForegroundCompat(notification: Notification) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(
                NOTIF_ID, notification,
                android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC
            )
        } else {
            startForeground(NOTIF_ID, notification)
        }
    }

    private fun setStatus(status: String) {
        prefs.edit()
            .putString("service_status", status)
            .putLong("last_update", System.currentTimeMillis())
            .apply()
    }

    /** v1.5：刷新“最后活动”时间（轮询/心跳/推送都算），不改状态。UI 的“刚刚更新”就靠它。 */
    private fun touchActivity() {
        prefs.edit().putLong("last_update", System.currentTimeMillis()).apply()
    }
}
