package com.quake.warning

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.util.Log
import androidx.core.app.NotificationCompat
import okhttp3.Call
import okhttp3.Callback
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import java.io.IOException
import java.util.concurrent.TimeUnit

/**
 * 常驻前台服务：实时预警的核心。
 *
 * 数据通道（按优先级）：
 * 1. WebSocket 直连中国地震台网预警推送 wss://ws-api.wolfx.jp/cenc_eew
 *    （服务端收到 EEW 即推送；心跳每分钟一次；客户端发 "ping" 保活）。
 * 2. 兜底轮询中国地震台网速报目录 https://api.wolfx.jp/cenc_eqlist.json（30 秒一次）。
 * 推送或轮询拿到新地震后，按用户的位置、震级阈值、烈度阈值、提前时间计算
 * S 波到达时刻，满足条件即拉起全屏报警。
 */
class WarningService : Service() {

    companion object {
        const val TAG = "WarningService"
        const val CHANNEL_ID = "warning_running"
        const val NOTIF_ID = 1
        const val NOTIFY_CHANNEL_ID = "quake_notify"
        const val NOTIFY_ID = 2
        const val WS_URL = "wss://ws-api.wolfx.jp/cenc_eew"
        const val CATALOG_URL = "https://api.wolfx.jp/cenc_eqlist.json"
    }

    private lateinit var prefs: SharedPreferences
    private val handler = Handler(Looper.getMainLooper())
    private var wsClient: OkHttpClient? = null
    private var httpClient: OkHttpClient? = null
    private var ws: WebSocket? = null
    private var wakeLock: PowerManager.WakeLock? = null
    private var reconnectDelay = 5000L
    private val alertedIds = mutableSetOf<String>()
    /** v1.5：已通知（未达预警）的地震 eventId，避免同一场地震反复通知/播报。 */
    private val notifiedIds = mutableSetOf<String>()
    private var serviceVoicePack: VoicePackPlayer? = null
    private var placeNameTts: PlaceNameTts? = null

    private val pingRunnable = object : Runnable {
        override fun run() {
            try {
                ws?.send("ping")
            } catch (_: Exception) {
            }
            handler.postDelayed(this, 50_000)
        }
    }

    private val pollRunnable = object : Runnable {
        override fun run() {
            pollCatalog()
            handler.postDelayed(this, 30_000)
        }
    }

    private val reconnectRunnable = Runnable { connectWs() }

    override fun onCreate() {
        super.onCreate()
        prefs = getSharedPreferences("prefs", Context.MODE_PRIVATE)
        alertedIds.addAll(
            prefs.getString("alerted_ids", "")!!.split(",").filter { it.isNotEmpty() }
        )
        notifiedIds.addAll(
            prefs.getString("notified_ids", "")!!.split(",").filter { it.isNotEmpty() }
        )
        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "quake:warning").apply {
            try {
                acquire()
            } catch (_: Exception) {
            }
        }
        createChannel()
        startForegroundCompat(buildNotification("正在连接台网推送通道…"))
        setStatus("connecting")
        wsClient = OkHttpClient.Builder()
            .readTimeout(0, TimeUnit.MILLISECONDS)
            .build()
        httpClient = OkHttpClient.Builder()
            .connectTimeout(15, TimeUnit.SECONDS)
            .readTimeout(15, TimeUnit.SECONDS)
            .build()
        connectWs()
        handler.post(pollRunnable)
        handler.post(pingRunnable)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        prefs.edit().putBoolean("service_wanted", true).apply()
        return START_STICKY
    }

    override fun onDestroy() {
        handler.removeCallbacks(pollRunnable)
        handler.removeCallbacks(pingRunnable)
        handler.removeCallbacks(reconnectRunnable)
        try {
            ws?.close(1000, "service stopped")
        } catch (_: Exception) {
        }
        try {
            wsClient?.dispatcher?.executorService?.shutdown()
        } catch (_: Exception) {
        }
        try {
            if (wakeLock?.isHeld == true) wakeLock?.release()
        } catch (_: Exception) {
        }
        setStatus("stopped")
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    // ---------------- WebSocket ----------------

    private fun connectWs() {
        handler.removeCallbacks(reconnectRunnable)
        val client = wsClient ?: return
        val request = Request.Builder().url(WS_URL).build()
        ws = client.newWebSocket(request, object : WebSocketListener() {
            override fun onOpen(webSocket: WebSocket, response: Response) {
                reconnectDelay = 5000L
                setStatus("ws_connected")
                updateNotification("台网推送已连接 · 实时预警中")
                Log.i(TAG, "EEW websocket connected")
            }

            override fun onMessage(webSocket: WebSocket, text: String) {
                // v1.5：任何消息（含 heartbeat/pong）都证明通道还活着，刷新活动时间，
                // 否则 last_update 只在状态变化时写，UI 会一直显示“21 分钟前更新”。
                touchActivity()
                if (text.contains("heartbeat") || text.contains("\"pong\"")) return
                val quake = EewParser.parseEew(text)
                if (quake != null) {
                    evaluate(quake)
                } else {
                    Log.i(TAG, "unparsed EEW payload: ${text.take(300)}")
                }
            }

            override fun onClosed(webSocket: WebSocket, code: Int, reason: String) {
                onWsLost()
            }

            override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                Log.w(TAG, "EEW websocket failure: ${t.message}")
                onWsLost()
            }
        })
    }

    private fun onWsLost() {
        if (ws == null) return
        ws = null
        setStatus("polling")
        updateNotification("推送通道断开 · 轮询兜底中（30 秒一次）")
        handler.postDelayed(reconnectRunnable, reconnectDelay)
        reconnectDelay = (reconnectDelay * 2).coerceAtMost(60_000)
    }

    // ---------------- 轮询兜底 ----------------

    private fun pollCatalog() {
        val client = httpClient ?: return
        val request = Request.Builder().url(CATALOG_URL).build()
        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                Log.w(TAG, "catalog poll failed: ${e.message}")
            }

            override fun onResponse(call: Call, response: Response) {
                val body = response.body?.string() ?: return
                val quakes = EewParser.parseCatalog(body)
                if (quakes.isEmpty()) return
                touchActivity()
                saveRecent(quakes.take(5))
                for (q in quakes) evaluate(q)
            }
        })
    }

    /** 最近地震存完整字段（震级/深度/经纬度/烈度/EventID），供列表、详情、AI 分析用。 */
    private fun saveRecent(quakes: List<Quake>) {
        LocalStore.saveRecentFull(this, quakes.take(20))
    }

    // ---------------- 判定与报警 ----------------

    /**
     * 提前时间语义：只有当 S 波到达还剩至少 minLeadSec 秒时才报警
     * （避免“已经到了才报”的无效报警；设 5 秒≈几乎都报）。
     */
    private fun evaluate(quake: Quake) {
        if (alertedIds.contains(quake.eventId)) return
        if (notifiedIds.contains(quake.eventId)) return
        val userLat = prefs.getFloat("user_lat", 0f).toDouble()
        val userLon = prefs.getFloat("user_lon", 0f).toDouble()
        val hasLoc = userLat != 0.0 || userLon != 0.0
        val dist = if (hasLoc) QuakeMath.distanceKm(userLat, userLon, quake.latitude, quake.longitude) else 0.0
        val intensity = if (hasLoc) {
            quake.intensity ?: QuakeMath.estimateIntensity(quake.magnitude, dist)
        } else {
            quake.intensity
        }
        // v1.5：达不到报警阈值的地震，走“未达预警通知”（通知栏提醒 + 语音播报，可开关）。
        // 注意：这里不要求提前时间——波已经到了的地震也要通知，只是形式不是全屏弹窗。
        if (!hasLoc) {
            // 无定位时仍可通知（只报震中+震级，不含距离/体感）
            notifyNonAlert(quake, null, null)
            return
        }
        val sArrival = QuakeMath.sArrivalMillis(quake.timeMillis, dist)
        val leadSec = (sArrival - System.currentTimeMillis()) / 1000
        val minLead = prefs.getInt("min_lead_sec", 5)
        if (leadSec < minLead) {
            notifyNonAlert(quake, dist, intensity)
            return
        }
        val minMag = prefs.getFloat("min_mag", 0f).toDouble()
        if (quake.magnitude < minMag) {
            notifyNonAlert(quake, dist, intensity)
            return
        }
        val minIntensity = prefs.getInt("min_intensity", 0)
        if (intensity != null && intensity < minIntensity) {
            notifyNonAlert(quake, dist, intensity)
            return
        }

        alertedIds.add(quake.eventId)
        if (alertedIds.size > 200) alertedIds.remove(alertedIds.first())
        prefs.edit().putString("alerted_ids", alertedIds.joinToString(",")).apply()
        LocalStore.addAlertHistory(this, "real", quake.location, quake.magnitude, leadSec.toInt())

        val intent = Intent(this, AlertActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
            putExtra("location", quake.location)
            putExtra("magnitude", quake.magnitude)
            putExtra("depth", quake.depthKm ?: -1.0)
            putExtra("intensity", intensity ?: 0)
            // 我所在地预计烈度（震级+距离衰减估算，AlertActivity 大红板显示用，
            // 与台网的震中烈度 intensity 分开，避免把震中烈度当成本地烈度）
            putExtra("local_intensity", QuakeMath.estimateIntensity(quake.magnitude, dist))
            putExtra("latitude", quake.latitude)
            putExtra("longitude", quake.longitude)
            putExtra("time", quake.timeMillis)
            putExtra("s_arrival", sArrival)
            putExtra("voice", prefs.getBoolean("voice_on", true))
        }
        startActivity(intent)
    }

    // ---------------- 未达预警通知（v1.5） ----------------

    /**
     * 未达预警通知：3.0 级以上、但没达到全屏报警阈值的地震，
     * 发一条状态栏通知 +（可选）语音播报。开关在 我的 > 提醒方式。
     * 注意：这里不要求提前时间——波已经到了的地震也要通知，
     * 只是形式不是全屏弹窗。
     */
    private fun notifyNonAlert(quake: Quake, dist: Double?, intensity: Int?) {
        if (quake.magnitude < 3.0) return
        val notifyOn = prefs.getBoolean("notify_non_alert_on", true)
        val voiceOn = prefs.getBoolean("voice_on", true) &&
            prefs.getBoolean("voice_new_quake_on", true)
        if (!notifyOn && !voiceOn) return
        notifiedIds.add(quake.eventId)
        if (notifiedIds.size > 200) notifiedIds.remove(notifiedIds.first())
        prefs.edit().putString("notified_ids", notifiedIds.joinToString(",")).apply()
        if (notifyOn) postQuakeNotification(quake, dist, intensity)
        if (voiceOn) speakNonAlert(quake, dist, intensity)
    }

    private fun postQuakeNotification(quake: Quake, dist: Double?, intensity: Int?) {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                NOTIFY_CHANNEL_ID, "地震速报",
                NotificationManager.IMPORTANCE_DEFAULT
            )
            nm.createNotificationChannel(channel)
        }
        val text = buildString {
            append("${quake.location}发生${quake.magnitude}级地震")
            if (dist != null && intensity != null) {
                append("，距你约${dist.toInt()}公里，我所在地预计${intensity}度")
            }
            append("（未达预警阈值）")
        }
        val intent = Intent(this, MainActivity::class.java)
        val pending = PendingIntent.getActivity(
            this, 0, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val notification = NotificationCompat.Builder(this, NOTIFY_CHANNEL_ID)
            .setContentTitle("地震速报 · ${quake.magnitude}级")
            .setContentText(text)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentIntent(pending)
            .setAutoCancel(true)
            .build()
        nm.notify(NOTIFY_ID, notification)
    }

    /** 未达预警地震的语音播报：在线普通话读全句，失败时用预录语音包报震级+体感。 */
    private fun speakNonAlert(quake: Quake, dist: Double?, intensity: Int?) {
        val feeling = intensity?.let { QuakeMath.feelingText(it) }
        val sentence = buildString {
            append("${quake.location}发生${quake.magnitude}级地震")
            if (dist != null && intensity != null && feeling != null) {
                append("，距你约${dist.toInt()}公里，我所在地预计${intensity}度，$feeling")
            }
        }
        if (placeNameTts == null) placeNameTts = PlaceNameTts(this)
        placeNameTts?.speak(sentence) { ok ->
            if (!ok && feeling != null) {
                val pack = LocalStore.voicePack(this)
                if (pack != "system") {
                    serviceVoicePack?.release()
                    serviceVoicePack = VoicePackPlayer(this, pack)
                    serviceVoicePack?.playMagnitudeAndFeeling(quake.magnitude, feeling)
                    handler.postDelayed({ serviceVoicePack?.release() }, 5000)
                }
            }
        }
    }

    // ---------------- 通知与状态 ----------------

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID, "地震预警运行状态",
                NotificationManager.IMPORTANCE_LOW
            )
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            nm.createNotificationChannel(channel)
        }
    }

    private fun buildNotification(text: String): Notification {
        val intent = Intent(this, MainActivity::class.java)
        val pending = PendingIntent.getActivity(
            this, 0, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("中国地震预警运行中")
            .setContentText(text)
            .setSmallIcon(android.R.drawable.ic_dialog_alert)
            .setContentIntent(pending)
            .setOngoing(true)
            .build()
    }

    private fun updateNotification(text: String) {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.notify(NOTIF_ID, buildNotification(text))
    }

    private fun startForegroundCompat(notification: Notification) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(
                NOTIF_ID, notification,
                android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC
            )
        } else {
            startForeground(NOTIF_ID, notification)
        }
    }

    private fun setStatus(status: String) {
        prefs.edit()
            .putString("service_status", status)
            .putLong("last_update", System.currentTimeMillis())
            .apply()
    }

    /** v1.5：刷新“最后活动”时间（轮询/心跳/推送都算），不改状态。UI 的“刚刚更新”就靠它。 */
    private fun touchActivity() {
        prefs.edit().putLong("last_update", System.currentTimeMillis()).apply()
    }
}
