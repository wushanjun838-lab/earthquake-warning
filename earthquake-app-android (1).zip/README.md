# 中国地震预警（原生 App）

给自己手机用的地震预警 App：常驻前台服务，实时连中国地震台网预警推送通道，
地震一来就全屏报警、倒计时、警报声、震动、普通话播报。

## 它怎么做到秒级

- **主通道**：手机 App 直连中国地震台网预警推送 `wss://ws-api.wolfx.jp/cenc_eew`
  （台网一捕捉到地震就向所有连接的客户端推送，不用等轮询）。
- **兜底**：推送断开时自动每 30 秒轮询一次台网速报目录
  `https://api.wolfx.jp/cenc_eqlist.json`，并自动重连推送。
- **判定**：按你设的位置算震中距离，用 S 波 3.5 km/s 算到达时刻；
  只有同时满足震级阈值、烈度阈值、提前时间（S 波还剩至少这么久才到）
  才报警，避免“已经到了才报”的无效报警。
- **报警**：锁屏也能亮屏全屏弹出，倒计时 + 警报声 + 震动 + 语音播报，
  直到你点“我知道了”才停。

## 同步更新（2026-11-06，版本 1.1，与网页版 v7–v16 同步 + 新增 AI 分析）

- **成熟 App 结构**：底部导航只有 首页 / 我的 两个页签。
  首页：问候顶栏（圆形搜索）→ 播报条胶囊 → Hero 监测卡（状态 + 24小时统计）→
  “值得关注”横向海报卡 → 3 个快捷入口（播报预览、避难场所、应急指南）→
  “离我最近”→ 最近地震列表。我的：身份卡 + 钻取列表行 + 二级页
  （预警设置 / 提醒方式 / 播报预览 / 预警记录 / 震感记录 / 避难场所 /
  家庭联系人 / 家庭安全自查 / 帮助与支持 / 应急指南 / 关于），一次只看一组。
- **深绿新外观（默认）**：近黑深绿底（#0B0F0B）、荧光绿（#93E62A）光晕、
  深色毛玻璃大圆角卡片、海报式“值得关注”卡（震级颜色、地震波纹环、大震级数字、
  第三张卡露一半）、荧光绿渐变应急指南卡、深色底部导航（激活项荧光绿）。
  外观可在“我的 > 提醒方式”里切浅色 / 跟随系统；没选过时默认深色。
- **预警弹窗 = 第一版 + 天气物资**：只有等级/震中/震级、倒计时大数字、
  当地天气和按天气推荐的随身物资；不要微博、不要避难场所整块、
  不要提示音流程文字。避难场所只在“我的”里有入口。
- **读秒与强提示音**：倒计时从收到实时推送那一刻开始，10 秒开外每 2 秒读一下，
  最后 10 秒每秒读；S 波到达时程序生成的警笛强提示音持续 20 秒，
  之后恢复普通警报声，直到手动停止。监测打开即自动启动。
- **严格普通话播报**：只认 zh-CN / zh-Hans-CN 的语音，粤语/港台语音一律排除；
  本机没有普通话语音时改用蜂鸣代替读秒，绝不用粤语凑数（说明在帮助与支持里，
  没有“测试普通话”按钮）。
- **播报条**：首页顶部胶囊，自动滚动最新地震 + 当地天气灾害预警，
  没有灾害预警时滚动未来 4 天天气预报；约 90 秒一圈，点按暂停/继续，
  等级只用小圆点和文字表示，不整条变色闪烁；天气不再单独成卡。
  “减少动态”开关在提醒方式里，开启后播报条停滚。
- **列表**：按震级配色（4级以下蓝绿、4级黄、5级橙、6级以上红），
  带“24小时最大”“最近最强”徽章；按 今天 / 昨天 / 更早 分组；
  可筛选（全部/4级以上/5级以上）、搜震中、按时间/距离排序；
  收起只显示基本信息，点开看详情：台网速报文案行内展示（不跳微博）、
  地图（点开才有，跳高德看震中）、震感记录。
  首页不再常驻地图。
- **新增功能**：离我最近（距监测城市最近 3 场，含预计烈度与 S 波到达状态）；
  家庭安全自查（我的里，6 项，本地保存，显示进度）；震感记录（本机保存）；
  家庭应急联系人（本机保存，可拨打）；预警记录（真实预警与测试预览分开记，
  可清空）；数据状态（我的页脚）；警报声/震动/外观开关都在提醒方式里。
- **推送断开只显示一次**：Hero 卡变琥珀色 + “重试连接”按钮，
  底部迷你状态条同步显示，不再另弹重复的“推送未连接”提示。
- **AI 分析（新增，每条地震的详情里）**：
  1. 智能分析：本机按本次地震的真实震级、深度、震中、距监测城市距离、
     估算烈度规则生成——震级定性、深浅、预计震感、余震可能性、应对建议，
     明确标注“本地规则生成，仅供参考，不构成预报”，绝不编造没有的数据。
  2. 历史最大地震：点开详情时查 USGS 全球地震目录（1900 年至今，
     震中 200 公里内，本次地震之前最大的那场），显示震级/时间/震中/深度；
     没有则显示“该区域公开目录内暂无记录”。
  3. 当时人员伤亡与受灾情况：只用 NOAA/NCEI 全球重大地震数据库里
     能对上号的记录（同年、震级差 ≤0.5、距离 ≤100 公里），显示死亡/
     受伤/房屋损毁的精确数字并注明来源；对不上或没有精确数字时显示
     “暂无公开伤亡数据”，绝不编造伤亡数字。
     注意：NCEI 部分记录只给量级代码不给精确数字（例如唐山 1976 年记录），
     这类一律按“无精确数据”处理，不把量级代码换算成人数。
  查询只在点开详情时触发一次，结果缓存在本机；失败时显示可重试的提示，
  不阻塞列表和报警。

## 同步更新（2026-11-05，第二批，与网页版同批改动）

- **预警弹窗不再展示微博**：全屏报警页里的微博按钮已去掉
  （列表详情里是台网速报文案行内展示，不跳微博）。
- **读秒节奏**：10 秒开外每 2 秒读一下，最后 10 秒每秒读。
- **到达强提示音**：倒计时结束（S 波到达）时，程序生成的警笛强提示音
  持续 20 秒（走闹钟通道），之后恢复普通警报声，直到用户手动停止。
- **快捷操作上移**：启动 / 停止 / 测试预警按钮移到主界面最上面，
  不用滑到底才找得到。（本版已改为：监测自动启动，开关在“我的 > 预警设置”，
  测试预警在“我的 > 播报预览”。）
- **iOS 27 毛玻璃风格**：浅色渐变底 + 半透明磨砂圆角卡片。
  实话：安卓原生控件做不出苹果那种真光线折射的液态玻璃，
  这里是同风格的半透明磨砂近似效果。（本版默认已换成深绿风格，
  浅色仍可在提醒方式里切回。）

## 打包成 APK（需要一台电脑，装 Android Studio）

1. 把本工程文件夹拷到电脑上，用 Android Studio 打开（第一次打开会下载
   Gradle 和依赖，需要联网，等同步完成）。
2. 点菜单 **Build → Build App Bundle(s) / APK(s) → Build APK(s)**，
   或者在 Android Studio 自带的终端里执行 `gradle assembleDebug`。
   （工程里只有 wrapper 配置没有 gradlew 脚本，Android Studio 打开后
   会用它自带的 Gradle，不影响打包。）
3. 生成的 APK 在 `app/build/outputs/apk/debug/app-debug.apk`，
   传到手机上安装（安装时会提示“未知来源”，允许这一次即可；
   debug 包用的是调试签名，自己用完全没问题）。

> 注意：本工程是在没有安卓编译环境的机器上写的，没有经过真机编译验证。
> 如果编译报错，把报错信息发回来，我来修。

## 云端编译（没有电脑也能用，在手机浏览器里操作）

工程里自带 `.github/workflows/android.yml`，用 GitHub 免费的云端机器编译，
全程在手机浏览器里就能完成：

1. 在手机浏览器打开 github.com，注册一个账号（已有账号直接登录）。
2. 点右上角 `+` → New repository，新建一个仓库，名字随便填（比如
   `earthquake-warning`），选 Public（公开，编译免费不限时；选 Private 也行，
   每月有 2000 分钟免费额度，一次编译只用几分钟），点 Create repository。
3. 在仓库页面点 Add file → Create new file，文件名填
   `.github/workflows/android.yml`，把下面“编译配置文件”的内容整段粘贴进去，
   点 Commit changes。
4. 再点 Add file → Upload files，上传 `earthquake-app-android.zip`
   （就是本工程的压缩包），点 Commit changes。
   （传完这一步编译会自动开始跑；如果它在你传 zip 之前就跑了一次并报错了，
   不用管，传完 zip 它会自动再跑一次。）
5. 点仓库顶部的 Actions 标签页，看到 Build APK 正在跑，等几分钟变成绿勾。
6. 点进那次运行，拉到最下面 Artifacts，下载 `app-debug`（是个 zip），
   在手机文件管理里解压，得到 `app-debug.apk`，点它安装，
   提示“未知来源”时允许这一次即可。
7. 装完按下面“装到手机后必须做的设置”走一遍。

编译配置文件（第 3 步粘贴用的内容）：

```yaml
name: Build APK

on:
  push:
  workflow_dispatch:

jobs:
  build:
    runs-on: ubuntu-latest
    steps:
      - name: Checkout
        uses: actions/checkout@v4

      - name: Set up JDK 17
        uses: actions/setup-java@v4
        with:
          distribution: temurin
          java-version: '17'

      - name: Set up Android SDK
        run: |
          mkdir -p "$HOME/Android/Sdk/cmdline-tools"
          cd "$HOME/Android/Sdk/cmdline-tools"
          curl -sL -o tools.zip https://dl.google.com/android/repository/commandlinetools-linux-11076708_latest.zip
          unzip -q tools.zip -d tmp
          mv tmp/cmdline-tools latest
          rm -rf tmp tools.zip
          echo "ANDROID_HOME=$HOME/Android/Sdk" >> $GITHUB_ENV
          echo "ANDROID_SDK_ROOT=$HOME/Android/Sdk" >> $GITHUB_ENV
          echo "$HOME/Android/Sdk/cmdline-tools/latest/bin" >> $GITHUB_PATH
          echo "$HOME/Android/Sdk/platform-tools" >> $GITHUB_PATH
          yes | "$HOME/Android/Sdk/cmdline-tools/latest/bin/sdkmanager" --licenses
          "$HOME/Android/Sdk/cmdline-tools/latest/bin/sdkmanager" "platform-tools" "platforms;android-34" "build-tools;34.0.0"

      - name: Set up Gradle 8.7
        uses: gradle/actions/setup-gradle@v3
        with:
          gradle-version: '8.7'

      - name: Unpack project zip (phone upload)
        run: |
          if [ -f earthquake-app-android.zip ]; then
            echo "Found project zip, unpacking..."
            unzip -o earthquake-app-android.zip -d .
          fi
          ls -la

      - name: Build debug APK
        run: gradle assembleDebug --stacktrace

      - name: Upload APK
        uses: actions/upload-artifact@v4
        with:
          name: app-debug
          path: app/build/outputs/apk/debug/app-debug.apk
          if-no-files-found: error
```

## 装到手机后必须做的设置（否则可能收不到或延迟）

1. 打开 App，到“我的 > 预警设置”选城市（或 GPS / 手动填经纬度），
   设好震级、烈度、提前时间；监测默认自动开启。
2. **电池设为无限制**：设置 → 应用 → 中国地震预警 → 电池 → 无限制
   （各品牌叫法不同，有的叫“允许后台运行”）。
3. **允许自启动**：设置 → 应用 → 中国地震预警 → 自启动 → 开。
4. **锁屏显示**：设置 → 应用 → 中国地震预警 → 权限 → 锁屏显示 / 悬浮窗 → 开。
5. 先到“我的 > 播报预览”点“测试预警”走一遍：全屏倒计时、警报声、震动、
   语音都正常再放心用。

## 数据来源与说明

- 地震数据：中国地震台网速报目录与预警推送（经 Wolfx 开放接口中转）。
- 列表详情里是台网速报标准格式文案（由目录真实字段拼成），行内展示，不跳微博。
- 天气：Open-Meteo（免费，无须 key）；天气灾害预警是按公开预报阈值推算的提示，
  不是气象部门正式发布的预警信号。
- 历史地震：美国地质调查局 USGS 地震目录（FDSN 接口，1900 年至今）。
- 伤亡数据：美国 NOAA/NCEI 全球重大地震数据库（只显示能对上号的记录的精确数字）。
- 预警推送的报文官方没有公开逐字段文档，代码里是兼容解析
  （多个候选字段名按顺序尝试，解析失败只记日志、不崩溃）；
  拿到真实推送后可按日志收紧字段。
- 烈度在台网没给时是粗略估算，仅供参考。
- 原生里没有内嵌地图（内嵌高德地图要 key 和 SDK）：详情里的地图和避难场所
  都是跳高德地图 App/网页查看，和网页版内嵌地图一样能用。
- 离震中太近的地震，S 波可能几秒就到甚至已经到了，预警时间可能为 0，
  这是所有预警系统的物理极限，不是 App 的问题。
- **本 App 不能替代官方预警**。最可靠的一层仍是手机系统自带的地震预警
  （华为、小米、OPPO、vivo、荣耀在设置里搜“地震预警”打开）；
  建议系统预警 + 本 App 双保险。

## 实现说明（给接手的人）

- 结构简化：没有用 Fragment。MainActivity 里两个页签用两个 ScrollView
  （homeScroll / myScroll）切换显示；“我的”二级页是同一个
  MyPageActivity 按 page 参数渲染 11 个子页；地震列表用 LinearLayout +
  ScrollView（目录最多取 20 条，没用 RecyclerView，和旧版写法一致）。
- 警报核心没动：WarningService 的 WebSocket、EewParser、BootReceiver、
  去重（alerted_ids）和报警判定逻辑与旧版完全一致；只加了两处：
  最近地震存完整字段（LocalStore.saveRecentFull），报警时记一条预警记录。
- 语音：MandarinTts 集中处理普通话白名单/黑名单与蜂鸣兜底，
  AlertActivity 和播报预览共用同一条路径。
- AI 分析：AiAnalysis.kt。本地分析纯规则计算；USGS 与 NCEI 查询只在
  点开详情时触发，结果按 eventId 缓存在 SharedPreferences。
