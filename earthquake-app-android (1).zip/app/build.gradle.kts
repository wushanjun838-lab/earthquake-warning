plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.quake.warning"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.quake.warning"
        minSdk = 26
        targetSdk = 34
        versionCode = 3
        versionName = "1.2"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("androidx.core:core-ktx:1.13.1")
    // 底部导航（首页 / 我的）
    implementation("com.google.android.material:material:1.12.0")
    // WebSocket + HTTP：连中国地震台网预警推送通道和速报目录
    implementation("com.squareup.okhttp3:okhttp:4.12.0")
}
